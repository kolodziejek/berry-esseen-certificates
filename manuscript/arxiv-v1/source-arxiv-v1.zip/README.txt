First manuscript draft, 27 October 2026
Bartosz Kolodziejek and Kacper Rodziewicz

This source archive is a conditional research draft, not a claim of a completed
sharp Berry--Esseen proof. It has not been submitted to arXiv.

Compile main.tex using pdfLaTeX. The generated main.bbl is included, so three
pdfLaTeX passes suffice. To regenerate the bibliography, use BibTeX between
the first and second pdfLaTeX passes. No external assets or shell escape needed.

Full source correspondence, citation verification, review reports and exact
check receipts are in the manuscript branch of the authors' fork:
https://github.com/kolodziejek/berry-esseen-certificates

AI assistance and remaining proof/certificate obligations are disclosed in
the manuscript. Author and mathematical review remain necessary.
