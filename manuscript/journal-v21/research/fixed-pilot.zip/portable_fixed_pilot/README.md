# Optional fixed-probability six-count research pilot

This package is **outside the selected manuscript proof DAG**. It proves a
conditional positive-score bound at exactly

```
n=5, p=77/200, k=2, u=0,
0 <= lambda <= 7687/25000,
-15293/500000 <= beta <= 307221/1000000,
```

with the selected original row's sign-conditioned support and rho lower
bound, as stated in the included proofs. It does not prove a closed
probability/phase rectangle, a complete original count row, all n=5 laws,
or a replacement for any selected manuscript argument. No page saving or
main-theorem consequence is claimed.

The method uses six global quartic CDF majorants, one for each actual
binomial count. Their expectations use the same two conditional marginal
laws. The acquired signed beta restricts their common variances to a
four-vertex polygon. Nine common moment pairs and the finite-n fourth
moment factor4/5 leave36 expectation tests. Exact ray checks and a
directed Gaussian target give the preserved CDF reserve greater than .00919.

## Exact replay

Extract the ZIP, enter its `portable_fixed_pilot` directory and run:

```sh
python3 -I -B -S replay.py /absolute/path/to/NEW_OUTPUT
```

Use unoptimized Python3.12. The output directory must not exist and must
be outside this package. Only the Python standard library is needed;
`-S` disables site packages. No SciPy, NumPy, compiler or network access
is required. The launcher checks the complete packaged file inventory,
runs the **unchanged** original `accept_beta_finite.py`, preserves actual
stdout/stderr/return code, and compares its complete result and proof
object byte-for-byte with the original accepted epoch. Replaying this
command establishes only the fixed-p/phase implication stated above.

The original acceptor reads the retained `DISCOVERY.json` to obtain its
thirty rational coefficients. It reconstructs the exact targets and
does not trust the discovery's success or floating margin. The package
therefore includes that exact discovery input, despite needing no discovery
rerun. Its floating search source is preserved for provenance; rerunning
the search would require SciPy and is not part of the command above.

The original workspace-relative `work/` and `runs/` hierarchy is retained
so all source and contract hashes are unchanged. `DEPENDENCIES.json`
lists the recursive local import/data closure used by exact acceptance.
`FILES.json` inventories every packaged file except itself. A trusted ZIP
or inventory hash from the enclosing publication is still needed to
authenticate the package; hashes alone do not prove mathematical soundness.

## What to read

- `work/count_quartic_shortening_20261104/audit/MIXTURE_SOUNDNESS.md`:
  exact count mixture, support moments, closed-CDF convention and the
  earlier smaller-noise motivation.
- `work/count_quartic_shortening_20261104/audit/BETA_FINITE_SOUNDNESS.md`:
  the full-noise fixed-point result packaged here.
- `work/earlier_local_comparison_20261104/integration/review_beta_polygon/`:
  independent proof and actual-law controls, including the danger of
  keeping a nonconvex negative variance-square correction.
- `runs/count_quartic_shortening_20261104/audit_beta_finite_accept01/`:
  complete original exact acceptance,12 malformed-object controls,
  441 beta-identity checks,23 actual law pairs,138 direct expectation
  checks and4 event collisions.

The selected contract is a necessary-condition input. Its acquisition,
contact reduction, full n=5 proof and original count forests are not
replayed or certified by this package. The independent review proves the
analytic implication; its agreement is not a substitute for that proof.

## Optional exact-law obstruction calculation

```sh
python3 -I -B -S check_obstruction_law.py /absolute/path/to/OTHER_NEW_OUTPUT
```

This small calculation reproduces the explicit three-atom law, its actual
CDF and the failure of the coarse-spacing staircase bound. It is not a
counterexample to Berry–Esseen and does not assert contact or attainment.
It does not repeat the historical scan of295 original contracts. The
selected contract and the proof note are included, but that whole scan's
inputs are deliberately not bundled.

Preserved `capture.py`, `check_obstruction.py` mains, older discovery
drivers, and absolute command paths inside historical records are not
portable replay entrypoints. Do not run those historical capture drivers
inside the published tree. Some older proof-note links describe smaller
or unsuccessful research epochs that are not bundled. Use the two commands
above for this package's supported scope. Original files and records were
copied byte-for-byte, rather than rewritten to hide historical paths.
