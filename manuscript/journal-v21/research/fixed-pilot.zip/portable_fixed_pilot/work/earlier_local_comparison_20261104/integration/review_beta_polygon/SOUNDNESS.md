# Nine shared moment pairs on the signed-beta polygon

Mathematical status: independently derived conditional expectation bound.
Execution status: bounded exact actual-law and convexity controls recorded
separately. This note does not prove a complete n=5 probability/phase row,
nor replace the original finite proof or any acquisition ancestor.

## Precise statement

Fix an integer `n>=1`, `0<p<1`, `q=1-p`, a real threshold `k+u`, and
two actual centered laws `U0,U1`. Assume, before using fourth moments,

```
-A0 <= U0 <= a0,       -a1 <= U1 <= A1,
0<=a0<=r0,             0<=a1<=r1,
A0,A1>=0,             r0<=p, r1<=q.
```

The last two restrictions ensure the original sign classes:
`U0-p<=0` and `q+U1>=0`, including atoms at zero. A separately acquired
bound `a0+a1<=d` may be used to set `r0=min(d,p)` and `r1=min(d,q)`.
Dropping the remaining coupling between `a0,a1` enlarges the domain and
is permitted for an upper bound. This theorem does **not** require
`d<p`, positive spacing between successive counts, or a bound on an
incoming/outgoing binomial mass ratio.

Set `s_i=E Ui²`, `x=q s0`, `y=p s1`, `v=pq`, `w=v+x+y`, and
`lambda=n(x+y)`. Let `Omega` be a fixed, nonempty compact convex polygon
containing the actual `(x,y)`, lying in `x,y>=0`, and independent of
the unknown inward endpoints and third moments. Degenerate segments
or singleton polygons are allowed, using their extreme points.

For every `j=0,...,n`, fix a quartic
`P_j(z)=sum c_(j,r) z^r` with `c_(j,4)>=0`. The coefficients are fixed
over the entire polygon, and do not depend on its unknown moments.
Define the nonnegative actual binomial weights
`pi_j=binom(n,j)p^j q^(n-j)`.

For each vertex `(x,y)` and each of the nine pairs

```
g0 in {-A0, 0, r0},       g1 in {A1, 0, -r1},
```

form, with `a=n-j`, `b=j`,

```
t_j = a*x/q + b*y/p,
M0=1, M1=0, M2=t_j,
M3=a*g0*x/q + b*g1*y/p,
M4=a*g0²*x/q + b*g1²*y/p + 3(1-1/n)*t_j².
```

Let `h_j=j-k-u` and evaluate

```
H_g(x,y) = sum_j pi_j sum_r c_(j,r)
              sum_(i=0..r) binom(r,i) h_j^(r-i) M_i.
```

Then, for `W_j` consisting of `n-j` independent copies of `U0` and
`j` independent copies of `U1`,

```
sum_j pi_j E P_j(W_j+h_j)
    <= max_(vertex of Omega, nine pairs g) H_g(x,y).
```

If also `P_j(z)>=1` on `z<=0` and `P_j(z)>=0` on `z>=0`, the left
side bounds the actual closed CDF `P(sum Y_i<=k+u)` from above.
Every `j` uses the same two conditional laws; this is the exact binomial
mixture of the iid law, not a collection of unrelated count distributions.
No coupling between different `W_j` is needed to take this expectation.
The global polynomial bounds include their common event-plane endpoint.

## Derivation of the beta polygon

Since `X=(Y-p)/sqrt(w)` has the actual sign partition, conditioning gives

```
w E[X|X|]
 = -q E(U0-p)² + p E(q+U1)²
 = -q(p²+s0)+p(q²+s1)
 = v(q-p)-x+y.
```

Thus the actual signed beta is exactly

```
beta = [v(q-p)-x+y]/[v+x+y].
```

The denominator is strictly positive, even at zero variance. Bounds
`beta_lo<=beta<=beta_hi` are therefore the two linear halfplanes

```
-(1+beta_hi)*x +(1-beta_hi)*y <= v*(beta_hi-(q-p)),
 (1+beta_lo)*x -(1-beta_lo)*y <= v*((q-p)-beta_lo).
```

These signs match `beta_polygon_model.PLANES`. There is no reflection
or replacement of beta by its absolute value. The identity is invalid
if the supplied conditional laws cross their original sign boundaries;
the separately acquired inward endpoint bounds are essential.

Safe additional halfplanes, when their premises have been proved, are:

- `x>=0`, `y>=0`, and `lambda_lo/n<=x+y<=lambda_hi/n`.
- `x+y<=v*Theta/(1-Theta)` from `theta<=Theta<1`.
- `x<=q*A0*r0`, `y<=p*A1*r1` from centering and bounded support.
- If `A0,A1>0` and `a0+a1<=d`, then
  `x/(q*A0)+y/(p*A1)<=d`.
- Any independently proved linear resource bound in `x,y`, with its
  coefficients fixed on this domain.

For the last two claims, integrate
`(Ui+outward_i)(inward_i-Ui)>=0` to obtain
`s_i<=outward_i*inward_i`. If an outward bound is zero, centering makes
that conditional law deterministic; impose its variance coordinate zero
instead of dividing by the zero bound. The rational halfplanes can be
enclosed outward over a probability cell, but a fixed-p vertex check by
itself proves nothing about other p values.

## Independent proof of the moment reduction

For `s_i>0`, set `gamma_i=E Ui³/s_i`. Weighting by `Ui²` gives
`-A0<=gamma0<=a0` and `-a1<=gamma1<=A1`. Integrating the nonnegative
support polynomials with an additional `Ui²` gives

```
E U0⁴ <= [(a0-A0)gamma0+A0*a0]*s0,
E U1⁴ <= [(A1-a1)gamma1+A1*a1]*s1.
```

For every count, independence and centering give exactly

```
E W_j⁴ = a E U0⁴+b E U1⁴
          +3t_j²-3(a s0²+b s1²).
```

Cauchy applied to the `n` individual variances gives
`a s0²+b s1²>=t_j²/n`. Consequently

```
E W_j⁴ <= a E U0⁴+b E U1⁴+3(1-1/n)t_j².
```

This includes `j=0,n`, deterministic components, and `n=1`. Translation
does not change the quartic leading coefficient. Therefore substituting
this bound into the whole expectation is valid, since both that coefficient
and each mixture weight are nonnegative.

Hold `(x,y)` fixed. The resulting expression is jointly affine in
`gamma0,gamma1` at fixed `a0,a1`, so its maximum on the rectangle is
bounded by the four simultaneous endpoints. On the class-zero outward
endpoint `gamma0=-A0`, the fourth-moment price is `A0²`, independent of
`a0`. On its inward endpoint `gamma0=a0`, that price is `a0²`. The
remaining contribution is

```
s0*(B3*a0+B4*a0²),
B4=sum_j pi_j*(n-j)*c_(j,4)>=0,
```

plus terms independent of `a0`; `B3` may have either sign. This is convex
in `a0`, so endpoints `0,r0` suffice. Class one similarly has outward
endpoint `gamma1=A1`, and an inward contribution
`s1*(-C3*a1+C4*a1²)` with `C4>=0`, hence endpoints `0,r1`.
The terms are separable in the two inward endpoints. Dropping their
coupling permits exactly the nine shared pairs stated above.

These are endpoints of a maximization of an **upper-bound polynomial**.
They do not assert `E Ui⁴<=gamma_i² s_i` for an arbitrary actual law.
Infeasible listed moment pairs can enlarge the answer; they cannot
invalidate the upper bound. A zero variance makes every corresponding
term vanish, so arbitrary gamma labels at that zero introduce no division
or missing case.

For each fixed shared pair, all terms of `H_g(x,y)` are affine except

```
3(1-1/n) sum_j pi_j*c_(j,4)*[(n-j)x/q+j y/p]².
```

This is a nonnegative sum of squares of linear forms, hence convex.
Every point of a compact polygon is a convex combination of its vertices;
Jensen's inequality bounds its value by the largest vertex value. One
can equivalently maximize the finite maximum of the nine convex functions.
The reduction keeps the same moment pair for every j before the sum.

## What cannot safely be added to this shortcut

1. Do not retain the **exact** negative variance-square correction and
   still assert convexity without a separate check. For `n=5,j=2`, put
   `t=3s0+2s1=1`. The exact cross-variance term is
   `3[1-3s0²-2s1²]`. Its endpoint values at `(1/3,0)` and `(0,1/2)`
   are `2` and `3/2`, while its interior value at `(1/5,1/5)` is `12/5`.
   The vertex maximum would miss the larger interior value. The Cauchy
   replacement is the convex upper bound `12/5` and handles it safely.
2. The polygon used above is independent of eliminated endpoints. If
   one keeps `x<=q A0 a0` with the unknown actual `a0`, its vertices move
   with `a0`. The stated two-stage proof no longer applies directly.
   The weaker fixed facets listed above are safe. A joint polytope in
   more variables would require a new convexity/endpoint argument.
3. Bounds on rho, cubic skew or physical defect may depend on the same
   higher moments. They are not automatically beta halfplanes. Retain
   them only through a separately proved fixed linear consequence, or
   supply a new optimization proof.
4. One fixed family of six quartics must be used over each whole moment
   polygon. Independently choosing a different family at every vertex
   does not establish a single convex expectation bound between vertices.
5. The binomial masses, shifts and Gaussian target vary with p and phase.
   This pilot's fixed `p=77/200,u=0` proof cannot be promoted to a closed
   p/phase cell, to every n=5 law, or to a shortened manuscript proof.

## Source mapping and current scope

The original `mixture_model.py` uses the weaker coefficient `3t²` and
eliminates a variance-allocation parameter at its two endpoints. Its
twelve-test smaller-noise statement is consistent with that proof.
The additive `beta_polygon_model.py` retains the acquired beta halfplanes,
enumerates their rational vertices, and uses the nine common pairs.
`beta_polygon_finite_model.py` replaces `3t²` by `3(1-1/n)t²`, exactly
the Cauchy bound proved here. Its moment rows and translated powers agree
with this theorem. This review finds no mathematical defect in that
extension. Serialized-object parsing, global Sturm acceptance and complete
scope coverage remain separate acceptance obligations.
