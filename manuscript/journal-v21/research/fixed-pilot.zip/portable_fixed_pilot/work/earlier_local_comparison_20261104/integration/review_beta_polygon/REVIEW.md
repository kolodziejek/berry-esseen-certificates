# Independent review outcome

No mathematical defect was found in the proposed beta-polygon extension
or its finite-n Cauchy refinement. `SOUNDNESS.md` supplies a complete
conditional theorem and an independent derivation. It proves the mixture
expectation bound; it does not establish a full n=5 row or admit any new
serialized score certificate.

The essential conditions are nonnegative binomial weights and quartic
leading coefficients; one fixed quartic family over each complete moment
polygon; actual sign-conditioned support; a fixed compact polygon containing
the law's variance pair; and no use of moment constraints whose dependence
on the eliminated inward/skew variables has been suppressed. The zero
variance cases are included without division. The nine moment pairs are
common to every count. Closed-CDF collisions are handled by both ray
majorants at zero.

The proof allows the additional fixed facet
`x/(q A0)+y/(p A1)<=d` when the outward bounds are positive. The current
pilot does not need this facet to be sound. Its beta/noise polygon is a
larger necessary-condition region, which is sufficient for an upper bound.
The global majorants need no ordered-count spacing, so `d<p` and even
`d<1` are not intrinsic premises of this expectation theorem; retaining
a stricter program guard is harmless for the selected pilot.

The tempting exact negative-diagonal fourth-moment correction is a real
obstruction to a careless vertex argument. An exact n=5 example on a
fixed-variance segment has interior value `12/5` and endpoint values
`2,3/2`. The Cauchy replacement `3(1-1/n)t²` is both valid and convex.
This refutes that proposed convexity shortcut, not the moment identity
or the Berry–Esseen conjecture.

Fresh independent controls use exact rational conditional laws and direct
convolution, without reading the constructor's successful proof object:

- 252 p/law/index/phase cases, including p above1/2 and both phase signs;
- 924 direct conditional convolutions;
- 35 exact event collisions,24 deterministic conditional components and
  12 negative-beta cases;
- the exact true-mixture CDF identity, the beta identity, the integrated
  fourth-moment price, the finite-n Cauchy bound, the nine-pair bound,
  and the polygon-vertex bound;
- explicit counterexamples to the exact-negative-diagonal convexity
  claim, to an actual-law `fourth<=gamma²*variance` claim, and to the beta
  formula without the original sign support.

Actual process return code0; elapsed4.041454792022705 seconds. Captures
are in `runs/earlier_local_comparison_20261104/analytic_beta_polygon_review01/`.
The result pins the four reviewed constructor source files before and
after execution. The controls do not calculate a new Berry–Esseen score
margin or constitute a numerical integration replay.

The fixed-p, fixed-phase pilot remains distinct from a continuous p/phase
cover. In particular, the rational Gaussian lower target at its full-noise
endpoint uses the positive numerator at this specific phase. A future
phase extension must retain the correct normal monotonicity direction,
along with the changing binomial masses, polygon and polynomial targets.
