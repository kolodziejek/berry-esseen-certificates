"""Independent exact finite-law controls for the beta-polygon theorem.

No constructor proof objects are read; no n=5 score conclusion is tested.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations,product
from math import comb
from hashlib import sha256
import json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
def need(v,m):
    if not v:raise ValueError(m)
need(__debug__ and not sys.flags.optimize,'unoptimized exact controls')
def H(p):return sha256(p.read_bytes()).hexdigest()
def conv(a,b):
    out={}
    for x,px in a.items():
        for y,py in b.items():out[x+y]=out.get(x+y,F(0))+px*py
    return out
def power(a,n):
    out={F(0):F(1)}
    for _ in range(n):out=conv(out,a)
    return out
def moment(a,d):return sum(w*x**d for x,w in a.items())
def centered(a,b):
    if not a or not b:return {F(0):F(1)}
    return {-a:b/(a+b),b:a/(a+b)}
def poly(c,z):return sum(v*z**j for j,v in enumerate(c))
def vertices(planes):
    out=set()
    for (a,b,c),(d,e,f)in combinations(planes,2):
        det=a*e-b*d
        if not det:continue
        x=(c*e-b*f)/det;y=(a*f-c*d)/det
        if all(A*x+B*y<=C for A,B,C in planes):out.add((x,y))
    need(out,'nonempty compact test polygon');return sorted(out)
def planes_for(p,A0,A1,r0,r1,d,L,blo,bhi):
    q=1-p;v=p*q
    need(0<p<1 and min(A0,A1)>0 and 0<=blo+1 and bhi<=1 and blo<=bhi and L>=0,'polygon premises')
    return [(-F(1),F(0),F(0)),(F(0),-F(1),F(0)),(F(1),F(1),L),
        (-(1+bhi),1-bhi,v*(bhi-(q-p))),
        (1+blo,-(1-blo),v*((q-p)-blo)),
        (F(1),F(0),q*A0*r0),(F(0),F(1),p*A1*r1),
        (1/(q*A0),1/(p*A1),d)]
def expectation_row(n,p,k,u,qs,x,y,g0,g1,J0,J1):
    q=1-p;total=F(0)
    for j,co in enumerate(qs):
        a=n-j;t=a*x/q+j*y/p
        M=[F(1),F(0),t,a*g0*x/q+j*g1*y/p,
           a*J0*x/q+j*J1*y/p+3*F(n-1,n)*t*t]
        h=j-k-u
        value=sum(co[r]*sum(F(comb(r,i))*h**(r-i)*M[i]for i in range(r+1))for r in range(5))
        total+=F(comb(n,j))*p**j*q**(n-j)*value
    return total
def majorants(n):
    out=[]
    for j in range(n+1):
        # 1+eta*(z^2+bz+c)^2 >=1 on all real z; mixed coefficient signs.
        b=F((-1)**j*(j+1),3);c=F(-j-1,4);eta=F(j+1,7)
        out.append([1+eta*c*c,2*eta*b*c,eta*(b*b+2*c),2*eta*b,eta])
    return out

def main(out):
    out.mkdir(parents=True,exist_ok=False)
    src=[ROOT/'work/count_quartic_shortening_20261104/audit'/f for f in
         ('MIXTURE_SOUNDNESS.md','mixture_model.py','beta_polygon_model.py','beta_polygon_finite_model.py')]
    before={str(p.relative_to(ROOT)):H(p)for p in src}
    A0=F(82453,125000);A1=F(703209,1000000);d=F(471533,500000)
    cases=convolutions=atoms=zero_variances=negative_betas=0;records=[]
    for p in (F(1,5),F(77,200),F(1,2),F(3,5)):
        q=1-p;v=p*q;r0=min(d,p);r1=min(d,q)
        zero={F(0):F(1)}
        laws=[(zero,zero),
              (centered(A0/2,r0/3),centered(r1/4,A1/2)),
              (centered(A0,r0/1000000),zero),
              (zero,centered(r1/1000000,A1)),
              (centered(A0,r0),zero),
              (zero,centered(r1,A1)),
              (centered(min(A0,r0)/3,min(A0,r0)/3),
               centered(min(A1,r1)/4,min(A1,r1)/4))]
        for number,(l0,l1)in enumerate(laws):
            need(moment(l0,1)==moment(l1,1)==0,'actual conditional centering')
            a0=max(l0);a1=-min(l1)
            need(-min(l0)<=A0 and max(l1)<=A1 and a0<=r0 and a1<=r1 and a0+a1<=d,'actual support including inward budget')
            s0=moment(l0,2);s1=moment(l1,2);x=q*s0;y=p*s1;w=v+x+y
            joint={}
            for b,pr,law in ((0,q,l0),(1,p,l1)):
                for z,m in law.items():joint[b+z]=joint.get(b+z,F(0))+pr*m
            beta=sum(m*(z-p)*abs(z-p)for z,m in joint.items())/w
            need(beta==(v*(q-p)-x+y)/w,'actual signed beta identity')
            negative_betas+=int(beta<0)
            blo=max(F(-1),beta-F(1,50));bhi=min(F(1),beta+F(1,50))
            planes=planes_for(p,A0,A1,r0,r1,d,x+y+F(1,20),blo,bhi)
            need(all(a*x+b*y<=c for a,b,c in planes),'all safe actual-law facets')
            V=vertices(planes);G=list(product((-A0,F(0),r0),(A1,F(0),-r1)))
            g0=moment(l0,3)/s0 if s0 else F(0);g1=moment(l1,3)/s1 if s1 else F(0)
            J0=(a0-A0)*g0+A0*a0;J1=(A1-a1)*g1+A1*a1
            need(moment(l0,4)<=J0*s0 and moment(l1,4)<=J1*s1,'integrated support fourth bounds')
            zero_variances+=int(s0==0)+int(s1==0)
            for n in (1,2,5):
              qs=majorants(n);k=n//2
              for u in (F(-1,2),F(0),F(1,2)):
                total=cdf=F(0)
                for j,co in enumerate(qs):
                    law=conv(power(l0,n-j),power(l1,j));pi=F(comb(n,j))*p**j*q**(n-j)
                    h=j-k-u
                    direct=sum(m*poly(co,z+h)for z,m in law.items());total+=pi*direct
                    cdf+=pi*sum(m for z,m in law.items()if z+h<=0)
                    atoms+=int(-h in law)
                    t=moment(law,2)
                    need(moment(law,4)<=(n-j)*moment(l0,4)+j*moment(l1,4)+3*F(n-1,n)*t*t,'finite-n Cauchy fourth bound')
                    convolutions+=1
                actual_cdf=sum(m for z,m in power(joint,n).items()if z<=k+u)
                need(cdf==actual_cdf and cdf<=total,'true iid mixture and closed-CDF majorant')
                first=expectation_row(n,p,k,u,qs,x,y,g0,g1,J0,J1)
                common=max(expectation_row(n,p,k,u,qs,x,y,h0,h1,h0*h0,h1*h1)for h0,h1 in G)
                last=max(expectation_row(n,p,k,u,qs,xx,yy,h0,h1,h0*h0,h1*h1)for xx,yy in V for h0,h1 in G)
                need(total<=first<=common<=last,'same-law -> nine common pairs -> polygon vertices')
                cases+=1
            records.append(dict(p=str(p),law_case=number,vertices=len(V),beta=str(beta),x=str(x),y=str(y)))
    # Exact obstruction to replacing the Cauchy bound by the negative diagonal.
    def exact_cross(s0,s1):return 3*((3*s0+2*s1)**2-3*s0*s0-2*s1*s1)
    end=(exact_cross(F(1,3),F(0)),exact_cross(F(0),F(1,2)))
    middle=exact_cross(F(1,5),F(1,5))
    need(middle==F(12,5)>max(end),'exact negative-diagonal vertex counterexample')
    # Actual symmetric noise refutes the unlicensed pointwise gamma-square bound.
    sym=centered(F(1,10),F(1,10))
    need(moment(sym,3)==0 and moment(sym,4)>0,'gamma-square is not an actual moment inequality')
    # Beta requires the sign partition: a centered U0 that crosses p breaks it.
    p=F(1,5);q=1-p;cross=centered(F(1,2),F(1,2));s0=moment(cross,2);w=p*q+q*s0
    actual=(q*sum(m*(z-p)*abs(z-p)for z,m in cross.items())+p*q*q)/w
    claimed=(p*q*(q-p)-q*s0)/w
    need(actual!=claimed,'cross-sign law defeats beta formula without endpoint premise')
    need({str(p.relative_to(ROOT)):H(p)for p in src}==before,'reviewed source epoch unchanged')
    result=dict(schema='BETA_POLYGON_INDEPENDENT_ACTUAL_LAW_REVIEW_V1',
        mathematical_status='proved conditional mixture expectation reduction; no complete n5 score or row claim',
        execution_status='fresh stdlib exact independent controls',cases=cases,conditional_convolutions=convolutions,
        exact_event_collisions=atoms,zero_variance_components=zero_variances,negative_beta_cases=negative_betas,
        source_pins=before,records=records,
        negative_examples=dict(exact_negative_diagonal=dict(endpoint_values=list(map(str,end)),interior_value=str(middle)),
            actual_gamma_square_bound='refuted by centered symmetric two-point noise',
            missing_sign_support=dict(actual_beta=str(actual),invalid_formula=str(claimed))),
        review_source_sha256=H(HERE/'check_actual_laws.py'),proof_sha256=H(HERE/'SOUNDNESS.md'),
        interpreter=dict(path=sys.executable,version=sys.version))
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in ('cases','conditional_convolutions','exact_event_collisions','zero_variance_components','negative_beta_cases')},indent=2))
if __name__=='__main__':
    need(len(sys.argv)==2,'one new output path');main(Path(sys.argv[1]).resolve())
