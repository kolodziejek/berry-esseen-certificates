"""Floating discovery only; exact fixed-target acceptance follows each candidate."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import numpy as np
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import mixture_model as m

def propose(upper):
    r=m.rows(upper);target=float(m.target(upper));points=[list(np.linspace(-8,8,65))for _ in range(6)]
    points=[p+[-.001,.001,0.]for p in points]
    for it in range(40):
        lhs=[list(map(float,z))+[1.]for z in r];rhs=[target]*len(r)
        for j in range(6):
            for z in points[j]:
                scale=max(1.,abs(z)**4);row=[0.]*31
                for d in range(5):row[5*j+d]=-z**d/scale
                lhs.append(row);rhs.append(-(1. if z<=0 else 0.)/scale)
        ans=linprog([0.]*30+[-1.],A_ub=lhs,b_ub=rhs,
            bounds=[((-500,500)if j%5<4 else(1e-7,500))for j in range(30)]+[(-100,100)],method='highs',
            options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
        if not ans.success:return {'status':'DISCOVERY_FAILED','message':ans.message}
        qs=ans.x[:30].reshape(6,5);new=0
        for j,q in enumerate(qs):
            for z in np.polynomial.polynomial.polyroots([d*q[d]for d in range(1,5)]):
                if abs(z.imag)>1e-8:continue
                z=float(z.real);needed=1 if z<=0 else 0
                if np.polynomial.polynomial.polyval(z,q)<needed-1e-8*max(1,abs(z)**4):
                    points[j].append(z);new+=1
        if new:continue
        if ans.x[-1]<=1e-5:return {'status':'NO_POSITIVE_DISCOVERY_MARGIN','margin':float(ans.x[-1]),'iterations':it+1}
        exact=[[F(round(x*10**10),10**10)for x in q]for q in qs]
        for q in exact:q[0]+=F(1,10**6);q[4]+=F(1,10**7)
        try:checked=m.accept(exact,upper)
        except ValueError as e:return {'status':'EXACT_CANDIDATE_REJECTED','reason':str(e),'margin':float(ans.x[-1]),'q':[[str(x)for x in q]for q in exact]}
        return {'status':'DISCOVERED_EXACTLY_ACCEPTED','q':[[str(x)for x in q]for q in exact],'result':checked,'iterations':it+1}
    return {'status':'DISCOVERY_SEPARATION_LIMIT'}

if __name__=='__main__':
    out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
    results=[]
    for upper in(F(m.cfg['acquired_lambda_upper']),F(123,4000)):
        z=propose(upper);z['upper']=str(upper);results.append(z)
        print(json.dumps({k:v for k,v in z.items()if k!='q'}),flush=True)
    (out/'DISCOVERY.json').write_text(json.dumps(results,indent=2)+'\n')
