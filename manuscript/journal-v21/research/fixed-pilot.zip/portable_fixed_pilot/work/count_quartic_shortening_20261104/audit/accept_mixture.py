"""Separate exact six-count pilot admission and adversarial controls."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(HERE))
import mixture_model as m
need=m.need
OBJECT='runs/count_quartic_shortening_20261104/audit_mixture_bernstein01/objects/DISCOVERY.json'
UPPER=F(123,4000)
def admit(obj):
    need(type(obj)is dict and set(obj)=={'n','p','k','u','lambda','q'},'fixed pilot object fields')
    need(type(obj['n'])is int and obj['n']==5 and type(obj['k'])is int and obj['k']==2,'actual n and count')
    need(obj['p']=='77/200'and obj['u']=='0'and obj['lambda']==['0','123/4000'],'exact explicitly bounded pilot domain')
    return m.accept(obj['q'],UPPER)

def main(out):
    src=ROOT/OBJECT;z=json.loads(src.read_text(),object_pairs_hook=m.old.unique)
    selected=[r for r in z if r['upper']=='123/4000'];need(len(selected)==1,'unique fixed discovery scope')
    obj=dict(n=5,p='77/200',k=2,u='0',**{'lambda':['0','123/4000']},q=selected[0]['q'])
    r=admit(obj);qs=[list(map(F,q))for q in obj['q']]
    controls=[]
    for name,modify in[
      ('missing count',lambda z:z['q'].pop()),
      ('wrong n',lambda z:z.update(n=6)),
      ('boolean n',lambda z:z.update(n=True)),
      ('wrong phase',lambda z:z.update(u='1/1000')),
      ('wrong probability',lambda z:z.update(p='19/50')),
      ('enlarged noise',lambda z:z.update({'lambda':['0','7687/25000']})),
      ('wrong closed CDF endpoint',lambda z:z['q'][2].__setitem__(0,'0')),
      ('negative leading coefficient',lambda z:z['q'][0].__setitem__(4,'-1')),
      ('false global majorant',lambda z:z['q'][3].__setitem__(0,str(F(z['q'][3][0])-2))),
      ('injected success marker',lambda z:z.update(success=True))]:
        bad=json.loads(json.dumps(obj));modify(bad)
        try:admit(bad)
        except(ValueError,KeyError,TypeError):controls.append(name)
        else:raise ValueError('mutation accepted '+name)
    # Independent full convolutions use actual conditional laws, not the
    # constructor's moment corner formula. They check both orientations,
    # zero variance, tiny atoms and exact event collisions.
    laws=[]
    def centered(a,b):return{-a:b/(a+b),b:a/(a+b)}
    for a,b in((F(1,100),F(1,100)),(F(1,10),F(1,10)),(F(1,2),F(1,1000))):
        laws.extend([(centered(a,b),{F(0):F(1)}),({F(0):F(1)},centered(b,a))])
    laws.append(({F(0):F(1)},{F(0):F(1)}))
    identities=0;collisions=0
    for l0,l1 in laws:
        s0=sum(x*x*p for x,p in l0.items());s1=sum(x*x*p for x,p in l1.items())
        lam=5*(m.Q*s0+m.P*s1);need(lam<=UPPER,'test within bounded noise')
        weighted=F(0)
        for j,q in enumerate(qs):
            d0=m.old.convolution(l0,5-j);d1=m.old.convolution(l1,j);dist={}
            for x,a in d0.items():
                for y,b in d1.items():dist[x+y]=dist.get(x+y,F(0))+a*b
            actual_m=[sum(prob*x**d for x,prob in dist.items())for d in range(5)]
            shifted=[sum(F(__import__('math').comb(d,i))*(j-2)**(d-i)*actual_m[i]for i in range(d+1))for d in range(5)]
            e_direct=sum(prob*sum(q[d]*(x+j-2)**d for d in range(5))for x,prob in dist.items())
            need(e_direct==sum(a*b for a,b in zip(q,shifted)),'independent translated expectation identity')
            event=sum(prob for x,prob in dist.items()if x<=2-j)
            need(event<=e_direct,'actual closed-event majorant')
            collisions+=int(F(2-j)in dist);weighted+=m.MASS[j]*e_direct;identities+=1
        corner=max(sum(a*b for a,b in zip(rr,sum(qs,[])))for rr in m.rows(UPPER))
        need(weighted<=corner,'actual iid moments within complete corner bound')
    out.mkdir(exist_ok=False)
    (out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n')
    r.update(discovery_source=OBJECT,discovery_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
       negative_controls=controls,independent_actual_pairs=len(laws),direct_expectation_checks=identities,event_collisions=collisions,
       source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(HERE/'mixture_model.py',HERE/'check_obstruction.py',Path(__file__))})
    (out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
if __name__=='__main__':main(Path(sys.argv[1]).resolve())
