# A six-count quartic pilot without a spacing denominator

Mathematical status: a locally derived and checked conditional implication
on the fixed probability and phase below. Execution status: fresh separate
stdlib-only exact acceptance, with mutations and actual-law controls. The
complete n=5 row, its other phases/probabilities and larger noise values
remain unproved by this new method. The original n=5 proof is unchanged.

The original selected row and its acquisition premises are identified in
`SOUNDNESS.md`. Fix n=5, p=77/200, q=123/200, k=2, u=0. Suppose the actual
sign-conditioned centered residuals satisfy

    -A0 <= U0 <= a0,       -a1 <= U1 <= A1,
    A0=82453/125000,       A1=703209/1000000,
    0<=a0<=min(d,p),       0<=a1<=min(d,q),
    d=471533/500000,       rho >= 11/10,
    0 <= lambda=5(q E U0²+p E U1²) <= 123/4000.

These are necessary conditions from the selected row on the stated smaller
noise interval. Dropping a0+a1<=d enlarges the actual domain and is safe for
an upper bound. The inward p and q bounds follow from the original sign
partition; they are not inferred from d<p, which is false on this row.
The absolute noise amplitudes are the original two outward bounds, not a
later confinement output. No fourth moment is introduced before support.

Let W_j sum j independent U1 variables and 5-j independent U0 variables.
For each of the six counts, choose a possibly different quartic

    P_j(z) = sum_(r=0)^4 c_(j,r) z^r,       c_(j,4)>=0,

satisfying P_j(z)>=1 for z<=0 and P_j(z)>=0 for z>=0. Then the exact mixture
identity yields

    P(sum Y_i<=2) <= sum_(j=0)^5 pi_j E P_j(W_j+j-2),
    pi_j=binom(5,j)p^j q^(5-j).

This is the closed-CDF convention at z=0. It has no small spacing
denominator and no reflection of the actual p domain.

## Why twelve common-moment tests suffice on this pilot domain

Write s_i=E U_i² and mu_i=E U_i³. Actual support gives

    E U0⁴ <= (a0-A0)mu0 + A0*a0*s0,
    E U1⁴ <= (A1-a1)mu1 + A1*a1*s1.

These follow by integrating (U0+A0)(a0-U0)U0²>=0 and its reflected
class-one form. When s_i>0 put gamma_i=mu_i/s_i; support-weighted averaging
gives -A0<=gamma0<=a0 and -a1<=gamma1<=A1. A zero variance is deterministic.

For lambda>0 set alpha=5p*s1/lambda. Then
s0=lambda(1-alpha)/(5q), s1=lambda*alpha/(5p), and alpha belongs to [0,1].
For each j, independence gives

    t_j=(5-j)s0+j*s1,
    E W_j³=(5-j)mu0+j*mu1,
    E W_j⁴=(5-j)E U0⁴+j E U1⁴
             +3t_j²-3((5-j)s0²+j*s1²).

Drop the last nonpositive term. Because every leading coefficient and every
binomial mass is nonnegative, the resulting upper bound for the complete
mixture is convex in alpha when a_i and gamma_i are fixed: all terms are
affine except a nonnegative sum of squares 3*pi_j*c_(j,4)*t_j². Its maximum
is therefore bounded by alpha=0 or alpha=1, keeping one common alpha for
all counts rather than optimizing each count separately.

At alpha=0 the remaining expression is affine in gamma0, so use -A0 or a0.
At -A0, the fourth-moment linear price is exactly A0², independent of a0.
At gamma0=a0, that price is a0²; the mixture is a convex quadratic in a0,
so use a0=0 or min(d,p). Class one is identical after reflection. Thus the
six common extremal pairs (alpha,gamma) are

    (0,-A0), (0,0), (0,min(d,p)),
    (1, A1), (1,0), (1,-min(d,q)).

This is a bound obtained after maximizing a polynomial extension of the
actual moment expression. It does **not** assert E U_i⁴<=gamma_i²*s_i for
an arbitrary actual law. Only at the listed extremal evaluations is that
linear fourth-moment price gamma².

For each such evaluation and every j, use

    t_j=lambda*(5-j)/(5q)  if alpha=0,
    t_j=lambda*j/(5p)      if alpha=1,
    M0=1, M1=0, M2=t_j, M3=gamma*t_j,
    M4=gamma²*t_j+3t_j².

The shifted expectation is exactly
sum_r c_(j,r) sum_(i<=r) binom(r,i)(j-2)^(r-i) M_i.
Its mixture is a convex quadratic in lambda, so its maximum on the closed
noise interval occurs at 0 or 123/4000. These are the twelve fixed tests.
At lambda=0 all residuals vanish, and the polynomial formulas apply
continuously without dividing by variance.

The actual normal argument is (3/40)/sqrt(5pq+lambda). Its numerator is
positive; therefore its CDF is bounded below by its value at the upper
noise endpoint. Directed Gaussian and square-root arithmetic gives the
fixed sufficient target

    sum pi_j E P_j < Phi((3/40)/sqrt(5pq+123/4000))
                     + C_E_lower*(11/10)/sqrt(5)_upper.

Since rho>=11/10 and C_E_lower<C_E, this proves the positive normalized
score is strictly less than C_E throughout the displayed domain.

## Exact global majorants and observed outcome

Each quartic's left target is P_j(z)-1 and its right target is P_j(z).
Set z=+/-t/(1-t), multiply by (1-t)^4, and verify strict positivity on
the complete compact interval t in [0,1] with the existing exact rational
Sturm reader. The left target includes the closed threshold. Positivity
of the leading coefficient controls the endpoint corresponding to infinity.
The reader reconstructs the targets from the thirty coefficients; a
discovery success marker is not consulted.

Selected object:
`runs/count_quartic_shortening_20261104/audit_mixture_accept01/accepted/proof_object.json`.
Independent exact process capture:
`runs/count_quartic_shortening_20261104/audit_mixture_accept01/PROCESS.json`.
Actual return code 0, 0.079 seconds, stable source hashes; no SciPy import
is needed during this acceptance. All twelve rays and twelve expectation
tests pass with CDF margin greater than .0205. Ten malformed or corrupted
objects reject. Seven actual conditional-law pairs, including deterministic
terms, skew pairs and a tiny atom, give 42 direct convolution/expectation
checks and four exact event collisions.

The floating search on the original larger noise interval [0,7687/25000]
did not produce a positive margin (the whole-ray Bernstein discovery gave
about -.00899). This is not an exact infeasibility result. A sampled-ray
search on the smaller interval hit its finite separation budget; the
separate whole-ray Bernstein discovery then supplied the accepted object.
Both records are retained. The simple Q0-template search also failed;
it is not evidence against unrestricted quartic majorants.

For a complete replacement, the next concrete mathematical obligation is
to retain the original common rho/beta/physical-defect restrictions when
maximizing the six-count quartic expectation. Those restrictions may remove
the adverse moment corners at larger noise. Full closed p and phase covers,
all legal counts and all retained signed moment rectangles would still be
required. This pilot warrants no manuscript deletion or claimed page saving.
