"""Create-only bounded exact-check capture; no inherited driver mutation."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
def pins():return{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(HERE.glob('*.py'))}
before=pins();argv=[sys.executable,'-I','-B',str(HERE/'check_obstruction.py'),str(out/'accepted')]
start=time.monotonic()
with(out/'stdout.txt').open('wb')as so,(out/'stderr.txt').open('wb')as se:
    p=subprocess.run(argv,cwd='/private/tmp',stdout=so,stderr=se)
record=dict(argv=argv,cwd='/private/tmp',runtime=sys.version,returncode=p.returncode,seconds=time.monotonic()-start,source_before=before,source_after=pins())
record['sources_unchanged']=before==record['source_after']
(out/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in('returncode','seconds','sources_unchanged')}))
if p.returncode or not record['sources_unchanged']:raise SystemExit(1)
