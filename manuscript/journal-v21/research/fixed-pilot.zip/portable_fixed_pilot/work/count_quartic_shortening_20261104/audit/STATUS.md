# Bounded low-index shortening checkpoint

The main manuscript and all original count data are unchanged. The earlier
coefficient-audit shortening attempt was read first; it gave no measured
net saving and remains optional. This branch tests a different probability
argument, not relocation of analytic obligations.

1. **Coarse-spacing obstruction — exact, fresh PASS.** On the hardest
   selected n=5 count contract (BN/p38, 822 old leaves), one explicit
   three-point iid law satisfies all checked numeric contract enclosures.
   Its exported-spacing staircase expectation is exactly 31/246, implying
   a proxy score >.456, while its actual score lies in (.017,.018).
   No polynomial majorant of that fixed payoff can close the score there.
   This is not a contact-law or conjecture counterexample. See SOUNDNESS.md,
   check_obstruction.py and audit_obstruction02. The physical gap gives
   spacing >0; the affine resource intercept must not be substituted for it.

2. **Six-count quartic alternative — exact bounded pilot, fresh PASS.**
   At p=77/200,k=2,u=0 and all lambda in [0,123/4000], six globally valid
   CDF quartics prove the sharp positive score bound under the selected
   support and rho premises. Same conditional moments are used for all
   six counts. Twelve common moment/noise endpoints and twelve exact rays
   suffice. Separate stdlib acceptance passes ten corrupt-object controls,
   42 direct actual-law expectation checks and four collisions. Sources:
   mixture_model.py, accept_mixture.py; evidence audit_mixture_accept01.

3. **Full acquired noise interval at the fixed p/u — now exact PASS.**
   A separate additive beta-polygon model retains the original signed beta
   halfplanes and uses the finite-sample Cauchy fourth-moment factor 4/5.
   Four exact variance vertices and nine common skew/inward pairs give 36
   expectation tests for six globally certified CDF quartics. The full
   lambda interval [0,7687/25000] now passes with margin >.00919 at exactly
   p=77/200,k=2,u=0. Fresh separate stdlib acceptance is recorded in
   audit_beta_finite_accept01; twelve mutations reject, 441 exact beta
   checks and 138 actual-law expectation checks pass. See
   BETA_FINITE_SOUNDNESS.md. The earlier negative floating searches are
   preserved as discovery outcomes, not impossibility statements.

4. **Still missing:** full p/phase/count and signed-domain coverage. No
   claim of a complete row, n=5 replacement, n=5..38 result, or page saving.
   This research checkpoint is frozen while the selected central campaign
   and its manuscript integration are completed.

All run names refer to `runs/count_quartic_shortening_20261104/`. The
historical original C5 selection is only a source/census identity here;
its adopted C4 claim is not newly invoked as a substitute for the current
manuscript's independently supplied small-index proofs.
