"""Separate fixed-p/u pilot retaining exact acquired beta halfplanes."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
from itertools import combinations,product
import sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import mixture_model as base
need=base.need;cfg=base.cfg;N=base.N;P=base.P;Q=base.Q;K=base.K
UPPER=F(cfg['acquired_lambda_upper']);BLO,BHI=map(F,cfg['acquired_beta'])
V=P*Q
PLANES=[(-F(1),F(0),F(0)),(F(0),-F(1),F(0)),(F(1),F(1),UPPER/N),
  (-(1+BHI),1-BHI,V*(BHI-(Q-P))),
  (1+BLO,-(1-BLO),V*((Q-P)-BLO))]
def vertices():
    out=set()
    for (a,b,c),(d,e,f)in combinations(PLANES,2):
        det=a*e-b*d
        if not det:continue
        x=(c*e-b*f)/det;y=(a*f-c*d)/det
        if all(A*x+B*y<=C for A,B,C in PLANES):out.add((x,y))
    need(len(out)>=3,'nonempty compact rational polygon');return sorted(out)
VERTICES=vertices()
GAMMAS=list(product((-base.A0,F(0),min(base.D,P)),(base.A1,F(0),-min(base.D,Q))))
def rows():
    out=[]
    for x,y in VERTICES:
      for g0,g1 in GAMMAS:
        rr=[]
        for j in range(6):
            t=(N-j)*x/Q+j*y/P
            m3=(N-j)*g0*x/Q+j*g1*y/P
            m4=(N-j)*g0*g0*x/Q+j*g1*g1*y/P+3*t*t
            moments=[F(1),F(0),t,m3,m4]
            shifted=[sum(F(comb(d,i))*(j-K)**(d-i)*moments[i]for i in range(d+1))for d in range(5)]
            rr.extend(base.MASS[j]*z for z in shifted)
        out.append(rr)
    return out
def accept(qs):
    need(type(qs)is list and len(qs)==6,'six exact quartics');qs=[list(map(F,q))for q in qs]
    for q in qs:
        need(len(q)==5 and q[4]>0,'positive leading quartic')
        base.sturm.positive(base.compact_ray(q,-1,1));base.sturm.positive(base.compact_ray(q,1,0))
    maximum=max(sum(a*b for a,b in zip(rr,sum(qs,[])))for rr in rows())
    margin=base.target(UPPER)-maximum;need(margin>0,'strict complete beta-polygon bound')
    return dict(status='PASS_EXACT_FIXED_P_PHASE_FULL_NOISE_BETA_POLYGON',n=N,p=str(P),k=K,u='0',noise=['0',str(UPPER)],
       beta=list(map(str,(BLO,BHI))),vertices=[[str(x),str(y)]for x,y in VERTICES],moment_combinations=9,
       gates=len(rows()),margin=str(margin),scope='Fixed p and phase only; original full noise and acquired beta intervals retained. No complete probability/phase row claim.')
