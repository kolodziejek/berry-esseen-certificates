"""Floating discovery on exact beta vertices, with whole-ray constraints."""
from pathlib import Path
from fractions import Fraction as F
import sys,json
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import beta_polygon_model as m

def propose():
    rows=m.rows();lhs=[list(map(float,r))+[1.]for r in rows];rhs=[float(m.base.target(m.UPPER))]*len(lhs)
    st=m.base.sturm.base
    for j in range(6):
      for sign,sub in((-1,1),(1,0)):
        targets=[m.base.compact_ray([int(k==d)for k in range(5)],sign,0)for d in range(5)]
        constant=m.base.compact_ray([sub,0,0,0,0],sign,0)
        for a in range(32):
          co=[st.bernstein(st.affine(p,F(a,32),F(1,32)))for p in targets]
          cc=st.bernstein(st.affine(constant,F(a,32),F(1,32)))
          for k in range(5):
            row=[0.]*31
            for d in range(5):row[5*j+d]=-float(co[d][k])
            lhs.append(row);rhs.append(-float(cc[k])-1e-9)
    ans=linprog([0.]*30+[-1.],A_ub=lhs,b_ub=rhs,
      bounds=[((-500,500)if d%5<4 else(1e-8,500))for d in range(30)]+[(-100,100)],method='highs',
      options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    if not ans.success:return dict(status='DISCOVERY_FAILED',message=ans.message)
    if ans.x[-1]<=1e-5:return dict(status='NO_POSITIVE_BETA_POLYGON_DISCOVERY_MARGIN',margin=float(ans.x[-1]))
    exact=[[F(round(x*10**10),10**10)for x in ans.x[5*j:5*j+5]]for j in range(6)]
    for q in exact:q[0]+=F(1,10**6);q[4]+=F(1,10**7)
    try:r=m.accept(exact)
    except ValueError as e:return dict(status='EXACT_CANDIDATE_REJECTED',reason=str(e),margin=float(ans.x[-1]),q=[[str(x)for x in q]for q in exact])
    return dict(status='PASS_EXACT_BETA_POLYGON_PILOT',margin=float(ans.x[-1]),result=r,q=[[str(x)for x in q]for q in exact])
if __name__=='__main__':
    out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False);r=propose()
    (out/'DISCOVERY.json').write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items()if k!='q'}))
