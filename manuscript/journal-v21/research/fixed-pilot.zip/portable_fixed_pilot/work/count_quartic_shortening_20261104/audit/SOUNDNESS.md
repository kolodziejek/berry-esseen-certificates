# What the first low-index test establishes

Mathematical status: locally derived exact obstruction to using one coarse
exported-spacing staircase on a selected five-summand count row. Execution
status: fresh exact finite-law and interval checks. This is not a new proof
or disproof of any Berry–Esseen inequality, and it does not invalidate the
old count forests.

The source is the selected BN row at p in [19/50,39/100], from
`work/cutoff5_20261020/root/count5_prepare_v1/gamma16_01/n5/BN/panel038/contract.json`,
SHA256 `2b3f626ba3a9e954e4700bf206cf7a364f44958bb901b463198249dda2f37e48`.
It has 822 accepted old leaves, the maximum over the 295 selected n=5
contracts. Its selection, contract and old receipt hashes are checked; the
old arithmetic and acquisition are not rerun here. Historical contract
fields still label acquisition as conditional. Later composition is a
separate dependency, not inferred from those labels.

## The interface is broader than the new central theorem

The original finite count domain includes p on both sides of 1/2. Among
the 295 selected contracts, 195 have upper endpoint at most 1/2 and 100
have lower endpoint at least 1/2. Only 56 satisfy the new theorem's
convenient sufficient guard d < min(p,q) throughout their full panel.

The row's affine inward intercept is 7.691481. It must not be used as
the actual inward bound or as a spacing. A separate physical-gap argument
supplies actual inward sum at most 471533/500000, strictly below one.
Thus the monotone coupling is licensed with c=28467/500000. Original
`contract_helpers.py` and `generalized_scope.py` explicitly distinguish
these quantities and preserve the same oriented sign-conditioned marginal.
The independent mean/noise cap is likewise separate from the joint
intercept: clipping the former does not replace the latter in the joint
resource plane.

A useful extension is possible in principle: the exact absolute-cubic
identity requires the actual sign conditions U0<=p and U1>=-q. These already
follow from B=1{X>0}, including the prescribed treatment of a zero atom.
They do not require the stronger numerical sufficient condition d<p.
After deriving the identity for the actual law, minimizing its polynomial
extension over a larger moment box remains a safe relaxation. However,
the present central gate API enforces d<p, and the p<1/2 scalar extrema
must be replaced by extrema on the correct side of 1/2. A successful new
certificate would need a separately named, audited interface. None is
silently claimed here.

## An exact same-pair example

Set n=5, p=77/200, q=123/200. Conditional on B=0, let U take the two
values -1/10 and 1/10 with equal probabilities; conditional on B=1, let
U=0. The centered unstandardized variable Z=B-p+U has three atoms

| Z | Probability |
|---|---|
| -97/200 | 123/400 |
| -57/200 | 123/400 |
| 123/200 | 77/200 |

Its variance is w=9717/40000. Put X=Z/sqrt(w). The exact checker proves
all numeric contract enclosures for this same law: the closed p and rho
bands; signed beta and gamma; first absolute half-mean; both outer radii
and inner endpoints; conditional outward and inward bounds; the mean-based
scale/noise caps; the original joint resource plane; and the phase-dependent
physical-defect budget at the selected threshold. In particular rho is
between 1.1004 and 1.1005, lambda=123/4000, and D is between 1.4305 and
1.4307. The signed quantities are evaluated in the original orientation.

For the defect check, the raw gap functional is computed directly from the
three atoms:
J_raw = sum over adjacent raw atoms x_j<x_(j+1) of
(sum_(i>j) probability_i*x_i)*(x_(j+1)-x_j)^2.
Then J=J_raw/w^(3/2) and
D=((3+sqrt(10))*E|Z|^3-EZ^3-3J_raw)/w^(3/2).
Directed rational square roots enclose this quantity. This is not an
assumption that a general moment tuple is realizable.

At k=2,u=0, the raw threshold for the sum of X is H=(3/40)/sqrt(w).
The common W2 sums three independent symmetric +/-1/10 variables. Its
values are -3/10,-1/10,1/10,3/10 with probabilities 1/8,3/8,3/8,1/8.
The exact maximum incoming binomial ratio is R0=77/123. With the exported
spacing c=28467/500000, the incoming floors at -3/10 and -1/10 are 5 and
1. The outgoing probability is 1/2. Therefore

    E psi(W2) = -1/2 + (77/123)*(5/8+3/8) = 31/246.

For any polynomial P, of any degree, satisfying P>=psi on the real line,
E P(W2)>=31/246. Thus even the smallest possible bound obtained by
substituting such a P into the one-staircase CDF inequality is at least

    sqrt(5)/rho * [ F_Bin(5,p)(2) + pi_2*(31/246)
                   - Phi((3/40)/sqrt(5w)) ] > .456 > C_E.

The checker proves this with rational Gaussian enclosures. An exact
convolution of the actual three-point iid law gives CDF
171439815843/320000000000 at that threshold, and its actual positive score
is in (.017,.018). Hence this is a limitation of the exported-spacing
majorant, not an actual Berry–Esseen counterexample.

The example is not asserted to satisfy attainment or the contact equation.
It satisfies the exported necessary scalar conditions; a stronger
contact-based exclusion or a stronger spacing could remove the obstruction.
Indeed, the actual law itself has inward sum 1/10 and spacing 9/10,
for which this same staircase expectation is -1/2. That check is retained
as an adversarial control against an overbroad impossibility claim.

## Consequence for shortening

Simply replacing the generic count proof by the new central staircase
cannot remove its pages: coarse spacing loses too much at low n. There is
no proved future page saving. A genuine alternative must strengthen the
spacing from already acquired restrictions or use a different payoff.
The proposed next bounded test keeps separate quartic CDF majorants for
each of the six actual counts, evaluated using one common conditional
moment pair. That avoids dividing by a small spacing and is a new proof
problem, not a consequence of this obstruction.

The earlier v19 coefficient-audit attempt was also read. Its complete
analytic replacement measured 102 pages both before and after; its exact
algebra package stayed optional. This new task seeks a changed probability
argument, not another relocation of essential algebra into a checker.
