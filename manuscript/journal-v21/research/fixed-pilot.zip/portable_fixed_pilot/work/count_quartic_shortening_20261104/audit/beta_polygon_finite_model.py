"""Additive finite-n fourth-moment variant of the beta-polygon pilot."""
from beta_polygon_model import base,need,cfg,N,P,Q,K,UPPER,BLO,BHI,V,PLANES,VERTICES,GAMMAS
from fractions import Fraction as F
from math import comb
def rows():
    out=[]
    for x,y in VERTICES:
      for g0,g1 in GAMMAS:
        rr=[]
        for j in range(N+1):
            t=(N-j)*x/Q+j*y/P
            m3=(N-j)*g0*x/Q+j*g1*y/P
            # Cauchy for the N individual variances: sum v_i^2>=t^2/N.
            m4=(N-j)*g0*g0*x/Q+j*g1*g1*y/P+3*F(N-1,N)*t*t
            moments=[F(1),F(0),t,m3,m4]
            shifted=[sum(F(comb(d,i))*(j-K)**(d-i)*moments[i]for i in range(d+1))for d in range(5)]
            rr.extend(base.MASS[j]*z for z in shifted)
        out.append(rr)
    return out
def accept(qs):
    need(type(qs)is list and len(qs)==N+1,'six exact quartics');qs=[list(map(F,q))for q in qs]
    for q in qs:
        need(len(q)==5 and q[4]>0,'positive leading quartic')
        base.sturm.positive(base.compact_ray(q,-1,1));base.sturm.positive(base.compact_ray(q,1,0))
    maximum=max(sum(a*b for a,b in zip(rr,sum(qs,[])))for rr in rows())
    margin=base.target(UPPER)-maximum;need(margin>0,'strict finite-n beta-polygon bound')
    return dict(status='PASS_EXACT_FIXED_P_PHASE_FULL_NOISE_BETA_FINITE_MOMENT',n=N,p=str(P),k=K,u='0',noise=['0',str(UPPER)],
       beta=list(map(str,(BLO,BHI))),vertices=[[str(x),str(y)]for x,y in VERTICES],moment_combinations=9,
       gates=len(rows()),fourth_variance_factor=str(F(N-1,N)),margin=str(margin),scope='Fixed p and phase only; original full noise and acquired beta intervals retained. No complete probability/phase row claim.')
