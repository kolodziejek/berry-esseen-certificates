"""Exact same-pair obstruction to using the original coarse n5 spacing.

This is not a counterexample to Berry--Esseen or to any original count proof.
It does not assert that the law satisfies a contact/attainment hypothesis.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import hashlib, importlib.util, json, sys

if not __debug__ or sys.flags.optimize:
    raise RuntimeError('ordinary exact Python required')
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
CONTRACT='work/cutoff5_20261020/root/count5_prepare_v1/gamma16_01/n5/BN/panel038/contract.json'
CONTRACT_SHA='2b3f626ba3a9e954e4700bf206cf7a364f44958bb901b463198249dda2f37e48'
SELECTION='work/cutoff5_20261020/root/final_composition_v2/C5_CHECKED.json'
NATIVE='work/finite_left_replacement_20261104/audit/native/finite_binomial_core.py'
NATIVE_SHA='939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f'
PINS={}
def need(x,msg):
    if not x: raise ValueError(msg)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
    d={}
    for k,v in pairs:
        need(k not in d,'duplicate key');d[k]=v
    return d
def read(rel,pin=None):
    p=ROOT/rel;h=sha(p)
    need(pin is None or h==pin,'fixed source '+rel);PINS[rel]=h
    return json.loads(p.read_text(),object_pairs_hook=unique)
need(sha(ROOT/NATIVE)==NATIVE_SHA,'unchanged reviewed exact Gaussian source')
PINS[NATIVE]=NATIVE_SHA
spec=importlib.util.spec_from_file_location('native_gaussian',ROOT/NATIVE)
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)

class I:
    def __init__(self,l,h=None):
        self.l=F(l);self.h=F(l if h is None else h);need(self.l<=self.h,'interval')
    def __add__(self,b):
        b=cast(b);return I(self.l+b.l,self.h+b.h)
    __radd__=__add__
    def __neg__(self):return I(-self.h,-self.l)
    def __sub__(self,b):return self+-cast(b)
    def __rsub__(self,b):return cast(b)+-self
    def __mul__(self,b):
        b=cast(b);v=[x*y for x in(self.l,self.h)for y in(b.l,b.h)];return I(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=cast(b);need(b.l>0,'positive divisor');return self*I(1/b.h,1/b.l)
    def __pow__(self,n):
        need(type(n)is int and n>=0,'power')
        if n==0:return I(1)
        if n%2:return I(self.l**n,self.h**n)
        return I(0 if self.l<=0<=self.h else min(self.l**n,self.h**n),max(self.l**n,self.h**n))
    def strings(self):return list(map(str,(self.l,self.h)))
def cast(x):return x if isinstance(x,I)else I(x)
def sqrt(x):return I(*native.root(F(x)))
def normal(num,den):
    a,b=native.root(F(den));num=F(num)
    if num<0:return 1-normal(-num,den)
    l=num/b;h=num/a;zl=l.numerator*native.Z//l.denominator
    zh=-((-h.numerator*native.Z)//h.denominator)
    need(0<=zl<=zh<=5*native.Z,'normal compact range')
    return I(F(native.positive_cdf(zl)[0],native.S),F(native.positive_cdf(zh)[1],native.S))
def convolution(law,n):
    dist={F(0):F(1)}
    for _ in range(n):
        nxt={}
        for x,p in dist.items():
            for y,q in law.items():nxt[x+y]=nxt.get(x+y,F(0))+p*q
        dist=nxt
    need(sum(dist.values())==1,'complete actual product law');return dist
def ceiling(b,x,label):
    x=cast(x);need(x.h<=F(b),label)
def containing(b,x,label):
    x=cast(x);need(F(b[0])<=x.l<=x.h<=F(b[1]),label)

def main(out):
    selection=read(SELECTION)
    need(selection['files_sha256'][CONTRACT]==CONTRACT_SHA,'selected original n5 contract')
    contracts=[]
    for rel,h in selection['files_sha256'].items():
        if '/n5/' not in rel or not rel.endswith('/contract.json'):continue
        z=read(rel,h);need(len(z['rows'])==1,'one selected row');r=z['rows'][0]
        accepted_path=str(Path(rel).parent/'COUNT_ACCEPTED.json')
        acc=read(accepted_path,selection['files_sha256'][accepted_path])
        contracts.append(dict(path=rel,sha256=h,p=r['p'],inward=r['acquired_inward_upper'],
                              d0=r['d0'],n=r['n'],leaves=acc['statistics']['leaves']))
    need(len(contracts)==295,'all selected n5 contracts')
    need(max(x['leaves']for x in contracts)==822,'hardest selected leaf count')
    chosen=next(x for x in contracts if x['path']==CONTRACT)
    need(chosen['leaves']==822,'selected hardest row')
    cfg=read(CONTRACT,CONTRACT_SHA)['rows'][0]
    n=5;p=F(77,200);q=1-p;a=F(1,10);k=2;u=F(0)
    law={-p-a:q/2,-p+a:q/2,q:p}
    # Raw X-coordinate: X=(B-p+U)/sqrt(w), U0=+/-a, U1=0.
    v=p*q;s=q*a*a;lam=n*s;w=v+s;rootw=sqrt(w)
    need(sum(law.values())==1 and sum(x*m for x,m in law.items())==0,'centered probability law')
    need(sum(x*x*m for x,m in law.items())==w,'exact variance')
    R=sum(abs(x)**3*m for x,m in law.items());G=sum(x**3*m for x,m in law.items())
    rho=I(R)/(w*rootw);gamma=I(G)/(w*rootw)
    beta=I(sum(x*abs(x)*m for x,m in law.items())/w);mean=I(v)/rootw
    pts=sorted(law);Jraw=sum(sum(x*law[x]for x in pts[j+1:])*(pts[j+1]-pts[j])**2 for j in range(2))
    D=((3+sqrt(10))*R-G-3*Jraw)/(w*rootw)
    delta=F(k)-n*p;H=I(delta+u)/rootw
    containing(cfg['p'],p,'probability');containing([cfg['rho_lower'],cfg['rho_upper']],rho,'rho')
    containing(cfg['acquired_beta'],beta,'beta');containing(cfg['acquired_gamma'],gamma,'gamma')
    containing(cfg['acquired_mean'],mean,'mean')
    ceiling(cfg['D'],D,'actual physical gap defect')
    ceiling(cfg['acquired_lambda_upper'],lam,'noise');ceiling(cfg['acquired_scale_upper'],rootw,'scale')
    ceiling(cfg['Hplus'],H,'positive threshold');need(H.l>=-F(cfg['Hminus']),'negative threshold')
    ceiling(cfg['radius_minus'],I(p+a)/rootw,'negative support radius')
    ceiling(cfg['radius_plus'],I(q)/rootw,'positive support radius')
    need(F(cfg['sign_premise']['negative_endpoint_lower'])<((I(p-a)/rootw).l),'negative inner endpoint')
    need(F(cfg['sign_premise']['positive_endpoint_lower'])<((I(q)/rootw).l),'positive inner endpoint')
    ceiling(cfg['outer0'],a,'outward0');ceiling(cfg['outer1'],0,'outward1')
    ceiling(cfg['acquired_inward_upper'],a,'inward')
    need((I(1-a)/rootw).l>=F(cfg['geometry_gap_lower']),'actual physical central gap')
    need(a/F(cfg['d0'])+lam/F(cfg['Lambda'])<1,'one original joint intercept budget')
    charge=F(cfg['binary_charge'])+F(cfg['gap_charge'])*a+F(cfg['noise_charge'])*lam
    need(charge<=D.l,'actual common physical defect dominates exported charge')
    qvals=[I(F(z['A']))+F(z['Fplus'])*H-F(z['Qbudget'])*H**2 for z in cfg['quadratics']]
    need(F(997,15000)*n*D.h<max(z.l for z in qvals),'same phase-dependent resource upper bound')
    c=1-F(cfg['acquired_inward_upper']);need(c>0,'licensed positive coarse spacing')
    masses=[F(comb(n,j))*p**j*q**(n-j)for j in range(n+1)]
    ratio=max(masses[j]/masses[k]for j in range(k+1,n+1));need(ratio==F(77,123),'exact all legal incoming mass ratio')
    W=convolution({-a:F(1,2),a:F(1,2)},n-k)
    def payoff(x):return -int(x>u)+ratio*max(0,(u-x)//c)
    psi=sum(prob*payoff(x)for x,prob in W.items());need(psi==F(31,246),'exact staircase expectation')
    cdfb=sum(masses[:k+1]);phi=normal(delta+u,n*w)
    proxy=sqrt(n)*(cdfb+masses[k]*psi-phi)/rho
    actualdist=convolution(law,n);cdf=sum(prob for x,prob in actualdist.items()if x<=delta+u)
    actual=sqrt(n)*(cdf-phi)/rho
    cehi=(3+sqrt(10).h)*native.PHI_HI/6
    need(proxy.l>F(456,1000)>F(41,100)>cehi,'exact obstruction with margin')
    need(F(17,1000)<actual.l<actual.h<F(18,1000),'actual score is far below target')
    # Adversarial checks: actual spacing is much stronger; the coarse
    # obstruction is not an assertion that every coupled payoff fails.
    truec=1-a
    psi_true=sum(prob*(-int(x>u)+ratio*max(0,(u-x)//truec))for x,prob in W.items())
    need(psi_true==-F(1,2),'stronger actual spacing resolves this payoff loss')
    need(F(cfg['acquired_inward_upper'])>min(p,q),'current strict-gap API guard fails')
    need(F(cfg['d0'])>1,'affine intercept cannot be substituted as spacing')
    # Atoms at every staircase knot use the higher, closed incoming step;
    # the outgoing indicator remains strict at zero.
    need(payoff(0)==0 and payoff(-c)==ratio and payoff(c)==-1,'closed-event atom directions')
    need(normal(-1,5).l==1-normal(1,5).h,'signed normal orientation')
    out.mkdir(exist_ok=False)
    summary={'status':'PASS_EXACT_COARSE_STAIRCASE_OBSTRUCTION_ON_SELECTED_N5_ROW',
      'mathematical_status':'Locally derived and checked obstruction to the coarse exported-spacing payoff; no contact/attainment or main-theorem counterexample claim.',
      'execution_status':'Fresh exact rational finite-law and Gaussian-enclosure checks.',
      'contract':CONTRACT,'contract_sha256':CONTRACT_SHA,'n':n,'p':str(p),'U0':['-1/10','1/10'],'U0_probabilities':['1/2','1/2'],'U1':['0'],
      'k':k,'u':str(u),'c':str(c),'R0':str(ratio),'psi_expectation':str(psi),
      'rho':rho.strings(),'gamma':gamma.strings(),'beta':beta.strings(),'mean':mean.strings(),
      'D':D.strings(),'lambda':str(lam),'H':H.strings(),'actual_cdf':str(cdf),
      'proxy_score':proxy.strings(),'actual_score':actual.strings(),'CE_upper':str(cehi),
      'stronger_true_spacing':str(truec),'stronger_payoff_expectation':str(psi_true),
      'all_selected_contracts':len(contracts),'fully_below_half':sum(F(x['p'][1])<=F(1,2)for x in contracts),
      'fully_above_half':sum(F(x['p'][0])>=F(1,2)for x in contracts),
      'strict_min_pq_guard':sum(F(x['inward'])<min(F(x['p'][0]),1-F(x['p'][1]))for x in contracts),
      'source_sha256':PINS,'limitations':['No new acquisition replay.','No claim that the example is a maximizing/contact law.','No failure of the original count forests.','No obstruction to a stronger spacing derived from original same-law restrictions.']}
    (out/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
    (out/'CONTRACT_CENSUS.json').write_text(json.dumps(contracts,indent=2)+'\n')
    print(json.dumps({k:summary[k]for k in('status','n','c','psi_expectation','all_selected_contracts','fully_below_half','fully_above_half','strict_min_pq_guard')}))
    print('proxy > 0.456; actual score in (0.017,0.018); CE < 0.410')
if __name__=='__main__':main(Path(sys.argv[1]).resolve())
