"""Bounded positive-template discovery; global proof is explicit factorization."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import numpy as np
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import mixture_model as m

def propose(upper):
    scales=[F(j,100)for j in range(0,101)]+[F(j,20)for j in range(21,81)]
    templates=[[F(1),-a,-a*a/2,F(0),a**4/2]for a in scales]
    count=len(scales);r=m.rows(upper);tar=float(m.target(upper))
    lhs=[]
    for rr in r:
        lhs.append([float(sum(rr[5*j+d]*q[d]for d in range(5)))for j in range(6)for q in templates]+[1.])
    eq=np.zeros((6,6*count+1))
    for j in range(6):eq[j,j*count:(j+1)*count]=1
    ans=linprog([0.]*(6*count)+[-1.],A_ub=lhs,b_ub=[tar]*len(r),A_eq=eq,b_eq=[1.]*6,
                bounds=[(0,1)]*(6*count)+[(-100,100)],method='highs')
    if not ans.success:return {'status':'DISCOVERY_FAILED','reason':ans.message}
    if ans.x[-1]<=1e-6:return {'status':'NO_POSITIVE_TEMPLATE_MARGIN','margin':float(ans.x[-1])}
    exact=[];data=[]
    for j in range(6):
        weights=[max(0,round(x*10**10))for x in ans.x[j*count:(j+1)*count]]
        total=sum(weights);m.need(total>0,'nonempty template mixture')
        weights=[F(x,total)for x in weights]
        q=[sum(w*t[d]for w,t in zip(weights,templates))for d in range(5)]
        # Tiny positive mixture with the a=1 template, then strict padding.
        eps=F(1,10**8);q=[(1-eps)*x+eps*y for x,y in zip(q,[1,-1,F(-1,2),0,F(1,2)])]
        q[0]+=F(1,10**7);exact.append(q)
        data.append([[str(a),str(w)]for a,w in zip(scales,weights)if w])
    try:checked=m.accept(exact,upper)
    except ValueError as e:return {'status':'EXACT_TEMPLATE_REJECTED','reason':str(e),'margin':float(ans.x[-1]),'q':[[str(x)for x in q]for q in exact]}
    return {'status':'PASS_EXACT_TEMPLATE_PILOT','margin':float(ans.x[-1]),'q':[[str(x)for x in q]for q in exact],'templates':data,'result':checked}

if __name__=='__main__':
    out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False);rows=[]
    for upper in(F(m.cfg['acquired_lambda_upper']),F(123,4000)):
        r=propose(upper);r['upper']=str(upper);rows.append(r)
        print(json.dumps({k:v for k,v in r.items()if k not in('q','templates')}),flush=True)
    (out/'DISCOVERY.json').write_text(json.dumps(rows,indent=2)+'\n')
