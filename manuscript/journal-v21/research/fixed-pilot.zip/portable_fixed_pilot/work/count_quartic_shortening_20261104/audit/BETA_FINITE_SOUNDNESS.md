# Full-noise beta-polygon extension at the fixed pilot point

This is an additive result. The first accepted small-noise pilot and its
sources remain unchanged. The present result covers n=5, p=77/200, k=2,
u=0 and the entire original acquired noise interval [0,7687/25000], with
the original signed beta interval [-15293/500000,307221/1000000]. It does
not cover a probability or phase interval, let alone all n=5 laws.

The support and normalization hypotheses, exact six-count CDF identity,
global quartic conditions and interpretation of the moment extrema are
those in MIXTURE_SOUNDNESS.md. Only the common variance domain and one
finite-sample fourth-moment term are strengthened.

Put x=q*s0, y=p*s1, v=pq. The exact signed second moment is

    beta = [v(q-p)-x+y]/[v+x+y].

The denominator is positive. Hence the acquired bounds b_l<=beta<=b_u
give the two rational linear inequalities

    -(1+b_u)x+(1-b_u)y <= v(b_u-(q-p)),
      (1+b_l)x-(1-b_l)y <= v((q-p)-b_l).

Intersect these with x>=0, y>=0 and x+y<=Lambda/5. This compact polygon
does not depend on the moments or support endpoints eliminated later.
Its complete exact vertex set is

    (0,0),
    (0,731360091/27711160000),
    (24319135109/2000000000000,98672864891/2000000000000),
    (7687/125000,0).

For fixed x,y, the common skew/inward argument applies separately to
both conditional classes. It leaves three choices for gamma0 and three
for gamma1, with one common choice shared by all six counts:

    gamma0 in {-A0,0,min(d,p)},
    gamma1 in { A1,0,-min(d,q)}.

As in the preceding proof, this is an extremal evaluation of the upper
moment expression, not the false actual-law inequality E U_i⁴<=gamma_i²*s_i.
The support fourth-moment term at each extremal evaluation is gamma_i²*s_i.

For the jth conditional sum, write t_j=(5-j)x/q+j*y/p. Its exact fourth
moment contains the correction -3((5-j)s0²+j*s1²). Cauchy applied to the
five individual variances gives

    (5-j)s0²+j*s1² >= t_j²/5.

Thus, after the support endpoint evaluations, the valid upper fourth
moment is

    (5-j)gamma0²*x/q+j*gamma1²*y/p + 3*(4/5)*t_j².

For a fixed pair (gamma0,gamma1), the complete mixture of quartic
expectations is therefore convex in (x,y): the non-affine part is a
sum of nonnegative multiples of squares of affine forms t_j. Its maximum
on the polygon occurs at a vertex. The four vertices and nine common
skew pairs give exactly 36 tests. The Gaussian target remains the lower
bound at Lambda, since k-np=3/40>0. Both zero-variance classes are handled
without division by their variance.

The exact negative diagonal fourth-moment correction itself was not
retained in a purported convex function. Its mixed-count Hessian can be
indefinite. The Cauchy replacement above is deliberately chosen to retain
a proved convex quadratic while recovering a useful factor 4/5.

The same twelve global CDF ray tests and exact scalar target as before
then imply a strict positive-score bound below C_E. The selected thirty
coefficients are in
`runs/count_quartic_shortening_20261104/audit_beta_finite_accept01/accepted/proof_object.json`.
The exact CDF margin is greater than .00919.

Separate stdlib-only acceptance returned zero in 0.122 seconds, with
stable sources. Twelve corrupt objects reject, 441 independent exact
grid checks verify the beta-halfplane algebra, and 23 actual conditional
law pairs give 138 full-convolution translated-expectation checks and four
exact event collisions. The grid checks support the implementation audit;
the displayed algebra proves the continuous beta equivalence.

The less accurate beta-only variant had a negative floating discovery
margin and remains preserved at `audit_beta_discovery01`. This is not an
exact impossibility certificate. The finite-Cauchy variant is the accepted
one. The first small-noise result remains a separate earlier checkpoint.

An independent derivation by the separate analytic reviewer is recorded
under `work/earlier_local_comparison_20261104/integration/review_beta_polygon/`.
Agreement is not a proof; the complete argument used here is supplied above
and in MIXTURE_SOUNDNESS.md. The next genuine obligation is a closed
probability/phase cover with original source bindings. No manuscript
deletion, complete-row result or page saving follows from this fixed-point
pilot alone.
