"""Bounded discovery with whole-ray Bernstein constraints, exact Sturm admission."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import mixture_model as m

def propose(upper):
    lhs=[list(map(float,r))+[1.]for r in m.rows(upper)]
    rhs=[float(m.target(upper))]*len(lhs);base=m.sturm.base
    for j in range(6):
      for sign,sub in((-1,1),(1,0)):
        targets=[m.compact_ray([int(k==d)for k in range(5)],sign,0)for d in range(5)]
        constant=m.compact_ray([sub,0,0,0,0],sign,0)
        for a in range(32):
          co=[base.bernstein(base.affine(p,F(a,32),F(1,32)))for p in targets]
          cc=base.bernstein(base.affine(constant,F(a,32),F(1,32)))
          for k in range(5):
            row=[0.]*31
            for d in range(5):row[5*j+d]=-float(co[d][k])
            lhs.append(row);rhs.append(-float(cc[k])-1e-9)
    ans=linprog([0.]*30+[-1.],A_ub=lhs,b_ub=rhs,
      bounds=[((-500,500)if d%5<4 else(1e-8,500))for d in range(30)]+[(-100,100)],method='highs',
      options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    if not ans.success:return {'status':'DISCOVERY_FAILED','message':ans.message}
    if ans.x[-1]<=1e-5:return {'status':'NO_POSITIVE_BERNSTEIN_DISCOVERY_MARGIN','margin':float(ans.x[-1])}
    exact=[[F(round(x*10**10),10**10)for x in ans.x[5*j:5*j+5]]for j in range(6)]
    for q in exact:q[0]+=F(1,10**6);q[4]+=F(1,10**7)
    try:r=m.accept(exact,upper)
    except ValueError as e:return {'status':'EXACT_REJECTED','reason':str(e),'margin':float(ans.x[-1]),'q':[[str(x)for x in q]for q in exact]}
    return {'status':'PASS_EXACT_SIX_COUNT_PILOT','margin':float(ans.x[-1]),'q':[[str(x)for x in q]for q in exact],'result':r}

if __name__=='__main__':
    out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False);rows=[]
    for upper in(F(m.cfg['acquired_lambda_upper']),F(123,4000)):
        r=propose(upper);r['upper']=str(upper);rows.append(r)
        print(json.dumps({k:v for k,v in r.items()if k!='q'}),flush=True)
    (out/'DISCOVERY.json').write_text(json.dumps(rows,indent=2)+'\n')
