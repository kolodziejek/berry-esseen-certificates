"""Fixed-p/phase, whole-noise-interval six-count quartic pilot.

The domain is deliberately stated below. No full probability row is accepted.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import hashlib,importlib.util,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(HERE))
import check_obstruction as old
need=old.need
path=ROOT/'work/finite_left_replacement_20261104/audit/quartic_sturm.py'
need(hashlib.sha256(path.read_bytes()).hexdigest()=='1f815ccb23692f78be98691a76a5fe0605f8995abdab5d9a3964f1625a4c2617','fixed exact ray reader')
spec=importlib.util.spec_from_file_location('strict_ray_reader',path)
sturm=importlib.util.module_from_spec(spec);spec.loader.exec_module(sturm)
cfg=old.read(old.CONTRACT,old.CONTRACT_SHA)['rows'][0]
N=5;P=F(77,200);Q=1-P;K=2;U=F(0)
A0=F(cfg['outer0']);A1=F(cfg['outer1']);D=F(cfg['acquired_inward_upper'])
need(0<P<1 and 0<D<1,'actual sign-conditioned pilot')
CORNERS=((0,-A0),(0,F(0)),(0,min(D,P)),(1,A1),(1,F(0)),(1,-min(D,Q)))
MASS=[F(comb(N,j))*P**j*Q**(N-j)for j in range(N+1)]

def rows(upper):
    upper=F(upper);need(0<upper<=F(cfg['acquired_lambda_upper']),'noise interval within actual row')
    result=[]
    for lam in(F(0),upper):
        for alpha,gamma in CORNERS:
            record=[]
            for j in range(N+1):
                t=lam*(F(N-j,N)/Q if alpha==0 else F(j,N)/P)
                moments=[F(1),F(0),t,gamma*t,gamma*gamma*t+3*t*t]
                shifted=[sum(F(comb(d,i))*(j-K)**(d-i)*moments[i]for i in range(d+1))for d in range(5)]
                record.extend(MASS[j]*x for x in shifted)
            result.append(record)
    return result

def target(upper):
    phi=old.normal(F(K)-N*P,N*P*Q+F(upper))
    return phi.l+old.native.CE_LO*F(cfg['rho_lower'])/old.sqrt(N).h

def compact_ray(q,sign,subtract):
    # z=sign*t/(1-t); multiply by (1-t)^4, t in [0,1].
    q=list(map(F,q));q[0]-=F(subtract);co=[F(0)]*5
    for j,a in enumerate(q):
        for l in range(5-j):co[j+l]+=a*sign**j*F(comb(4-j,l))*(-1)**l
    return co

def accept(qs,upper):
    need(type(qs)is list and len(qs)==6,'all six actual counts')
    qs=[list(map(F,q))for q in qs]
    for q in qs:
        need(len(q)==5 and q[4]>0,'positive-leading quartic')
        sturm.positive(compact_ray(q,-1,1))
        sturm.positive(compact_ray(q,1,0))
    flat=sum(qs,[]);bound=max(sum(a*b for a,b in zip(r,flat))for r in rows(upper))
    margin=target(upper)-bound;need(margin>0,'strict mixture CDF bound')
    return dict(status='PASS_EXACT_SIX_COUNT_FIXED_P_PHASE_NOISE_INTERVAL',n=N,p=str(P),k=K,u='0',
       noise=['0',str(F(upper))],moment_corners=6,noise_endpoints=2,global_rays=12,
       margin=str(margin),scope='All sign-conditioned marginals in the selected scalar support/rho domain at fixed p=77/200 and phase u=0, noise in the displayed closed interval. Not a full p/phase row.')
