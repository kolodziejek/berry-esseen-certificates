"""Independent exact replay/control entrypoint for the full-noise pilot."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];sys.path.insert(0,str(HERE))
import beta_polygon_finite_model as m
need=m.need
DISCOVERY=ROOT/'runs/count_quartic_shortening_20261104/audit_beta_finite_discovery01/objects/DISCOVERY.json'
def admit(z):
    need(type(z)is dict and set(z)=={'n','p','k','u','noise','beta','q'},'fixed full-noise schema')
    need(type(z['n'])is int and z['n']==5 and type(z['k'])is int and z['k']==2,'actual count/index')
    need(z['p']=='77/200'and z['u']=='0'and z['noise']==['0','7687/25000']and z['beta']==list(map(str,(m.BLO,m.BHI))),'exact acquired pilot scope')
    return m.accept(z['q'])
def main(out):
    found=json.loads(DISCOVERY.read_text(),object_pairs_hook=m.base.old.unique)
    obj=dict(n=5,p='77/200',k=2,u='0',noise=['0','7687/25000'],beta=list(map(str,(m.BLO,m.BHI))),q=found['q'])
    r=admit(obj);qs=[list(map(F,q))for q in obj['q']];controls=[]
    changes=[('missing count',lambda z:z['q'].pop()),('wrong index',lambda z:z.update(n=6)),
      ('boolean count',lambda z:z.update(k=True)),('wrong probability',lambda z:z.update(p='39/100')),
      ('different phase',lambda z:z.update(u='1/100')),
      ('larger noise',lambda z:z.update(noise=['0','1'])),
      ('wider beta',lambda z:z.update(beta=['-1','1'])),
      ('false leading term',lambda z:z['q'][0].__setitem__(4,'-1')),
      ('false closed endpoint',lambda z:z['q'][2].__setitem__(0,'0')),
      ('false ray',lambda z:z['q'][4].__setitem__(0,str(F(z['q'][4][0])-2))),
      ('candidate vertices',lambda z:z.update(vertices=[])),
      ('candidate success',lambda z:z.update(status='PASS'))]
    for name,change in changes:
        bad=json.loads(json.dumps(obj));change(bad)
        try:admit(bad)
        except(ValueError,KeyError,TypeError):controls.append(name)
        else:raise ValueError('bad object admitted '+name)
    # Independently check beta halfplane algebra at a grid, without using
    # the vertex generator or constructing a success fixture.
    beta_checks=0
    for i in range(21):
      for j in range(21):
        x=F(i,300);y=F(j,300)
        beta=(m.V*(m.Q-m.P)-x+y)/(m.V+x+y)
        lhs=all(a*x+b*y<=c for a,b,c in m.PLANES)
        rhs=x>=0 and y>=0 and x+y<=m.UPPER/m.N and m.BLO<=beta<=m.BHI
        need(lhs==rhs,'independent signed beta-domain equivalence');beta_checks+=1
    def centered(a,b):return{-a:b/(a+b),b:a/(a+b)}
    zero={F(0):F(1)}
    choices0=[zero,centered(F(1,10),F(1,10)),centered(F(1,2),F(1,1000)),centered(F(3,5),F(1,10)),centered(F(1,10),F(3,10))]
    choices1=[zero,centered(F(1,10),F(1,10)),centered(F(1,1000),F(1,2)),centered(F(1,10),F(7,10)),centered(F(3,10),F(1,10))]
    examples=0;identities=0;collisions=0;maximum=max(sum(a*b for a,b in zip(row,sum(qs,[])))for row in m.rows())
    for l0,l1 in product(choices0,choices1):
        s0=sum(a*a*b for a,b in l0.items());s1=sum(a*a*b for a,b in l1.items());x=m.Q*s0;y=m.P*s1
        if not all(a*x+b*y<=c for a,b,c in m.PLANES):continue
        examples+=1;weighted=F(0)
        for j,q in enumerate(qs):
            d0=m.base.old.convolution(l0,5-j);d1=m.base.old.convolution(l1,j);dist={}
            for a,b in d0.items():
                for c,d in d1.items():dist[a+c]=dist.get(a+c,F(0))+b*d
            t=(5-j)*s0+j*s1
            m3=(5-j)*sum(a**3*b for a,b in l0.items())+j*sum(a**3*b for a,b in l1.items())
            m4=(5-j)*sum(a**4*b for a,b in l0.items())+j*sum(a**4*b for a,b in l1.items())+3*t*t-3*((5-j)*s0*s0+j*s1*s1)
            need(m4==sum(a**4*b for a,b in dist.items()),'independent actual fourth moment')
            need((5-j)*s0*s0+j*s1*s1>=t*t/5,'finite-n Cauchy correction')
            moments=[F(1),F(0),t,m3,m4]
            shifted=[sum(F(__import__('math').comb(d,i))*(j-2)**(d-i)*moments[i]for i in range(d+1))for d in range(5)]
            direct=sum(prob*sum(q[d]*(a+j-2)**d for d in range(5))for a,prob in dist.items())
            need(direct==sum(a*b for a,b in zip(q,shifted)),'actual translated quartic identity')
            need(sum(prob for a,prob in dist.items()if a<=2-j)<=direct,'actual closed event majorant')
            collisions+=int(F(2-j)in dist);identities+=1;weighted+=m.base.MASS[j]*direct
        need(weighted<=maximum,'same-pair mixture below complete shared vertex bound')
    out.mkdir(exist_ok=False);(out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n')
    r.update(negative_controls=controls,beta_halfplane_checks=beta_checks,actual_pairs=examples,direct_expectation_checks=identities,event_collisions=collisions,
      discovery_sha256=hashlib.sha256(DISCOVERY.read_bytes()).hexdigest(),
      source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(HERE/'mixture_model.py',HERE/'beta_polygon_model.py',HERE/'beta_polygon_finite_model.py',Path(__file__))})
    (out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
if __name__=='__main__':main(Path(sys.argv[1]).resolve())
