"""Exact explicit-law calculation only; does not scan295 historical contracts."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import importlib.util,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from verify_package import verify,need
def main(out):
    inventory=verify(HERE);out=out.resolve()
    need(not out.exists()and not out.is_relative_to(HERE),'new external output')
    path=HERE/'work/count_quartic_shortening_20261104/audit/check_obstruction.py'
    spec=importlib.util.spec_from_file_location('preserved_obstruction_functions',path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    cfg=m.read(m.CONTRACT,m.CONTRACT_SHA)['rows'][0]
    n=5;p=F(77,200);q=1-p;a=F(1,10);k=2
    law={-p-a:q/2,-p+a:q/2,q:p};w=p*q+q*a*a
    need(sum(law.values())==1 and sum(x*t for x,t in law.items())==0,'centered actual law')
    need(sum(x*x*t for x,t in law.items())==w==F(9717,40000),'actual variance')
    W=m.convolution({-a:F(1,2),a:F(1,2)},n-k)
    mass=[F(comb(n,j))*p**j*q**(n-j)for j in range(n+1)]
    R=max(mass[j]/mass[k]for j in range(k+1,n+1));c=1-F(cfg['acquired_inward_upper'])
    need(c==F(28467,500000)and R==F(77,123),'actual selected coarse-spacing inputs')
    psi=sum(prob*(-int(z>0)+R*max(0,(-z)//c))for z,prob in W.items())
    need(psi==F(31,246),'exact coarse staircase expectation')
    delta=F(k)-n*p;dist=m.convolution(law,n)
    cdf=sum(prob for z,prob in dist.items()if z<=delta)
    need(cdf==F(171439815843,320000000000),'actual closed CDF')
    rho=m.I(sum(abs(z)**3*prob for z,prob in law.items()))/(w*m.sqrt(w))
    normal=m.normal(delta,n*w)
    proxy=m.sqrt(n)*(sum(mass[:k+1])+mass[k]*psi-normal)/rho
    score=m.sqrt(n)*(cdf-normal)/rho
    need(proxy.l>F(456,1000)and F(17,1000)<score.l<score.h<F(18,1000),'rigorous coarse proxy and actual score')
    truepsi=sum(prob*(-int(z>0)+R*max(0,(-z)//F(9,10)))for z,prob in W.items())
    need(truepsi==-F(1,2),'stronger actual spacing resolves the coarse loss')
    need(verify(HERE)==inventory,'unchanged package')
    out.mkdir(parents=True,exist_ok=False)
    result=dict(status='PASS_EXACT_EXPLICIT_LAW_CALCULATION',n=n,p=str(p),k=k,u='0',
        law={str(x):str(t)for x,t in law.items()},variance=str(w),cdf=str(cdf),
        coarse_spacing=str(c),coarse_payoff=str(psi),proxy=proxy.strings(),actual_score=score.strings(),
        actual_spacing='9/10',actual_spacing_payoff=str(truepsi),
        scope='Explicit-law coarse-spacing obstruction only; no295-contract scan, contact/attainment claim, or Berry-Esseen counterexample',inventory=inventory)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    need(len(sys.argv)==2,'one new external output directory');main(Path(sys.argv[1]))
