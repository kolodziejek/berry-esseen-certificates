"""Run the unchanged fixed-p/full-noise acceptor in a fresh external output."""
from pathlib import Path
import json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from verify_package import verify,need,digest
def main(out):
    before=verify(HERE);out=out.resolve()
    need(not out.exists()and not out.is_relative_to(HERE),'new output outside immutable package')
    out.mkdir(parents=True,exist_ok=False)
    src=HERE/'work/count_quartic_shortening_20261104/audit/accept_beta_finite.py'
    argv=[sys.executable,'-I','-B','-S',str(src),str(out/'accepted')]
    t=time.monotonic()
    with(out/'stdout.txt').open('wb')as so,(out/'stderr.txt').open('wb')as se:
        p=subprocess.run(argv,cwd=out,stdout=so,stderr=se)
    record=dict(argv=argv,cwd=str(out),actual_returncode=p.returncode,elapsed_seconds=time.monotonic()-t,
        runtime=sys.version,executed_binary_sha256=digest(Path(sys.executable).resolve()),
        inventory_before=before,stdout_sha256=digest(out/'stdout.txt'),stderr_sha256=digest(out/'stderr.txt'),
        scope='Optional fixed n5,p77/200,k2,u0 full-noise exact acceptance only')
    (out/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n')
    need(p.returncode==0,'original exact acceptor failed; see actual capture')
    after=verify(HERE);need(after==before,'unchanged package inventory')
    old=HERE/'runs/count_quartic_shortening_20261104/audit_beta_finite_accept01/accepted'
    pins={}
    for name in ('RESULT.json','proof_object.json'):
        a=old/name;b=out/'accepted'/name
        need(b.is_file()and b.read_bytes()==a.read_bytes(),'complete exact original output equality '+name)
        pins[name]=digest(b)
    result=dict(status='PASS_RELOCATED_OPTIONAL_FIXED_PILOT',scope=record['scope'],
        selected_manuscript_dependency=False,complete_n5_row=False,inventory=after,outputs=pins,
        original_acceptor_unchanged=True,third_party_packages_required=False)
    (out/'REPLAY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    need(len(sys.argv)==2,'one new external output directory');main(Path(sys.argv[1]))
