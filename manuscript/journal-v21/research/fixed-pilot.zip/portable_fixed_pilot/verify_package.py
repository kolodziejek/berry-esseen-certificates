"""Byte inventory verification only; not a mathematical proof checker."""
from pathlib import Path,PurePosixPath
from hashlib import sha256
import json,stat,sys
def need(v,m):
    if not v:raise ValueError(m)
need(__debug__ and not sys.flags.optimize,'unoptimized Python required')
def unique(pairs):
    out={}
    for k,v in pairs:need(k not in out,'duplicate JSON key');out[k]=v
    return out
def digest(p):return sha256(p.read_bytes()).hexdigest()
def safe(name):
    need(type(name)is str and name and '\\'not in name and '\x00'not in name,'portable path')
    p=PurePosixPath(name)
    need(not p.is_absolute()and p.as_posix()==name and all(x not in ('','.','..')for x in p.parts),'relative normalized path')
    return p
def verify(root):
    root=Path(root).resolve();mp=root/'FILES.json'
    need(mp.is_file()and not mp.is_symlink(),'regular inventory')
    doc=json.loads(mp.read_text(),object_pairs_hook=unique)
    need(set(doc)=={'schema','scope','files'}and doc['schema']=='OPTIONAL_FIXED_PILOT_FILES_V1','fixed inventory schema')
    files=doc['files'];need(type(files)is dict and files and 'FILES.json'not in files,'noncircular inventory')
    observed=set()
    for p in root.rglob('*'):
        need(not p.is_symlink(),'no packaged symlinks')
        need(p.is_dir()or stat.S_ISREG(p.stat().st_mode),'regular package paths')
        if p.is_file():observed.add(p.relative_to(root).as_posix())
    need(observed==set(files)|{'FILES.json'},'exact complete package file set')
    for name,pin in files.items():
        safe(name);need(set(pin)=={'bytes','sha256'}and type(pin['bytes'])is int and pin['bytes']>=0,'file pin schema')
        need(type(pin['sha256'])is str and len(pin['sha256'])==64,'SHA256 pin')
        p=root/name;need(p.stat().st_size==pin['bytes']and digest(p)==pin['sha256'],'file identity '+name)
    return dict(files=len(files)+1,inventory_sha256=digest(mp))
