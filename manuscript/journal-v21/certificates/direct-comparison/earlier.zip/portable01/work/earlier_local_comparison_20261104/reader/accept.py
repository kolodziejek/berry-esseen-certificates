"""Fresh exact readback. --complete requires all737 unique acquired pairs."""
from pathlib import Path
import argparse,json,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import model as m
def sources():
    return {str(p.relative_to(m.ROOT)):m.digest(p)for p in sorted(HERE.iterdir())if p.is_file()and p.suffix in('.py','.json')}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('objects',type=Path);p.add_argument('output',type=Path);p.add_argument('--complete',action='store_true');a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);before=sources();start=time.monotonic()
    paths=[a.objects]if a.objects.is_file()else sorted(a.objects.rglob('proof_*.json'))
    m.need(paths,'explicit nonempty immutable proof object selection')
    pins={str(x):m.digest(x)for x in paths};seen=set();results=[]
    for path in paths:
        obj=m.cat.load(path);r=m.accept(obj);key=(r['family'],r['index'],r['n'])
        m.need(key not in seen,'unique actual family/index/n proof');seen.add(key);results.append(r)
        print('ADMITTED',r['job'],r['quartics'],r['excluded'],flush=True)
    if a.complete:m.need(seen==set(m.cat.CENSUS),'all737 actual pairs; no missing or extra cases')
    m.need(before==sources(),'unchanged reader sources');m.need(pins=={str(x):m.digest(x)for x in paths},'unchanged proof objects')
    totals={k:sum(r[k]for r in results)for k in('quartics','excluded','splits','score_coefficients')}
    result=dict(mathematical_status='exact direct-score implication for selected earlier acquired laws; acquisition/contact/strip ancestors retained',execution_status='fresh PASS',complete_737=a.complete,selected_pairs=len(results),results=results,totals=totals,source_manifest_sha256=m.cat.PIN,reader_sources=before,algebra_sources=m.PINS,proof_objects=pins,seconds=time.monotonic()-start)
    (a.output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in('results','proof_objects','reader_sources','algebra_sources')},indent=2))
if __name__=='__main__':main()
