"""Bounded adverse tests, including target identity and partial-cover rejection."""
from pathlib import Path
from fractions import Fraction as F
import copy,json,subprocess,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import model as m
from accept import sources
def main():
    inputs=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
    before=sources();objects=[m.cat.load(p)for p in sorted(inputs.glob('proof_*.json'))]
    m.need(len(objects)==5 and {x['family']for x in objects}==set(m.cat.SPECS),'five distinct pilot families')
    baseline=[m.accept(o)for o in objects];tested=[]
    def reject(label,fn):
        try:fn()
        except(ValueError,AssertionError,TypeError,KeyError,IndexError):tested.append(label)
        else:raise ValueError('negative control accepted: '+label)
    original=next(x for x in objects if x['family']=='positive39')
    leaf=next(j for j,x in enumerate(original['trees'])if 'q'in x['tree'])
    mutations={
      'null_exclusion':lambda o:o['trees'][leaf].update(tree={'excluded':None}),
      'invented_exclusion':lambda o:o['trees'][leaf].update(tree={'excluded':'joint_binary_budget'}),
      'missing_count':lambda o:o['trees'].pop(),
      'duplicate_count':lambda o:o['trees'].__setitem__(1,copy.deepcopy(o['trees'][0])),
      'reordered_count':lambda o:o['trees'].reverse(),
      'missing_phase':lambda o:o['trees'].__setitem__(leaf,dict(o['trees'][leaf],sign=0)),
      'bool_n':lambda o:o.update(n=True),
      'float_n':lambda o:o.update(n=39.0),
      'wrong_actual_n':lambda o:o.update(n=40),
      'wrong_family':lambda o:o.update(family='central40'),
      'wrong_acquired_source':lambda o:o.update(source_sha256='0'*64),
      'changed_p_interval':lambda o:o['gap'].update(p=['0','1']),
      'inflated_gap':lambda o:o['gap'].update(epsilon='1'),
      'float_gap_identity':lambda o:o['gap'].update(n=39.0),
      'wrong_native_cap':lambda o:o['gap'].update(score_cap='0'),
      'false_global_or_score_quartic':lambda o:o['trees'][leaf]['tree']['q'].__setitem__(0,'100'),
      'negative_q4':lambda o:o['trees'][leaf]['tree']['q'].__setitem__(4,'-1'),
      'float_q':lambda o:o['trees'][leaf]['tree']['q'].__setitem__(0,0.0),
      'extra_allowance_field':lambda o:o.update(K='0')}
    for label,change in mutations.items():
        bad=copy.deepcopy(original);change(bad);reject(label,lambda:m.accept(bad))
    reject('duplicate_JSON',lambda:json.loads('{"n":39,"n":40}',object_pairs_hook=m.cat.unique))
    # No inference of complete737 from a valid five-family pilot.
    cmd=[sys.executable,'-I','-B',str(HERE/'accept.py'),str(inputs),str(out/'incomplete_cover_rejection'),'--complete']
    r=subprocess.run(cmd,capture_output=True,text=True)
    (out/'incomplete_stdout.txt').write_text(r.stdout);(out/'incomplete_stderr.txt').write_text(r.stderr)
    m.need(r.returncode!=0 and 'all737 actual pairs'in r.stderr,'full real reader rejects incomplete census');tested.append('partial_cover_claim')
    duplicate=out/'duplicate_objects';duplicate.mkdir()
    for name in('proof_one.json','proof_two.json'):(duplicate/name).write_text(json.dumps(original)+'\n')
    cmd2=[sys.executable,'-I','-B',str(HERE/'accept.py'),str(duplicate),str(out/'duplicate_rejection')]
    r2=subprocess.run(cmd2,capture_output=True,text=True)
    (out/'duplicate_stdout.txt').write_text(r2.stdout);(out/'duplicate_stderr.txt').write_text(r2.stderr)
    m.need(r2.returncode!=0 and 'unique actual family/index/n'in r2.stderr,'full reader rejects duplicated job');tested.append('duplicate_pair_claim')
    # A rational actual conditional law with rho<rhoB, independent of these
    # acquired domains: p=.2, U0 in[-.1125,.09], U1=0, conditional centering.
    p=F(1,5);v=p*(1-p);a=F(9,100);b=F(9,80)
    weights=(a/(a+b),b/(a+b));values=(-b,a)
    m.need(sum(t*x for t,x in zip(weights,values))==0,'actual conditional centering')
    s0=sum(t*x*x for t,x in zip(weights,values));s=(1-p)*s0;w=v+s
    m.need(v==F(2,5)**2 and w==F(41,100)**2,'rational variance roots')
    third=sum(t*x**3 for t,x in zip(weights,values));G=3*p-third/s0
    rho=(v*(1-2*v)+s*G)/F(41,100)**3;rhob=(1-2*v)/F(2,5)
    m.need(rho<rhob,'actual signed cubic repair can be negative')
    allowance=F(19,4000);CE=F('.4097');T=CE+allowance
    m.need(T*(rho-rhob)==CE*(rho-rhob)+allowance*(rho-rhob),'full target identity')
    m.need(CE*(rho-rhob)>T*(rho-rhob),'CE-only gain omits a negative allowance correction')
    # Actual positive39 reader must multiply both endpoints by CE+K/39.
    k,sgn,cell=next(z for z in m.roots('positive39',209,39)if 'excluded'not in m.parameters('positive39',209,39,z[0],*z[2]))
    z=m.parameters('positive39',209,39,k,*cell);pl,pu,_,_=cell;vl=pl*(1-pl);wh=pu*(1-pu)+z['U']/39
    m.need(z['cglo']==m.lo((m.CELO+allowance)/(wh*m.sh(wh)))and z['cghi']==m.hi((m.CEHI+allowance)/(vl*m.sl(vl))),'both actual positive39 target multipliers')
    # Fresh critical panels requested before any full campaign.
    critical=[m.binary_gap.panel(n,209)for n in range(39,47)]
    m.need(all(F(x['epsilon'])>0 for x in critical),'all eight critical sharp binary gaps positive at current grid')
    m.need(before==sources(),'unchanged sources throughout controls')
    result=dict(execution_status='fresh PASS',scope='five-family pilot plus exact semantic controls; no full737 claim',baseline=baseline,negative_controls=tested,actual_signed_law=dict(p=str(p),U0=list(map(str,values)),weights=list(map(str,weights)),U1='0',rho=str(rho),rhoB=str(rhob)),positive39_multiplier_checks=2,critical_binary_gaps=critical,sources=before,child_exit_codes=[r.returncode,r2.returncode])
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(execution_status=result['execution_status'],negative_controls=len(tested),critical_gaps=[(x['n'],x['epsilon'])for x in critical]),indent=2))
if __name__=='__main__':main()
