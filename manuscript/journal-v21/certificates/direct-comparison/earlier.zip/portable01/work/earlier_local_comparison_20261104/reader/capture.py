"""Create-only actual process capture, including the whole external source closure."""
from pathlib import Path
import argparse,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import model as m
from accept import sources
def inventory():
    result=sources()
    for z in m.cat.SOURCES:result[z['path']]=m.digest(m.ROOT/z['path'])
    for rel in m.PINS:
        path=m.FAMILY/rel;result[str(path.relative_to(m.ROOT))]=m.digest(path)
    return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('discovery','acceptance','controls'));p.add_argument('output',type=Path);p.add_argument('arguments',nargs=argparse.REMAINDER);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);before=inventory()
    exe=Path(sys.executable);runtime=dict(executable=str(exe),resolved=str(exe.resolve()),binary_sha256=m.digest(exe.resolve()),version=sys.version)
    if a.mode=='discovery':cmd=[sys.executable,'-I','-B',str(HERE/'discover.py'),str(a.output/'objects'),*a.arguments]
    else:
        m.need(a.arguments,'input proof root required')
        if a.mode=='acceptance':cmd=[sys.executable,'-I','-B',str(HERE/'accept.py'),a.arguments[0],str(a.output/'accepted'),*a.arguments[1:]]
        else:
            m.need(len(a.arguments)==1,'controls input only');cmd=[sys.executable,'-I','-B',str(HERE/'controls.py'),a.arguments[0],str(a.output/'checked')]
    started=dict(command=cmd,runtime=runtime,source_before=before,scope='actual process observation and byte integrity only')
    (a.output/'STARTED.json').write_text(json.dumps(started,indent=2)+'\n');t=time.monotonic()
    with(a.output/'stdout.txt').open('w')as stdout,(a.output/'stderr.txt').open('w')as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr)
    after=inventory();observed=dict(started,actual_returncode=r.returncode,seconds=time.monotonic()-t,sources_unchanged=before==after,source_after=after,stdout_sha256=m.digest(a.output/'stdout.txt'),stderr_sha256=m.digest(a.output/'stderr.txt'))
    (a.output/'PROCESS.json').write_text(json.dumps(observed,indent=2)+'\n')
    print(json.dumps(dict(mode=a.mode,actual_returncode=r.returncode,sources_unchanged=before==after,seconds=observed['seconds']),indent=2))
    if r.returncode:raise SystemExit(r.returncode)
    m.need(before==after,'source closure changed during execution')
if __name__=='__main__':main()
