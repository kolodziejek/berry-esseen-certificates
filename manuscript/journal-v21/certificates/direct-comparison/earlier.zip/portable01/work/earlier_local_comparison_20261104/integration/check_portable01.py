"""Full byte relocation and six representative exact admissions, not737 replay."""
from pathlib import Path,PurePosixPath
import hashlib,json,stat,subprocess,sys,time,zipfile
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def need(v,s):
    if not v:raise ValueError(s)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    receipt=json.loads((ROOT/'runs/earlier_local_comparison_20261104/analytic_package01/RESULT.json').read_text())
    archive=ROOT/receipt['zip'];need(H(archive)==receipt['zip_sha256'],'selected archive bytes')
    out=ROOT/'runs/earlier_local_comparison_20261104/analytic_relocation01';out.mkdir(exist_ok=False)
    namespace=out/'workspace';namespace.mkdir();seen=set()
    with zipfile.ZipFile(archive)as z:
        for info in z.infolist():
            name=PurePosixPath(info.filename)
            need(not name.is_absolute()and '..'not in name.parts and str(name)==info.filename and name.parts[0]=='portable01'and info.filename not in seen,'safe unique archive path')
            need(not info.is_dir()and stat.S_IFMT(info.external_attr>>16)==stat.S_IFREG,'ordinary archived file')
            seen.add(info.filename);path=namespace/info.filename;path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('xb')as f:f.write(z.read(info))
    package=namespace/'portable01'
    need(H(package/'FILES.json')==receipt['manifest_sha256'],'same relocated manifest')
    files=json.loads((package/'FILES.json').read_text())['files']
    for r in files:
        p=package/r['path'];need(p.is_file()and not p.is_symlink()and p.stat().st_size==r['bytes']and H(p)==r['sha256'],'every relocated file readback')
    need(len(files)+1==receipt['files'],'entire namespace census')
    records=[]
    def run(label,cmd):
        t=time.monotonic()
        with(out/(label+'.stdout.txt')).open('w')as a,(out/(label+'.stderr.txt')).open('w')as b:r=subprocess.run(cmd,stdout=a,stderr=b)
        observed=dict(label=label,command=cmd,actual_returncode=r.returncode,seconds=time.monotonic()-t)
        records.append(observed);(out/(label+'.PROCESS.json')).write_text(json.dumps(observed,indent=2)+'\n')
        need(r.returncode==0,'successful bounded relocation stage '+label)
    run('package_verify',[sys.executable,'-I','-B',str(package/'replay.py'),str(out/'unused_new_replay_output'),'--verify-only'])
    selections=['positive39.p209.n39','central40.p209.n40','left40.p141.n40','left40.p162.n40','central42.p209.n46','left42.p145.n46']
    selected=out/'selected';selected.mkdir()
    native=package/'runs/earlier_local_comparison_20261104/analytic_complete01/discovery/objects'
    for name in selections:
        p=native/f'proof_{name}.json';(selected/p.name).write_bytes(p.read_bytes())
    run('relocated_six',[sys.executable,'-I','-B',str(package/'work/earlier_local_comparison_20261104/reader/capture.py'),'acceptance',str(out/'admission'),str(selected)])
    a=json.loads((out/'admission/accepted/RESULT.json').read_text())
    need(a['selected_pairs']==6 and a['complete_737']is False,'bounded admission scope')
    need({r['job']for r in a['results']}==set(selections),'all selected actual identities')
    # Both commands must leave the extracted package byte-identical.
    need({str(p.relative_to(package))for p in package.rglob('*')if p.is_file()}=={r['path']for r in files}|{'FILES.json'},'unchanged namespace')
    for r in files:need(H(package/r['path'])==r['sha256'],'unchanged relocated bytes')
    result=dict(execution_status='fresh PASS',scope='every packaged file relocated and rehashed; six representative actual pairs freshly admitted from relocated sources',full_relocated_737_replay=False,full_original_737_readback_preserved=True,files=receipt['files'],zip_sha256=receipt['zip_sha256'],manifest_sha256=receipt['manifest_sha256'],selected=selections,records=records,source_sha256=H(Path(__file__)))
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='records'},indent=2))
if __name__=='__main__':main()
