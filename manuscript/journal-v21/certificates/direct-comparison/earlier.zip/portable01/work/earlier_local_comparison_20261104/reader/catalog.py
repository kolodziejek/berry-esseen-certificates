"""Exact earlier-law projections and the fixed 737 actual-index census.

This binds previously acquired data; it does not re-prove acquisition.
No confinement, profile, or post-Sperner output is an input.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PIN='202927a2055d1ceb3c9cc4d3a052b60d6894db241adb435ba3d5797324a24783'
def need(v,message):
    if not v:raise ValueError(message)
need(__debug__ and not sys.flags.optimize,'unoptimized exact reader')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
    d={}
    for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def load(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def same(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b
def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return{k:encode(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return list(map(encode,x))
    return x
need(digest(HERE/'SOURCE_PINS.json')==PIN,'fixed source manifest')
SOURCES=load(HERE/'SOURCE_PINS.json')['files']
for item in SOURCES:
    p=ROOT/item['path'];need(p.is_file()and p.stat().st_size==item['bytes']and digest(p)==item['sha256'],'source bytes '+item['path'])

SPECS={
 'positive39':dict(path='work/toward40_20261007/entry/acquisition39/panels/acquisition39_candidate.json',floor=39,ns=(39,),count=78,first=151,last=228,K=F(741,4000),schema='SINGLE39_K741_4000_Q033_ACQUISITION_V1',initial='work/toward40_20261007/entry/acquisition39/initial/initial39_candidate.json'),
 'central40':dict(path='work/toward40_20261007/central40/acquisition_candidate.json',floor=40,ns=(40,41,42),count=48,first=190,last=237,K=F(0),schema='SINGLE40_CENTRAL_UPPER_ACQUISITION_V1',initial='work/toward40_20261007/central40/initial40_candidate.json'),
 'left40':dict(path='work/toward40_20261007/left40_accept/indexed_acquisition_candidate.json',floor=40,ns=(40,41,42),count=49,first=141,last=189,K=F(0),schema='INDEXED40_42_LEFT_ACQUISITION_V1',initial='work/toward40_20261007/central40/initial40_candidate.json'),
 'central42':dict(path='work/below49_20261006/acquisition/central42_acquisition_candidate.json',floor=42,ns=(43,44,45,46),count=47,first=190,last=236,K=F(0),schema='CENTRAL42_ACQUISITION_V1',initial='work/below49_20261006/acquisition/initial42_candidate.json'),
 'left42':dict(path='work/below49_20261006/package_audit/left42_exact/pre_sperner42_exact.json',floor=42,ns=(43,44,45,46),count=45,first=145,last=189,K=F(0),initial='work/below49_20261006/package_audit/left42_exact/initial42_candidate.json')}
ROWS={}
for family,spec in SPECS.items():
    data=load(ROOT/spec['path']);initial=load(ROOT/spec['initial'])
    need(type(data['N'])is int and data['N']==spec['floor'],'exact acquisition floor')
    need(len(initial['panels'])==100,'complete upstream initial probability cover')
    for j,r in enumerate(initial['panels']):need([F(r['pl']),F(r['pu'])]==[F(j,100),F(j+1,100)],'ordered initial cover')
    if family!='left42':
        need(data['schema']==spec['schema'],'named acquisition schema')
        source_key='initial_sha256'if family=='left40'else'source_sha256'
        need(data[source_key]==digest(ROOT/spec['initial']),'same initial source')
    if family=='positive39':
        need(F(data['barrier'])==spec['K']and F(data['decrement'])==F('.33')and F(data['cap'])==F('.4226')and F(data['excess_upper'])==F('.5'),'positive39 target and original scope')
        need(len(data['fine'])==90 and[data['fine'][j]['index']for j in range(90)]==list(range(140,230)),'complete positive39 fine cover')
    if family=='central40':
        need(len(data['fine'])==50 and len(data['prep'])==62,'central40 complete complement')
        need(sum(r.get('radius_proof',{}).get('cells',0)for r in data['prep'])==1080 and sum(r.get('strip_proof',{}).get('cells',0)for r in data['fine'])==3044,'original central40 strip/radius census')
    if family=='left40':
        need(data['indexed_premise']=='n=40,delta<=.19 OR n in{41,42},delta=0'and data['weighted_invariant']=='nD<=40*D_row'and F(data['current_cap'])==F('.4226'),'explicit left40 indexed scope')
    if family=='central42':need(data['weighted_invariant']=='n*D <= 42*D_row'and len(data['fine'])==50 and len(data['prep'])==10,'central42 weighted source')
    if family=='left42':
        need(type(data['L'])is int and data['L']==48,'left42 upper index')
        acq=load(ROOT/'work/below49_20261006/package_audit/left42_exact/acquisition42_proof.json')
        targets=load(ROOT/'work/below49_20261006/package_audit/left42_exact/strip_targets.json')
        proof=load(ROOT/'work/below49_20261006/package_audit/left42_exact/strip42_proof.json')
        need(acq['source_sha256']==digest(ROOT/spec['initial'])and len(acq['fine'])==55,'original left42 acquisition binding')
        selected=[dict(r['final'],radius=r['radius'])for r in acq['fine']if not r['final'].get('excluded')]
        need(same(selected,data['rows']),'direct pre-confinement rows equal acquired finals')
        need(targets['N']==42 and targets['L']==48 and F(targets['strip'])==F('.575')and len(targets['rows'])==45,'independent left42 coarse strip')
        need(proof['source_sha256']==digest(ROOT/'work/below49_20261006/package_audit/left42_exact/strip_targets.json')and len(proof['rows'])==45,'left42 strip proof source')
    rows=data['rows']if family in('left40','left42')else[r for r in data['fine']if not r.get('excluded')]
    need(len(rows)==spec['count'],'complete live row census')
    for j,raw in enumerate(rows):
        ix=spec['first']+j;need([F(raw['pl']),F(raw['pu'])]==[F(ix,500),F(ix+1,500)],'ordered closed surviving cover')
        if family=='central42':need(raw['index']==ix-190,'central42 source index')
        elif family!='left42':need(raw['index']==ix,'source panel index')
        width=F(raw['strip_width'])if family=='positive39'else F(raw['strip'])if family=='left40'else F('.575')if family=='left42'else F('.55')
        if family in('positive39','central40','central42'):
            need(raw['strip_proof']['cells']>0 and F(raw['strip_proof']['maximum'])<0,'complete independent strip receipt')
        need(F(0)<width<1 and 0<F(raw['inward_d_max'])<min(width,F(raw['pl'])),'coarse support and inward domains')
        r={k:F(raw[k])for k in('pl','pu','raw','D','theta','rho','beta','lambda_max','inward_d_max','Hplus','Hminus','A','B')}
        r['quadratics']=[{k:F(q[k])for k in('A','Fplus','Fminus','Qbudget')}for q in raw['quadratics']]
        need(len(r['quadratics'])==4 and all(q['Qbudget']>0 for q in r['quadratics']),'all four signed quadratics')
        r.update(index=ix,family=family,floor=spec['floor'],K=spec['K'],strip=width,source_path=spec['path'],source_sha256=digest(ROOT/spec['path']))
        ROWS[family,ix]=r
    need(spec['last']==spec['first']+len(rows)-1,'complete family endpoints')
CENSUS=[(family,ix,n)for family,s in SPECS.items()for ix in range(s['first'],s['last']+1)for n in s['ns']]
need(len(CENSUS)==737 and len(set(CENSUS))==737,'exact earlier737 partition')
def row(family,index,n):
    need(type(family)is str and family in SPECS and type(index)is int and type(n)is int,'strict identity types')
    need((family,index,n)in CENSUS,'selected actual index belongs to acquisition scope')
    return ROWS[family,index]
def job_id(family,index,n):
    row(family,index,n);return f'{family}.p{index}.n{n}'
def sl(x):
    need(x>=0,'nonnegative root');return F(isqrt(x.numerator*10**24//x.denominator),10**12)
def sh(x):return sl(x)+F(1,10**12)
def count_domain(family,index,n):
    r=row(family,index,n);pl,pu=r['pl'],r['pu'];sw=sh(pu*(1-pu)+r['lambda_max']/n)
    # These are bounds for the real threshold-coordinate k+u, before rounding.
    xmin=n*pl-r['Hminus']*sw;xmax=n*pu+r['Hplus']*sw
    need(0<=xmin<=xmax<=n,'unclamped threshold must lie in [0,n]')
    lower=xmin-F(1,2);upper=xmax+F(1,2)
    kl=-((-lower.numerator)//lower.denominator);kh=upper.numerator//upper.denominator
    need(0<=kl<=kh<=n,'unclamped nearest count interval')
    return dict(xmin=xmin,xmax=xmax,kl=kl,kh=kh)
def census_receipt():
    jobs=[];negative=[]
    for family,ix,n in CENSUS:
        r=row(family,ix,n);d=count_domain(family,ix,n);p=r['pl'];v=p*(1-p)
        L=3*p-r['inward_d_max']-F(3,2)*(1-2*v)-3*(1-2*v)*r['lambda_max']/(8*n*v)
        z=dict(job=job_id(family,ix,n),family=family,index=ix,n=n,p=[r['pl'],r['pu']],floor=r['floor'],K=r['K'],strip=r['strip'],count_domain=d,raw_bracket_lower=L)
        jobs.append(z)
        if L<0:negative.append(z['job'])
    return encode(dict(schema='EARLIER737_CENSUS_V1',mathematical_status='same-law acquisition scope projection; not a new comparison theorem',execution_status='fresh source and interior-count checks',source_manifest_sha256=PIN,jobs=jobs,negative_raw_box_bracket=negative,family_pairs={f:sum(x[0]==f for x in CENSUS)for f in SPECS}))
if __name__=='__main__':
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
    result=census_receipt();(out/'CENSUS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'jobs':len(result['jobs']),'negative_raw_bracket':len(result['negative_raw_box_bracket']),'family_pairs':result['family_pairs']},indent=2))
