# Earlier acquired-law direct comparison

The analytic contract is in `analytic/INTERFACE.md`. `reader/catalog.py`
defines the complete737-pair scope from the earlier acquired rows; it does
not take confinement or profile outputs as inputs. The immutable source
manifest lists the required original work-tree files. Preserve that workspace
layout, since paths derive from this directory's location under `work/`.

All acceptance arithmetic uses Python integers and `Fraction`. Discovery
uses NumPy/SciPy to propose quartics; each saved leaf is then checked exactly.
Use ordinary Python without `-O` or `-OO`. The standalone scripts support
`-I -B` and create their requested output directory exclusively.

From the workspace root, for a new destination that does not exist:

```sh
python3 -I -B work/earlier_local_comparison_20261104/reader/catalog.py NEW_CENSUS
python3 -I -B work/earlier_local_comparison_20261104/reader/capture.py discovery NEW_DISCOVERY positive39.p209.n39 central40.p209.n40 left40.p162.n40 central42.p209.n43 left42.p145.n43
python3 -I -B work/earlier_local_comparison_20261104/reader/capture.py acceptance NEW_ACCEPTANCE NEW_DISCOVERY/objects
python3 -I -B work/earlier_local_comparison_20261104/reader/capture.py controls NEW_CONTROLS NEW_DISCOVERY/objects
```

The controls command expects the five-family pilot shown. To claim complete
coverage, pass every exact job identifier from the catalog to discovery, then
invoke acceptance with `--complete`; this independently requires all737
unique family/index/n identities. The optional flag is an acceptance scope
requirement, not a relaxation of any mathematical check. A partial admission
explicitly remains partial.

`analytic/run_complete01.py` is a preserved historical campaign driver with
fixed run destinations. Do not rerun it in an existing evidence tree. New
runs should use distinct destinations through `capture.py`, preserving all
failed or interrupted observations and source epochs. Captures include
the complete external source closure as well as the actual process exits.

The complete global theorem additionally needs its established analytic
ancestors and other index ranges. A737 arithmetic success alone does not
prove attainment, the Fourier reduction, or acquisition. See the analytic
contract and the parent manuscript's dependency ledger.
