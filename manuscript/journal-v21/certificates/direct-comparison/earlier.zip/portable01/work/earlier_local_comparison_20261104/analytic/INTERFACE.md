# Direct comparison on the earlier acquired laws

This is a locally derived analytic implication. Its computational counterpart
is the fixed 737-pair reader in `../reader`. The complete comparison census is
not claimed until every pair is accepted. The original attainment, contact,
Fourier, acquisition and coarse-strip arguments remain hypotheses; this
module replaces their later confinement and probabilistic-comparison uses.

## Exact upstream contracts

The fixed catalog selects the following earlier outputs, with their original
joint, same-law meanings. Here N is the resource floor and n the actual index.

|Family|Actual n|Closed p panels|Rows|N|K in target CE+K/n|Earlier strip width|
|---|---|---|---:|---:|---:|---|
|positive39|39|[.302,.458], step .002|78|39|741/4000|.575 or .55|
|central40|40,41,42|[.38,.476], step .002|48|40|0|.55|
|left40|40,41,42|[.282,.38], step .002|49|40|0|.55, .575 or .6|
|central42|43,44,45,46|[.38,.474], step .002|47|42|0|.55|
|left42|43,44,45,46|[.29,.38], step .002|45|42|0|.575|

The sum is 78+3(48+49)+4(47+45)=737. Positive39 retains the
original positive barrier and predecessor allowance .33. Both floor40
branches require n=40 with predecessor decrement at most .19, or n=41/42
with zero decrement; the weighted invariant is **nD<=40 Drow**, not
nD<=n Drow. The central indexed extension is a separate previously derived
analytic input, pinned alongside the original single-index central source.
The floor42 branches retain their original finite42--48 scope; selecting
43--46 is a restriction. Global initial/complement exclusions are retained
separately. Nothing here claims to re-establish those ancestors.

`SOURCE_PINS.json` binds25 upstream data/interface files. In particular,
left42 input rows are checked equal, field for field, to the original
acquisition's live final rows before Sperner confinement. Coarse strips are
from independent earlier exterior-contact proofs. No post-confinement
amplitude, TINY, MID, or LOW target supplies a hypothesis.

## One conditional marginal, one count process

Write X=(Y-p)/sqrt(w), Y=B+U, P(B=1)=p, E(U|B)=0,
q=1-p, v=pq, s=q*s0+p*s1, w=v+s, lambda=n*s. The actual conditional
laws U0,U1 satisfy

    U0 in [-A,a0], U1 in [-a1,A],
    a0,a1>=0, a0+a1<=d0<min(p,A), E Uj=0.

A is the row's licensed strip width. Let Wk be a sum of n-k independent
U0 variables and k independent U1 variables, always using this same pair
of marginals. Put H=(k+u-np)/sqrt(w), |u|<=1/2, pi_j=Bin(n,p){j}.
The source H bounds imply an unclamped real-threshold interval [xmin,xmax]
inside [0,n]. The reader verifies this before taking the nearest-count
range ceil(xmin-1/2)..floor(xmax+1/2); it never silently clamps away a case.
Both closed phase halves are included, including u=0 and half-integer ties.

Couple all counts with the same independent pairs (U0i,U1i). Consecutive
sums j+Wj increase by at least c=1-d0>0. The last index at or below k+u
is therefore well defined (use -1 when the set is empty). If Wk>u, at
least pi_k is lost from the binary cumulative mass. If a later index k+i
is at or below threshold, then Wk<=u-c*i. For

    R0 >= max_{1<=i<=n-k} pi_(k+i)/pi_k

the normalized cumulative-mass difference is consequently at most

    psi(Wk-u),  psi(z)=-1{z>0}+R0*max(0,floor(-z/c)).

This is a pathwise argument, not an identification of other-count
distributions from the own-count law. It handles atoms because outgoing
uses a strict inequality and incoming a closed one. A global quartic Q>=psi
gives the CDF bound by E Q(Wk-u). The exact global checker verifies all
staircase intervals through eight steps and a valid linear bound for the
remaining negative ray, together with the entire positive ray. Sampled
LP points are only discovery inputs.

## Fourth moments and the signed target

Let m3j=E Uj^3, gamma_j=m3j/sj when sj>0, and
alpha=p*s1/s when s>0; use zero terms by continuity. Then

    t=E Wk^2=(n-k)s0+k*s1,
    S3=E Wk^3=(n-k)m30+k*m31,
    E Wk^4 <= (n-k)[(a0-A)m30+A*a0*s0]
               +k[(A-a1)m31+A*a1*s1]+3t^2.

The conditional bounds follow by integrating
(U0+A)(a0-U0)U0^2>=0 and its reflected counterpart. The sum identity
uses independence and discards only the nonnegative term3*sum Var(Ui)^2.
Thus the same actual law licenses all three moments simultaneously.

Since a0<p and a1<q, absolute values have fixed signs conditionally, and

    rho=[v(1-2v)+s*G]/w^(3/2),
    G=3p(1-alpha)+3q*alpha+alpha*gamma1-(1-alpha)*gamma0.

The elementary bound (1+x)^(3/2)<=1+3x/2+3x^2/8 gives

    rho-rhoB >= s*L/w^(3/2),
    L=G-3(1-2v)/2-3(1-2v)s/(8v), rhoB=(1-2v)/sqrt(v).

For the fixed target T=CE+K/n choose positive cell constants
c_lo<=T/w^(3/2)<=c_hi. The valid gain is the minimum of
c_lo*s*L and c_hi*s*L, irrespective of the sign of L. The32 raw boxes
whose simple L lower bound is negative are explicitly listed in the
census. No sign is assumed even for the other boxes.

If the exact binary score at the actual n is at most CE-epsilon, the
target loss obeys the exact decomposition

    rho*(T-C) >= (epsilon+K/n)*rhoB + T*(rho-rhoB)
       +sqrt(n)[Phi((k+u-np)/sqrt(nw))-Phi((k-np)/sqrt(nv))]
       -b*E Q(Wk-u),                 b=sqrt(n)*pi_k.

This uses the fixed target T, not the unknown attained C. Both multiplier
endpoints include K/n. Omitting K*(rho-rhoB)/n while adding only K*rhoB/n
would be invalid when the moment difference is negative. The baseline
reserve uses the lower rhoB endpoint if epsilon+K/n>=0 and the upper
endpoint otherwise. The binary module proves its cap by exact endpoint
CDF bounds over128 closed p subdivisions and all counts/both jump sides.
Its signed epsilon is a mathematical bound even if negative; a failed
score gate then remains a failure rather than being relabeled a proof.

On each phase-sign cell the Gaussian difference has a lower bound
phasecoef*u+varcoef*lambda, obtained by integrating the derivative of Phi
first in phase and then in variance. For positive phase use the lower
density/larger denominator; for negative phase use the upper density/
smaller denominator. Negative binary displacement makes the variance
term favorable, in which case its density is bounded below; otherwise
its negative contribution is bounded in absolute value. All arguments
lie in the same reconstructed closed threshold interval. The elementary
phi(x)>=phi(0)(1-x^2/2) lower bound is required positive before use.

## Joint resource restriction and48 sufficient gates

The original joint-defect lower bound gives

    D >= P0 + I*d + beta*theta,
    P0<=D_B(p), theta=s/(v+s), d=a0+a1,
    I<=6(1-Theta)*sqrt((1-Theta)/vmax)*(1-d0),
    beta<=min(3(sqrt(10)+1)Bmin,3(sqrt(10)+3)Amin)-3P0/2.

P0 is zero if the p interval meets p*=(4-sqrt(10))/2; otherwise a lower
distance bound gives P0. Conditional centering and support imply s0<=A*a0
and s1<=A*a1, hence s<=A*(1-pl)*d on these p<1/2 panels. With the
original weighted budget M=min(N*Drow,Bmax/kappa), kappa=997/15000,

    lambda <= (M-nP0)/[I/(A*(1-pl))+beta*n/(n*vmax+U)],

provided M-nP0>=0. A negative numerator is an exclusion. Bmax is the
minimum of the original raw cap and the maximum of all four original
signed concave quadratics over the current actual H interval. A finite
sequence of16 ceiling intersections is valid step by step; no convergence
argument is used. Positive39 exports its quadratics without subtracting
K*rho. We conservatively drop that extra charge here; the inherited
N*Drow still retains its original K-priced acquisition. There is no new
or double use of the positive charge. A strict binary-phase exclusion
requires Bmax<0, or P0>0 and kappa*nP0>=Bmax; P0=Bmax=0 is not excluded.

For each fixed positive multiplier endpoint the score gate is concave in
alpha. At alpha0/1 it is affine in the surviving gamma. The outward gamma
endpoint removes inward dependence; at the inward endpoint the remaining
loss is a concave quadratic in a_j, so only0,d0 need checking. These are
six moment corners. Next the gate is concave in lambda: the quadratic
coefficient is

    -3*c*(1-2v)/(8*n^2*v)-3*b*q4*(t/lambda)^2 <= 0.

Finally it is affine in b. Thus six moment corners, two noise endpoints,
two mass endpoints and two target-multiplier endpoints give48 gates.
All eliminated constants are fixed uniformly on the same (p,u) cell.
Clearing the positive factor(nv)^2 leaves bidegree at most(6,4). Every
Bernstein coefficient must be strictly positive on the closed rectangle.
Zero lambda is included by these exact polynomials and the global Q(-u)
majorant; it is not dismissed by confusing own-count k with the binary
CDF index when u<0. All strict proof obligations remain actual strict tests.

## Acceptance and evidence

The pure exact reader reconstructs all constants and binary caps. Objects
contain only the family/index/n/source identity, the reproduced binary cap,
and an ordered full count/sign forest whose leaves are literal quartics
or independently reconstructed exclusions. Split children cover both
closed halves. Duplicate JSON keys, integer/Boolean/float substitutions,
false or null exclusions, omitted roots, changed source identities and
changed arithmetic are rejected. `accept.py --complete` requires exactly
the737 catalog identities. A valid partial run cannot produce that claim.

`capture.py` records actual argv, Python binary/runtime, stdout, stderr,
return code and before/after hashes of all reader files, the25 upstream
files and eight algebra/native files. These are integrity observations;
the mathematical soundness is the argument above and its dependencies.
The five-family pilot and separate exact readback do not yet replace the
full earlier census. No manuscript source has been changed by this module.
