"""Floating earlier737 witness search, with separate exact leaf admission."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,math,sys,time
import numpy as np
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import model as m
from accept import sources

def propose(z):
    padding=min(F(1,10**6),max(F(1,10**10),z['gap']/(100*z['bhi'])))
    fourth_padding=min(F(1,10**7),padding/10)
    separation=float(padding/10)
    margin_floor=min(1e-9,max(1e-12,float(z['gap']/(1000*z['bhi']))))
    records=m.affine_gates(z);norm=float((z['n']*(z['pl']+z['pu'])/2*(1-(z['pl']+z['pu'])/2))**2)
    matrix=[];rhs=[];seen=set()
    for rec in records:
        b=m.gate.bernstein_affine(rec,z['pl'],z['pu'],z['ul'],z['uh']);cc,aa=b['constant'],b['linear']
        for i in range(7):
            for j in range(5):
                rr=(cc[i][j],*(x[i][j]for x in aa))
                if rr in seen:continue
                seen.add(rr);matrix.append([-float(x)/norm for x in rr[1:]]+[1.]);rhs.append(float(rr[0])/norm)
    c,R=float(z['c']),float(z['R0']);J=8
    def target(x):
        if x<-J*c:return R*(-x)/c
        if x>1e-10:return -1.
        v=-x/c
        if abs(v-round(v))<1e-9:v=round(v)
        return R*max(0,math.floor(v))
    points=sorted(set(np.linspace(-10,10,51))|{-j*c for j in range(J+1)}|{0.})
    for iteration in range(50):
        lhs=list(matrix);bound=list(rhs)
        for x in points:
            scale=max(1.,abs(x)**4);lhs.append([-x**j/scale for j in range(5)]+[0.]);bound.append(-target(x)/scale)
        r=linprog([0.]*5+[-1.],A_ub=lhs,b_ub=bound,bounds=[(-100,100)]*4+[(.001,100),(-100,100)],method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
        if not r.success:return None,{'reason':'LP','message':r.message}
        if r.x[-1]<margin_floor:return None,{'reason':'score','margin':float(r.x[-1])}
        q=r.x[:5];der=np.array([j*q[j]for j in range(1,5)]);extra=[]
        for root in np.polynomial.polynomial.polyroots(der):
            if abs(root.imag)<1e-7 and root.real>=-J*c:
                x=float(root.real)
                if np.polynomial.polynomial.polyval(x,q)-target(x)<-separation*max(1.,abs(x)**4):extra.append(x)
        der[0]+=R/c
        for root in np.polynomial.polynomial.polyroots(der):
            if abs(root.imag)<1e-7 and root.real<-J*c:
                x=float(root.real)
                if np.polynomial.polynomial.polyval(x,q)-target(x)<-separation*max(1.,abs(x)**4):extra.append(x)
        if extra:points.extend(extra);continue
        rational=[F(round(float(x)*10**10),10**10)for x in q];rational[0]+=padding;rational[4]+=fourth_padding
        try:
            margin=m.leaf_check(z,rational)
            return list(map(str,rational)),{'exact_margin':str(margin),'floating_margin':float(r.x[-1])}
        except ValueError as e:return None,{'reason':'exact_rejection','message':str(e),'floating_margin':float(r.x[-1])}
    return None,{'reason':'separation_limit'}

def main():
    # Explicit case arguments avoid an accidental full campaign at import/startup.
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path);p.add_argument('jobs',nargs='+');a=p.parse_args()
    selected=[]
    by_id={m.cat.job_id(*x):x for x in m.cat.CENSUS}
    for name in a.jobs:m.need(name in by_id and by_id[name]not in selected,'unique fixed-census job');selected.append(by_id[name])
    a.output.mkdir(parents=True,exist_ok=False);before=sources();start=time.monotonic();results=[]
    for family,index,n in selected:
        job=m.cat.job_id(family,index,n);g=m.gap(family,index,n);nodes=0
        def build(k,cell,depth):
            nonlocal nodes
            nodes+=1;m.need(nodes<=3000 and depth<=16,'bounded discovery tree budget')
            z=m.parameters(family,index,n,k,*cell)
            if 'excluded'in z:return {'excluded':z['excluded']}
            q,detail=propose(z)
            if q is not None:
                print('ACCEPTED_LEAF',job,k,depth,[str(x)for x in cell],detail['floating_margin'],flush=True);return {'q':q}
            if depth>=16:raise ValueError('unresolved '+json.dumps(m.encode(dict(job=job,k=k,cell=cell,detail=detail))))
            pl,pu,ul,uh=cell;axis='u'if uh-ul>F(1,32)else'p'
            print('SPLIT',job,k,depth,axis,detail,flush=True)
            return {'split':axis,'children':[build(k,cc,depth+1)for cc in m.children(cell,axis)]}
        r=m.cat.row(family,index,n)
        obj=dict(schema='EARLIER737_SIGNED48_V1',family=family,index=index,n=n,source_sha256=r['source_sha256'],gap=g,
             trees=[{'k':k,'sign':sign,'tree':build(k,cell,0)}for k,sign,cell in m.roots(family,index,n)])
        result=m.accept(obj);result['nodes']=nodes;results.append(result)
        (a.output/f'proof_{job}.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps(result),flush=True)
    m.need(before==sources(),'unchanged discovery/reader sources')
    result=dict(status='EXACT_ADMITTED_DISCOVERY_OBJECTS',scope='only listed earlier acquired pairs; no complete-census claim',results=results,seconds=time.monotonic()-start,sources=before)
    (a.output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
