"""Independent small algebra/endpoint probes for the frozen strict reader."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
SOURCE=ROOT/'work/finite_left_replacement_20261104/audit/quartic_sturm.py'
PIN='1f815ccb23692f78be98691a76a5fe0605f8995abdab5d9a3964f1625a4c2617'
def need(v,s):
    if not v:raise ValueError(s)
need(__debug__ and not sys.flags.optimize,'ordinary exact runtime')
need(hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN,'frozen reader source')
sp=importlib.util.spec_from_file_location('reviewed_sturm',SOURCE);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def ev(p,x):return sum(F(a)*x**j for j,a in enumerate(p))
def main():
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
    tests=[('positive_constant',[2],True),('positive_linear',[1,1],True),('positive_squarefree_quadratic',[1,0,1],True),('positive_near_contact',[F(13,50),-1,1],True),('two_simple_interior_roots',[F(3,16),-1,1],False),('double_contact',[F(1,4),-1,1],False),('repeated_complex_factor',[1,0,2,0,1],False),('repeated_exterior_factor',[1,2,1],False),('left_endpoint_zero',[0,1],False),('right_endpoint_zero',[1,-1],False),('zero_polynomial',[0,0],False),('negative_constant',[-1],False),('floating_coefficient',[1.,1],False),('boolean_coefficient',[True,1],False),('degree_five',[1,0,0,0,0,1],False)]
    result=[]
    for name,p,expected in tests:
        try:r=m.positive(p);actual=True
        except(ValueError,TypeError,ZeroDivisionError):actual=False;r=None
        need(actual==expected,'expected positivity outcome '+name);result.append(dict(name=name,accepted=actual,receipt=r))
    # Independently verify every transformation by rational substitution.
    q=[F(7),F(-2),F(3,2),F(-1,5),F(1,3)];u=F(2,7);c=F(5,6);R=F(9,8);J=8
    targets=m.base.fixed_targets(q,u,c,R,J);identities=0
    for name,p in targets:
        for t in(F(0),F(1,8),F(1,3),F(1,2),F(3,4)):
            if name=='right-ray':want=(1-t)**4*(ev(q,u+t/(1-t))+1)
            elif name=='left-ray':
                s=t/(1-t);want=(1-t)**4*(ev(q,u-J*c-s)-R*J-R*s/c)
            else:
                j=int(name.split('-')[1]);want=ev(q,u-(j+1)*c+c*t)-R*j
            need(ev(p,t)==want,'independent exact target substitution');identities+=1
        if 'ray'in name:need(ev(p,F(1))==q[4],'compact ray endpoint equals leading coefficient');identities+=1
    # All jumps for one actually selected global witness, including both tails.
    path=ROOT/'runs/earlier_local_comparison_20261104/analytic_pilot01/objects/proof_positive39.p209.n39.json'
    sys.path.insert(0,str(ROOT/'work/earlier_local_comparison_20261104/reader'))
    import model
    obj=json.loads(path.read_text());leaf=next(x for x in obj['trees']if 'q'in x['tree'])
    cell=next(z[2]for z in model.roots(obj['family'],obj['index'],obj['n'])if z[:2]==(leaf['k'],leaf['sign']))
    z=model.parameters(obj['family'],obj['index'],obj['n'],leaf['k'],*cell);qq=list(map(F,leaf['tree']['q']))
    receipt=m.accept(qq,0,z['c'],z['R0']);collisions=0
    for j in range(13):
        for eps in(F(-1,10**8),F(0),F(1,10**8)):
            x=-j*z['c']+eps;v=-x/z['c'];stair=max(0,v.numerator//v.denominator)
            value=-int(x>0)+z['R0']*stair
            need(ev(qq,x)>=value,'actual closed-jump and strict-outgoing comparison');collisions+=1
    status=dict(mathematical_status='bounded independent source/semantics review; continuous proof in SOUNDNESS.md',execution_status='fresh PASS',polynomial_tests=result,target_substitution_identities=identities,actual_atom_and_tail_probes=collisions,selected_majorant=receipt,reader_sha256=PIN,test_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (out/'RESULT.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(dict(tests=len(tests),identities=identities,atom_probes=collisions,execution_status='fresh PASS'),indent=2))
if __name__=='__main__':main()
