"""Fixed serial737 campaign followed by independent fresh exact admission.

Parent reviewed and authorized this run after the five-family pilot,
critical binary checks, full source reviews and adverse controls.
No retry, source modification, target change, or implicit overwrite.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent
READER=HERE.parent/'reader';ROOT=HERE.parents[2]
sys.path.insert(0,str(READER))
import catalog as cat
def main():
    out=ROOT/'runs/earlier_local_comparison_20261104/analytic_complete01'
    out.mkdir(parents=True,exist_ok=False)
    jobs=[cat.job_id(*x)for x in cat.CENSUS]
    plan=dict(schema='EARLIER737_SERIAL_EXECUTION_PLAN_V1',jobs=jobs,source_manifest_sha256=cat.PIN,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
    capture=READER/'capture.py'
    cmds=[
      [sys.executable,'-I','-B',str(capture),'discovery',str(out/'discovery'),*jobs],
      [sys.executable,'-I','-B',str(capture),'acceptance',str(out/'acceptance'),str(out/'discovery/objects'),'--complete'],
      [sys.executable,'-I','-B',str(capture),'controls',str(out/'controls'),str(ROOT/'runs/earlier_local_comparison_20261104/analytic_pilot01/objects')]]
    records=[]
    for stage,cmd in zip(('discovery','acceptance','controls'),cmds):
        t=time.monotonic();print('START',stage,flush=True)
        r=subprocess.run(cmd)
        rec=dict(stage=stage,command=cmd,actual_returncode=r.returncode,seconds=time.monotonic()-t);records.append(rec)
        (out/f'{stage}_OUTER.json').write_text(json.dumps(rec,indent=2)+'\n')
        if r.returncode:raise SystemExit(r.returncode)
    result=dict(execution_status='fresh complete campaign and exact admission passed',records=records,scope='737 earlier acquired-law implications; original analytic acquisition ancestors retained')
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='records'},indent=2))
if __name__=='__main__':main()
