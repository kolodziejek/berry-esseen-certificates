"""Byte-exact selected source/object/evidence package; no mathematical replay."""
from pathlib import Path, PurePosixPath
import hashlib,json,shutil,sys,zipfile
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
READER=HERE.parent/'reader';sys.path.insert(0,str(READER))
import model as m
from capture import inventory
def copy(source,target):
    m.need(source.is_file()and not source.is_symlink(),'ordinary selected file '+str(source))
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():m.need(target.read_bytes()==source.read_bytes(),'identical shared file')
    else:target.write_bytes(source.read_bytes())
def main():
    campaign=ROOT/'runs/earlier_local_comparison_20261104/analytic_complete01'
    final=m.cat.load(campaign/'RESULT.json')
    m.need(len(final['records'])==3 and all(r['actual_returncode']==0 for r in final['records']),'stopped complete campaign')
    admitted=m.cat.load(campaign/'acceptance/accepted/RESULT.json')
    m.need(admitted['complete_737']is True and admitted['selected_pairs']==737,'fresh full exact admission')
    current=inventory()
    for stage in('discovery','acceptance','controls'):
        p=m.cat.load(campaign/stage/'PROCESS.json')
        m.need(p['actual_returncode']==0 and p['sources_unchanged']is True and m.same(p['source_before'],current)and m.same(p['source_after'],current),'same completed source epoch '+stage)
    dest=HERE.parent/'portable01';dest.mkdir(exist_ok=False)
    for rel in current:copy(ROOT/rel,dest/rel)
    for rel in('work/earlier_local_comparison_20261104/README.md','work/earlier_local_comparison_20261104/analytic/INTERFACE.md','work/earlier_local_comparison_20261104/analytic/ENVIRONMENT.json','work/earlier_local_comparison_20261104/analytic/run_complete01.py','work/earlier_local_comparison_20261104/integration/build_portable01.py'):
        copy(ROOT/rel,dest/rel)
    reviews=HERE/'review_sturm'
    for path in reviews.rglob('*'):
        if path.is_file():copy(path,dest/path.relative_to(ROOT))
    runnames=('analytic_census01','analytic_pilot01','analytic_accept01','analytic_controls01','analytic_complete01','analytic_sturm_review02','analytic_sturm_layout01')
    for name in runnames:
        base=ROOT/'runs/earlier_local_comparison_20261104'/name
        for path in sorted(base.rglob('*')):
            if path.is_file():copy(path,dest/path.relative_to(ROOT))
    replay='''"""Verify selected package bytes, then replay all737 exact implications."""
from pathlib import Path, PurePosixPath
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized Python required')
if len(sys.argv)not in(2,3)or(len(sys.argv)==3 and sys.argv[2]!='--verify-only'):raise SystemExit('usage: python3 -I -B replay.py NEW_OUTPUT [--verify-only]')
out=Path(sys.argv[1]).resolve()
if out.exists():raise FileExistsError('create-only replay output already exists')
if out==ROOT or ROOT in out.parents:raise ValueError('write new replay evidence outside the immutable package')
seen=set()
for row in json.loads((ROOT/'FILES.json').read_text())['files']:
    rel=PurePosixPath(row['path'])
    if rel.is_absolute()or '..'in rel.parts or str(rel)!=row['path']or row['path']in seen:raise ValueError('unsafe or duplicate package path')
    seen.add(row['path'])
    p=ROOT/row['path']
    if p.is_symlink()or not p.is_file()or p.stat().st_size!=row['bytes']or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:raise ValueError('package byte mismatch '+row['path'])
if {str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()}!=seen|{'FILES.json'}:raise ValueError('extra or missing package files')
if len(sys.argv)==3:
    print('PACKAGE_BYTES_VERIFIED; no mathematical replay was run')
    raise SystemExit(0)
cmd=[sys.executable,'-I','-B',str(ROOT/'work/earlier_local_comparison_20261104/reader/capture.py'),'acceptance',str(out),str(ROOT/'runs/earlier_local_comparison_20261104/analytic_complete01/discovery/objects'),'--complete']
raise SystemExit(subprocess.run(cmd).returncode)
'''
    (dest/'replay.py').write_text(replay)
    (dest/'README.md').write_text('''# Earlier737 exact comparison package

From this extracted directory, run one command with a new output destination:

```
python3 -I -B replay.py /absolute/path/to/NEW_OUTPUT
```

The command verifies every selected package file and freshly accepts all737
family/index/n objects using exact Python integer/Fraction arithmetic. It
does not import NumPy or SciPy. Python3.12.12 was tested; -O and -OO are
rejected. No compiler, network or system installation is needed. The
published ZIP digest is the external integrity anchor; FILES.json detects
accidental changes inside the package but is not a separate trust authority.

The complete original actual discovery, fresh exact readback and adverse
controls are preserved under runs/earlier_local_comparison_20261104/
analytic_complete01. Their absolute argv paths record where those original
processes ran; they are historical observations, not claims of execution in
your extracted directory. A new replay writes its own actual paths, runtime,
source hashes, outputs and exit code. The preserved run_complete01.py has
fixed historical destinations and should not be rerun in this package.

The mathematical result is a direct-score implication for the specified
earlier acquired laws: positive39 at target CE+741/(4000*39), and the
listed actual40--46 cases at target CE. It retains the same-law contact,
initialization, Fourier/acquisition and independent coarse-strip hypotheses.
The25 original upstream files are included and bound for source/interface
integrity; this command does NOT replay or prove their analytic acquisition
ancestors. It also does not prove the other index ranges or the full theorem
by itself. See work/earlier_local_comparison_20261104/analytic/INTERFACE.md
for the complete reduction and source scope, and
work/earlier_local_comparison_20261104/integration/review_sturm/
for the strict global-polynomial reader's self-contained soundness proof.

Discovery is separate: the preserved discovery source uses NumPy/SciPy
only to propose candidates. Exact acceptance reconstructs all constants,
binary caps, global majorants,48-corner tensors and complete coverage. The
objects do not contain an assumed PASS flag that replaces these checks.
''')
    files=[]
    for path in sorted(dest.rglob('*')):
        if path.is_file():files.append(dict(path=str(path.relative_to(dest)),bytes=path.stat().st_size,sha256=m.digest(path)))
    manifest=dict(schema='EARLIER737_PORTABLE_FILES_V1',scope='byte-preserved selected source/object/evidence package; exact replay is a separate command',files=files)
    (dest/'FILES.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=dest.with_suffix('.zip')
    m.need(not archive.exists(),'new archive only')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for path in sorted(dest.rglob('*')):
            if path.is_file():z.write(path,str(path.relative_to(dest.parent)))
    result=dict(package=str(dest.relative_to(ROOT)),zip=str(archive.relative_to(ROOT)),zip_sha256=m.digest(archive),zip_bytes=archive.stat().st_size,manifest_sha256=m.digest(dest/'FILES.json'),files=len(files)+1,logical_bytes=sum(r['bytes']for r in files)+(dest/'FILES.json').stat().st_size,scope='byte packaging only; full original737 readback is preserved; relocated smoke/replay reported separately')
    out=ROOT/'runs/earlier_local_comparison_20261104/analytic_package01';out.mkdir(exist_ok=False)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
