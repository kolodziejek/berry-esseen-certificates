"""Exact 48-gate comparison on the fixed earlier737 acquired-law census."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,comb
from functools import lru_cache
import hashlib,importlib.util,json,sys
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized exact acceptance required')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
FAMILY=ROOT/'work/finite_left_replacement_20261104'
sys.path.insert(0,str(HERE))
import catalog as cat
import binary_gap
PINS={'construction/quartic_gate.py':'b34522389c8e2bf745b70cd4907a021b96e60cd64a14e9b6cadd7951a0207858',
 'construction/quartic_gate24.py':'e1e99806639ce4cb382c239c3748007a6da3acb7e7757495bb7258e7f7809d04',
 'construction/shifted_quartic_gate.py':'20ffba75c8692132fb377f9aa9643acdb5e78aecf0b0a1522b8fba830d79716e',
 'construction/shifted_quartic_fast.py':'ab5d0f667e5f5faa5656e4a0315acebe1d5e31ae718d36cb1d92122f00edd874',
 'audit/quartic_sturm.py':'1f815ccb23692f78be98691a76a5fe0605f8995abdab5d9a3964f1625a4c2617',
 'audit/quartic_global.py':'0760d772b6cf1858ed139a1fe179490cb1e523a5d685a37a25271a10b349aa35',
 'audit/native/finite_binomial_core.py':'939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f'}
def need(v,m):
    if not v:raise ValueError(m)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for rel,pin in PINS.items():need(digest(FAMILY/rel)==pin,'fixed algebra source '+rel)

sys.path.insert(0,str(FAMILY/'construction'))
import shifted_quartic_fast as gate
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
globalq=module('bottleneck_sturm',FAMILY/'audit/quartic_sturm.py')
native=binary_gap.native
SIGLO=F(3162277660,10**9);SIGHI=F(3162277661,10**9);KAPPA=F(997,15000)
CELO=F('.4095');CEHI=F('.40974');PHILO=F('.39886');PHIHI=F('.4')
need(SIGLO**2<10<SIGHI**2 and CELO<native.CE_LO and (3+SIGHI)*native.PHI_HI/6<CEHI,'directed scalar constants')
need(KAPPA<native.PHI_LO/6 and PHILO<native.PHI_LO<native.PHI_HI<PHIHI,'normal scalar constants')
def lo(x):return F(x.numerator*10**10//x.denominator,10**10)
def hi(x):return lo(x)+F(1,10**10)
def sl(x):return F(isqrt(x.numerator*10**24//x.denominator),10**12)
def sh(x):return sl(x)+F(1,10**12)
def row(family,index,n):
    actual=cat.row(family,index,n)
    # Directed projection to a short rational envelope; originals remain pinned.
    r=dict(actual)
    for key in('raw','D','theta','rho','beta','lambda_max','inward_d_max','Hplus','Hminus'):r[key]=hi(actual[key])
    for key in('A','B'):r[key]=lo(actual[key])
    r['quadratics']=[{key:(lo(q[key])if key=='Qbudget'else hi(q[key]))for key in('A','Fplus','Fminus','Qbudget')}for q in actual['quadratics']]
    need(0<r['strip']<1 and 0<r['inward_d_max']<min(r['strip'],r['pl']),'licensed support and cubic signs')
    return r
@lru_cache(maxsize=800)
def gap(family,index,n):
    cat.row(family,index,n);return binary_gap.panel(n,index)
def roots(family,index,n):
    r=cat.row(family,index,n);d=cat.count_domain(family,index,n)
    return[(k,sign,(r['pl'],r['pu'],F(-1,2)if sign<0 else F(0),F(0)if sign<0 else F(1,2)))for k in range(d['kl'],d['kh']+1)for sign in(-1,1)]
def qmax(q,a,b,positive):
    aa,ff,qq=F(q['A']),F(q['Fplus'if positive else'Fminus']),F(q['Qbudget'])
    need(qq>0 and 0<=a<=b,'signed concave resource domain');x=max(a,min(b,ff/(2*qq)))
    return aa+ff*x-qq*x*x
def parameters(family,index,n,k,pl,pu,ul,uh):
    r=row(family,index,n);N=n;A=r['strip'];K=r['K'];pl,pu,ul,uh=map(F,(pl,pu,ul,uh));need(F(r['pl'])<=pl<pu<=F(r['pu'])and-F(1,2)<=ul<uh<=F(1,2)and(uh<=0 or ul>=0),'closed subcell')
    vl,vh=pl*(1-pl),pu*(1-pu);theta=F(r['theta']);d0=F(r['inward_d_max'])
    dist=max(F(0),(4-SIGHI)/2-pu,pl-(4-SIGLO)/2)
    P0=lo((6+2*SIGLO)*dist**2/sh(vh));beta=lo(min(3*(SIGLO+1)*F(r['B']),3*(SIGLO+3)*F(r['A']))-3*P0/2)
    inward=lo(6*(1-theta)*sl((1-theta)/vh)*(1-d0));M=A*(1-pl)
    need(beta>0 and inward>0 and M>0,'simultaneous positive joint prices')
    U=F(r['lambda_max']);dl=k-N*pu;dh=k-N*pl
    for _ in range(16):
        wh=vh+U/N;swl=sl(vl);swh=sh(wh);rl=dl+ul;rh=dh+uh
        Hl=max(-F(r['Hminus']),rl/(swh if rl>=0 else swl));Hh=min(F(r['Hplus']),rh/(swl if rh>=0 else swh))
        if Hl>Hh:return {'excluded':'actual_signed_H'}
        values=[]
        if Hh>=0:values +=[qmax(q,max(0,Hl),Hh,True)for q in r['quadratics']]
        if Hl<=0:values +=[qmax(q,max(0,-Hh),-Hl,False)for q in r['quadratics']]
        B=min(F(r['raw']),max(values))
        if B<0 or(P0>0 and KAPPA*N*P0>=B):return {'excluded':'strict_joint_resource'}
        E=min(r['floor']*F(r['D']),B/KAPPA)-N*P0
        if E<0:return {'excluded':'joint_binary_budget'}
        nxt=min(U,hi(E/(inward/M+beta*N/(N*vh+U))))
        if nxt==U:break
        U=nxt
    wh=vh+U/N;swl=sl(vl);swh=sh(wh)
    mx=max(abs(dl),abs(dh),abs(dl+ul),abs(dh+uh));phimin=lo(PHILO*(1-mx*mx/(2*N*vl)));need(phimin>0,'Gaussian interpolation density')
    phase=lo(phimin/swh)if ul>=0 else hi(PHIHI/swl)
    if dh<0:
        pm=PHILO*(1-max(abs(dl),abs(dh))**2/(2*N*vl));need(pm>0,'variance interpolation density')
        varcoef=lo(pm*(-dh)/(2*N*wh*swh))
    else:varcoef=lo(-PHIHI*max(0,dh)/(2*N*vl*swl))
    def mass(p):return F(comb(N,k))*p**k*(1-p)**(N-k)
    ml,mh=mass(pl),mass(pu);mp=mass(max(pl,min(pu,F(k,N))))
    blo=lo(sl(F(N))*min(ml,mh));bhi=hi(sh(F(N))*max(ml,mh,mp))
    ratio=F(1);R=F(0)
    for j in range(k+1,N+1):ratio*=F(N-j+1,j)*pu/(1-pu);R=max(R,ratio)
    cglo=lo((CELO+K/N)/(wh*swh));cghi=hi((CEHI+K/N)/(vl*swl));need(0<cglo<cghi,'two signed cubic multiplier endpoints')
    eps=F(gap(family,index,n)['epsilon'])+K/N
    rhob=(1-2*vh)/sh(vh)if eps>=0 else(1-2*vl)/sl(vl)
    return dict(n=N,k=k,pl=pl,pu=pu,L=F(0),U=U,A0=A,A1=A,d0=d0,gap=lo(eps*rhob),phase=F(0),varcoef=varcoef,
                cglo=cglo,cghi=cghi,blo=blo,bhi=bhi,ul=ul,uh=uh,phasecoef=phase,c=1-d0,R0=hi(R))
KEYS=('n','k','pl','pu','L','U','A0','A1','d0','gap','phase','varcoef','blo','bhi','ul','uh','phasecoef')
def arguments(z,c):return{k:z[k]for k in KEYS}|{'cgain':c}
def affine_gates(z):
    return[r for cg in(z['cglo'],z['cghi'])for r in gate.affine_gates(**arguments(z,cg))]
def leaf_check(z,q):
    need(type(q)is list and len(q)==5 and all(type(x)in(str,int,F)for x in q),'five exact coefficient values')
    q=list(map(F,q));need(q[4]>0,'positive leading coefficient')
    globalq.accept(q,0,z['c'],z['R0'])
    polys=[p for cg in(z['cglo'],z['cghi'])for p in gate.gates(**arguments(z,cg),q=q)]
    need(len(polys)==48,'both gain endpoints and all24 moment/noise/mass corners')
    bs=[x for p in polys for rr in gate.bernstein(p,z['pl'],z['pu'],z['ul'],z['uh'])for x in rr]
    need(min(bs)>0,'strict whole-cell score');return min(bs)
def children(cell,axis):
    pl,pu,ul,uh=cell
    if axis=='p':m=(pl+pu)/2;return[(pl,m,ul,uh),(m,pu,ul,uh)]
    need(axis=='u','fixed split axis');m=(ul+uh)/2;return[(pl,pu,ul,m),(pl,pu,m,uh)]
def same(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b
def accept(obj):
    need(type(obj)is dict and set(obj)=={'schema','family','index','n','source_sha256','gap','trees'}and obj['schema']=='EARLIER737_SIGNED48_V1','exact earlier737 object fields')
    family,index,n=obj['family'],obj['index'],obj['n'];r=cat.row(family,index,n)
    need(type(obj['source_sha256'])is str and obj['source_sha256']==r['source_sha256'],'actual source-law row binding')
    expected=roots(family,index,n);need(same(obj['gap'],gap(family,index,n)),'fresh complete finite binomial proof')
    need(type(obj['trees'])is list and len(obj['trees'])==len(expected),'complete nearest-count/sign roots');stats=dict(quartics=0,excluded=0,splits=0,maxdepth=0,score_coefficients=0)
    def visit(node,k,cell,depth):
        need(type(node)is dict and depth<=16,'bounded exact tree');stats['maxdepth']=max(stats['maxdepth'],depth)
        if 'split'in node:
            need(set(node)=={'split','children'}and type(node['children'])is list and len(node['children'])==2,'both closed children');stats['splits']+=1
            for nd,cc in zip(node['children'],children(cell,node['split'])):visit(nd,k,cc,depth+1)
            return
        z=parameters(family,index,n,k,*cell)
        if set(node)=={'excluded'}:
            need('excluded'in z and type(node['excluded'])is str and z['excluded']==node['excluded'],'reconstructed real exclusion');stats['excluded']+=1;return
        need(set(node)=={'q'}and'excluded'not in z,'literal quartic leaf');leaf_check(z,node['q']);stats['quartics']+=1;stats['score_coefficients']+=48*7*5
    for objroot,(k,sign,cell)in zip(obj['trees'],expected):
        need(type(objroot)is dict and set(objroot)=={'k','sign','tree'}and type(objroot['k'])is int and type(objroot['sign'])is int and(objroot['k'],objroot['sign'])==(k,sign),'ordered actual count/sign roots')
        visit(objroot['tree'],k,cell,0)
    return dict(job=cat.job_id(family,index,n),family=family,index=index,n=n,target_allowance=str(r['K']/n),status='PASS_EXACT_SELECTED_EARLIER_ACQUIRED_PAIR',**stats)
def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return{k:encode(v)for k,v in x.items()}
    if isinstance(x,(tuple,list)):return list(map(encode,x))
    return x
