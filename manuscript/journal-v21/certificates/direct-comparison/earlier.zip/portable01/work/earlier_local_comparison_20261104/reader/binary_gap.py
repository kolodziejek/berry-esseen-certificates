"""Exact all-count binary cap, allowing a signed CE-minus-cap reserve.

The endpoint/CDF arithmetic is the unchanged pinned native implementation.
Only the final positive-epsilon assertion of its convenience `panel` wrapper
is absent: the returned cap is proved regardless of its relation to CE.
The direct score uses the actual target CE+K/n and the correct reserve sign.
"""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import hashlib,importlib.util,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PATH=ROOT/'work/finite_left_replacement_20261104/audit/native/finite_binomial_core.py'
PIN='939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f'
def need(v,s):
    if not v:raise ValueError(s)
need(__debug__ and not sys.flags.optimize,'unoptimized exact binary proof')
need(hashlib.sha256(PATH.read_bytes()).hexdigest()==PIN,'fixed native CDF implementation')
sp=importlib.util.spec_from_file_location('earlier_binary_native',PATH)
native=importlib.util.module_from_spec(sp);sp.loader.exec_module(native)
@lru_cache(maxsize=800)
def panel(n,index,subdiv=128):
    need(type(n)is int and 39<=n<=46 and type(index)is int and 0<index<250,'actual finite binary identity')
    need(type(subdiv)is int and subdiv==128,'fixed complete binary p subdivision')
    M=500*subdiv;first=index*subdiv;last=(index+1)*subdiv
    left=native.endpoint(n,first,M);best=F(-1);where=None
    for a in range(first,last):
        right=native.endpoint(n,a+1,M)
        v=F((a+1)*(M-a-1),M*M)
        factor=native.root(n*v)[1]/(1-2*v)
        for j in range(n+1):
            positive=F(max(0,left[j][3]-right[j][4]),native.S)*factor
            negative=F(max(0,left[j][5]-right[j][0]),native.S)*factor
            for sign,value in(('+',positive),('-',negative)):
                if value>best:best=value;where=[a,j,sign]
        left=right
    cap=F(native.ceildiv(best.numerator*10**9,best.denominator),10**9)
    eps=(native.CE_LO-cap);eps=F(eps.numerator*10**9//eps.denominator,10**9)
    return dict(n=n,index=index,p=[str(F(index,500)),str(F(index+1,500))],subdivisions=subdiv,score_cap=str(cap),epsilon=str(eps),maximizing_box=where,closed_boxes=subdiv*(n+1)*2)
