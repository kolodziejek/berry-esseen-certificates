# Exact semantics of the selected strict Sturm reader

Reviewed, without modifying:

* `work/finite_left_replacement_20261104/audit/quartic_sturm.py`, SHA256
  `1f815ccb23692f78be98691a76a5fe0605f8995abdab5d9a3964f1625a4c2617`.
* Its fixed target constructor `quartic_global.py`, SHA256
  `0760d772b6cf1858ed139a1fe179490cb1e523a5d685a37a25271a10b349aa35`.

Mathematical status: locally derived and checked sufficient positivity test.
It is deliberately incomplete for nonnegative polynomials or repeated factors.
This review concerns global algebraic majorization, not probabilistic reduction.

## Exact theorem implemented by positive

For a nonzero rational polynomial P of degree at most4 the reader first
requires P(0)>0 and P(1)>0. Constants then pass. Otherwise it constructs
P0=P, P1=P', P_(j+1)=-rem(P_(j-1),P_j), using exact rational long division,
until the next remainder is zero. It requires the last nonzero polynomial
to be a constant. This is precisely the condition gcd(P,P') is constant,
so all roots of P are simple over the complex numbers. The code does not
divide out repeated factors or silently count only sign-changing roots.

Let V(x) count sign changes in the evaluated list after zeros are deleted.
At a zero of an intermediate P_j, its neighboring nonzero entries have
opposite signs, because P_(j-1)=-P_(j+1) there. No two consecutive entries
can vanish: recurrence would propagate to the nonzero constant. The two
adjacent sign comparisons therefore contribute one on either side of that
zero; V does not change. At a zero r of P, P'(r) is nonzero. As x passes r,
the initial signs change from opposite to equal, so V decreases by exactly
one. Thus V(0)-V(1) is the number of roots of P in (0,1). Endpoint zeros of
P were already rejected, while deleting zeros of intermediate polynomials
at the endpoints gives the continuous value of V there. The reader requires
V(0)=V(1), hence P has no zero on [0,1]. Continuity and P(0)>0 imply strict
positivity throughout the interval.

This counts all roots of the admitted squarefree polynomial. In particular,
positive endpoints do not conceal a negative interval between two roots.
An even-multiplicity contact zero is rejected by the gcd requirement.
A strictly positive polynomial with a repeated complex or exterior root
is also rejected; this is conservative rejection, not a false proof.
The zero polynomial, degree>4, Boolean/float coefficients and zero endpoints
are rejected. Rational representations are converted to exact Fraction.

## Global staircase targets and endpoints

For c>0, R>=0, phase upper bound u and J=8, define
psi_u(w)=-1{w>u}+R*max(0,floor((u-w)/c)). The ten fixed polynomials are:

1. Q(u+s)+1 on the right ray s>=0;
2. Q(w)-R*j on each closed interval
   [u-(j+1)c,u-jc], j=0,...,J-1;
3. Q(u-Jc-s)-R*J-(R/c)*s on the left ray s>=0.

Finite intervals are mapped affinely to [0,1]. At a step's left endpoint
w=u-(j+1)c the staircase equals R*(j+1), rather than R*j. The adjacent
interval j+1 supplies that stronger value at its right endpoint; for the
last interval the left-ray polynomial supplies R*J. At w=u the zero-step
interval supplies Q(u)>0, whereas the outgoing ray alone would only give
Q(u)>-1. Thus closed incoming jumps and the strict outgoing event are both
covered; no endpoint convention is left to a numerical tolerance.

For a ray polynomial A(s) of degree<=4 the reader constructs
R_A(t)=(1-t)^4 A(t/(1-t)). This is an exact polynomial, including its
endpoint R_A(1), the fourth-degree coefficient of A. If R_A>0 on [0,1],
then A(s)>0 for every finite s>=0, by t=s/(1+s). Requiring positivity also
at t=1 is a sufficient asymptotic guard, not an evaluation at infinity.
It conservatively rejects a lower-degree ray target. For the left ray,
floor(J+s/c)<=J+s/c makes its linear envelope sufficient for all remaining
steps. These facts prove Q>=psi_u on the whole real line. Finally psi_u(w)
is nondecreasing in u, so a fixed upper-phase target also covers every
smaller phase. The translated method sets this fixed phase to0 and applies
Q to W-u, preserving the actual variable phase exactly.

The separately checked q4>=0 is the sign needed when replacing the fourth
moment by its upper bound. Strict ray endpoints already force q4>0 in every
accepted object. No Poisson comparison, convexity of Q itself, or unproved
probabilistic premise is part of this reader.

## Implementation audit

`trim` removes only exact trailing zeros. Long division subtracts the exact
leading multiple and strictly lowers the remainder degree. The signed
remainder sequence is therefore finite. A nonzero constant final entry is
explicitly required. `variation` ignores exact zeros and uses exact signs.
`fixed_targets` is bound by source hash and is recomputed from the five
quartic coefficients and external c/R/phase parameters. Objects cannot
replace or omit a positivity target. The degree4 compactification uses
the binomial expansion of (1-t)^(4-j), with the ray direction handled by
the preceding affine substitution. I found no gap in these semantics.

The companion exact probes distinguish two simple interior roots from a
double contact root; test repeated exterior/complex roots, strict endpoints,
constant and zero targets, and independently evaluate affine/compactified
targets and actual staircase collisions. These are adverse checks of the
implementation; the proof above establishes the continuous-domain claim.
