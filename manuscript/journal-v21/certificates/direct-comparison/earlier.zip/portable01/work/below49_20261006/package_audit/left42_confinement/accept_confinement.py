"""Fixed ordinary-Python acceptance of first LEFT42 confinement and feedback."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,copy,sys
import confinement_core as c
assert __debug__ and not sys.flags.optimize and len(sys.argv)==1
HERE=Path(__file__).resolve().parent
ACQ=HERE.parent/'left42_exact'
def need(v,msg):
 if not v:raise ValueError(msg)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def load(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(same(x,y)for x,y in zip(a,b))
 return a==b
source=Path('pre_sperner42_exact.json');routep=Path('fixed_amplitudes.json');proofp=Path('confinement42_proof.json');postp=Path('post_sperner42_exact.json')
seed=load(source);route=load(routep);proof=load(proofp);post=load(postp)
need(sha256(source.read_bytes()).hexdigest()==sha256((ACQ/source.name).read_bytes()).hexdigest(),'same acquired resource file')
acq=load(ACQ/'acquisition42_proof.json');source_rows=[dict(z['final'],radius=z['radius'])for z in acq['fine']if not z['final'].get('excluded')]
need(same(source_rows,seed['rows']),'direct exact acquired rows')
need(type(seed['N'])is int and seed['N']==42 and seed['L']==48 and len(seed['rows'])==45,'input finite scope and coverage')
need(route['N']==42 and route['L']==48 and len(route['rows'])==45,'fixed route scope')
need(set(proof)=={'status','N','L','source_sha256','route_sha256','rows'},'fixed proof schema')
need(proof['status']=='EXACT_CONFINEMENT_DISCOVERY' and type(proof['N'])is int and proof['N']==42 and proof['L']==48 and len(proof['rows'])==45,'proof finite scope')
need(proof['source_sha256']==sha256(source.read_bytes()).hexdigest() and proof['route_sha256']==sha256(routep.read_bytes()).hexdigest(),'fixed input bytes')
need(post['N']==42 and post['L']==48 and len(post['rows'])==45,'post output complete scope')
want=[];gates=0;configs=0
for j,(z,r,expected)in enumerate(zip(seed['rows'],route['rows'],proof['rows'])):
 need([F(z['pl']),F(z['pu'])]==[F(145+j,500),F(146+j,500)],'ordered exact p cover')
 actual=c.enc(c.panel(z,r));need(same(actual,expected),'same-law first confinement and feedback replay');need(same(actual['final'],post['rows'][j]),'post resource output binding')
 configs+=2*len(actual['trace']);gates+=sum(x['gates']['count']for t in actual['trace']for x in t['signs']);want.append(actual)
 print('REPLAY_LEFT42_CONFINEMENT',j,flush=True)
def rejected(label,fn):
 try:fn()
 except (ValueError,AssertionError,KeyError,TypeError,IndexError):print('NEGATIVE_CONTROL_REJECTED',label,flush=True)
 else:raise ValueError('negative control accepted '+label)
def valid_rows(z):need(same(z,want),'fixed complete proof rows')
for label,fn in [('missing',lambda z:z.pop()),('reordered',lambda z:z.reverse()),('duplicated',lambda z:z.__setitem__(1,copy.deepcopy(z[0]))),('false_amplitude',lambda z:z[0]['trace'][0].update(amplitude='1/100')),('false_radius',lambda z:z[0]['trace'][0].update(radius='1')),('false_inward',lambda z:z[0]['final'].update(inward_d_max='0')),('false_noise',lambda z:z[0]['final'].update(lambda_max='0')),('missing_phase',lambda z:z[0]['trace'][0]['signs'].pop()),('changed_phase',lambda z:z[0]['trace'][0]['signs'][0]['config'].update(phase_sign=1)),('false_gate_count',lambda z:z[0]['trace'][0]['signs'][0]['gates'].update(count=True)),('extra_field',lambda z:z[0].update(unrestricted=True))]:
 q=copy.deepcopy(proof['rows']);fn(q);rejected(label,lambda:valid_rows(q))
rejected('duplicate_json',lambda:json.loads('{"x":1,"x":2}',object_pairs_hook=unique))
q=copy.deepcopy(route['rows'][0]);q['amplitudes']=['1/100'];rejected('actual_false_amplitude',lambda:c.panel(seed['rows'][0],q))
print('PASS_FIXED_LEFT42_FIRST_CONFINEMENT_FEEDBACK',45,'panels',configs,'signed_configs',gates,'strict_gates',13,'negative_controls',flush=True)
