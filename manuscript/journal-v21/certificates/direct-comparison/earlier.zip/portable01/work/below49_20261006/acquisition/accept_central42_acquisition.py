"""Read-only, fixed-scope acceptance of the new central42 acquisition."""
from pathlib import Path
from hashlib import sha256
import json,copy,sys
import central42_acquisition_core as c
def need(x,s):
    if not x:raise ValueError(s)
def unique(pairs):
    out={}
    for k,v in pairs:need(k not in out,'duplicate JSON key');out[k]=v
    return out
def strict_equal(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(strict_equal(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(strict_equal(x,y)for x,y in zip(a,b))
    return a==b
def validate(got,want):need(strict_equal(got,want),'false or malformed acquisition object')
need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed unoptimized invocation')
need(sha256(Path('initial42_candidate.json').read_bytes()).hexdigest()=='bd2a808005703ac1fbdb5fb17bc63637f48ebb568f65220f99c47692108a23e0','fixed INITIAL42 weighted dependency')
blob=Path('central42_acquisition_candidate.json').read_bytes();got=json.loads(blob,object_pairs_hook=unique)
want=c.enc(c.build(False));validate(got,want)
cases=[]
def add(label,fn):
    z=copy.deepcopy(got);fn(z);cases.append((label,z))
add('missing parent',lambda z:z['prep'].pop())
add('missing child',lambda z:z['fine'].pop())
add('reordered child cover',lambda z:z['fine'].reverse())
add('duplicated cell',lambda z:z['fine'].__setitem__(1,copy.deepcopy(z['fine'][0])))
add('boolean index',lambda z:z['fine'][1].update(index=True))
add('false raw target',lambda z:z['fine'][0].update(raw='1/100'))
add('false variance target',lambda z:z['fine'][0].update(lambda_max='1/1000000'))
add('wrong endpoint',lambda z:z['fine'][0].update(pu='39/100'))
add('missing joint premise',lambda z:z['fine'][0].update(joint_inward_noise=False))
add('false support sign',lambda z:z['prep'][0]['radius_proof'].update(maximum='0'))
add('false strip sign',lambda z:z['fine'][0]['strip_proof'].update(maximum='0'))
add('changed floor',lambda z:z.update(N=41))
add('changed source',lambda z:z.update(source_sha256='0'*64))
add('extra field',lambda z:z.update(extra=True))
for label,z in cases:
    try:validate(z,want)
    except ValueError:pass
    else:raise ValueError('negative control accepted: '+label)
try:json.loads('{"x":1,"x":2}',object_pairs_hook=unique)
except ValueError:pass
else:raise ValueError('duplicate JSON key accepted')
print(json.dumps(dict(status='PASS_CENTRAL42_ACQUISITION',N=42,central_closed_cells=50,
    surviving_cells=sum(not q.get('excluded')for q in got['fine']),
    radius_cells=sum(q['radius_proof']['cells']for q in got['prep']),
    strip_cells=sum(q['strip_proof']['cells']for q in got['fine']if not q.get('excluded')),
    negative_controls=len(cases)+1,source_sha256=got['source_sha256'],proof_sha256=sha256(blob).hexdigest(),
    mathematical_status='Conditional on the separately accepted INITIAL42 weighted interface, attained contact, 0<=n*a_n<=.7, decrement<=.19 and current C<.4247; central p cover only.'),indent=2),flush=True)
