"""Fixed exact replay of LEFT42 acquisition and first .575 support strip.

No floating arithmetic, search, or proof-object repair. All actual-p panels,
first support bridge, ordered radius refinements and strip cells are replayed.
This proves a finite42..48 conditional reduction; the stated global inputs and
subsequent local comparisons remain separate DAG dependencies.
"""
import json,sys,hashlib,copy
from pathlib import Path
from fractions import Fraction as F
import coupled_panel_core as c
import corrected_phase_callback_extended as phase
import fifth_heat50 as fifth,heat_support50 as heat
import panel_exterior42 as exterior
assert __debug__ and not sys.flags.optimize
phase.install(c.k)
def need(v,msg):
 if not v:raise ValueError(msg)
def unique(pairs):
 out={}
 for k,v in pairs:
  need(k not in out,'duplicate JSON key');out[k]=v
 return out
def load(path):return json.loads(path.read_text(),object_pairs_hook=unique)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(same(x,y)for x,y in zip(a,b))
 return a==b
def encode(x):
 if type(x)is F:return str(x)
 if isinstance(x,list):return[encode(v)for v in x]
 if isinstance(x,dict):return{k:encode(v)for k,v in x.items()}
 return x
def inp(z):return{k:F(z[k])for k in('pl','pu','raw','D','theta','rho','beta')}
base=heat.constants
def support(z,R):
 def constants(N,last,K):
  C,_,_,ell,S=base(N,last,K);return C,z['rho'],z['beta'],ell,S
 heat.constants=constants
 try:return fifth.target(42,48,F(0),R,F('.19'))
 finally:heat.constants=base
source=Path('initial42_candidate.json');initial=load(source);route=load(Path('fixed_route.json'))
proof=load(Path('acquisition42_proof.json'));target_source=Path('strip_targets.json');targets=load(target_source);strip=load(Path('strip42_proof.json'))
def structure(pr,ro,ta,st):
 need(set(pr)=={'status','N','L','cap','source_sha256','route_sha256','coarse','first_bridge','fine'},'proof fields')
 need(pr['status']=='EXACT_ACQUISITION_CANDIDATE' and type(pr['N'])is int and pr['N']==42 and pr['L']==48 and F(pr['cap'])==F('.4226'),'finite scope')
 need(pr['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest(),'INITIAL42 bytes')
 need(pr['route_sha256']==hashlib.sha256(Path('fixed_route.json').read_bytes()).hexdigest(),'fixed route bytes')
 need(ro['N']==42 and ro['L']==48 and F(ro['cap'])==F('.4226') and F(ro['first_radius'])==F('3.025'),'fixed route scope')
 need(len(pr['coarse'])==15 and len(pr['fine'])==55 and len(ro['rows'])==55,'complete acquisition counts')
 for j,z in enumerate(pr['coarse']):need(list(map(F,z['input_p']))==[F(23+j,100),F(24+j,100)],'coarse order/coverage')
 for j,(z,r)in enumerate(zip(pr['fine'],ro['rows'])):
  p=[F(135+j,500),F(136+j,500)];need(list(map(F,z['p']))==p and list(map(F,r['p']))==p,'fine order/coverage')
  need(set(z)=={'p','trace','final','radius'} and bool(z['trace']),'fine schema')
  rs=list(map(F,r['radii']));need(rs[0]==F('3.025') and all(b<a for a,b in zip(rs,rs[1:])),'support order')
  need(len(z['trace'])==len(rs) and F(z['radius'])==rs[-1],'radius trace length')
  need(z['final']==z['trace'][-1]['resource'],'final same-law binding')
  need(bool(z['final'].get('excluded'))==r['excluded']==(j<10),'fixed active/excluded coverage')
 need(ta['N']==42 and ta['L']==48 and F(ta['strip'])==F('23/40') and len(ta['rows'])==45,'strip target scope')
 need(st['N']==42 and st['L']==48 and len(st['rows'])==45,'strip proof scope')
 need(st['source_sha256']==hashlib.sha256(target_source.read_bytes()).hexdigest(),'strip target bytes')
 for j,h in enumerate(ta['rows']):need(list(map(F,h['p']))==[F(145+j,500),F(146+j,500)],'strip full coverage')
structure(proof,route,targets,strip)
need(len(initial['panels'])==100,'initial complete hundred panels')
for j,r in enumerate(initial['panels']):need([F(r['pl']),F(r['pu'])]==[F(j,100),F(j+1,100)],'initial panel order')
need([j for j,z in enumerate(initial['panels'][:38])if z['cells']]==list(range(23,38)),'initial lower emptiness')
coarse=[]
for j,expected in zip(range(23,38),proof['coarse']):
 row=initial['panels'][j];z=c.cell(42,F('3.84'),F('.4226'),inp(row),steps=48);z['input_p']=[F(row['pl']),F(row['pu'])]
 need(same(encode(z),expected),'coarse exact replay');coarse.append(z);print('REPLAY_COARSE42',j,flush=True)
active=[z for z in coarse if not z.get('excluded')];mom=dict(rho=max(z['rho']for z in active),beta=max(z['beta']for z in active))
need(same(encode(support(mom,F('3.025'))),proof['first_bridge']),'first factual support bridge')
parents=[(z,j)for z in active for j in range(5)];need(len(parents)==55,'all active coarse children')
for index,((parent,j),expected,route_row)in enumerate(zip(parents,proof['fine'],route['rows'])):
 row=inp(parent);row.update(pl=parent['pl']+F(j,500),pu=parent['pl']+F(j+1,500));need([row['pl'],row['pu']]==list(map(F,expected['p'])),'child containment')
 for step,(R,entry)in enumerate(zip(map(F,route_row['radii']),expected['trace'])):
  bridge=None if step==0 else support(row,R)
  z=c.cell(42,R,F('.4226'),row,steps=48)
  need(same(encode(dict(radius=R,contraction=bridge,resource=z)),entry),'ordered exact fine replay')
  if z.get('excluded'):need(step==len(expected['trace'])-1,'excluded continuation');break
  row=inp(z)
 if not z.get('excluded'):
  h=targets['rows'][index-10];need(list(map(F,h['p']))==[z['pl'],z['pu']] and F(h['radius'])==R,'strip actual panel and radius')
  for key in('theta','rho'):need(z[key]<=F(h[key]),'strip input '+key)
  need(z['beta']<=F(h['beta_upper']) and max(z['Hplus'],z['Hminus'])<=F(h['H']),'strip signed moment inputs')
 print('REPLAY_FINE42',index,flush=True)
stripcells=0
for j,(h,expected)in enumerate(zip(targets['rows'],strip['rows'])):
 z=exterior.from_hypotheses(h,F('23/40'));need(same(z,expected),'all exterior cells exact replay')
 need(all(F(row['upper'])<0 for row in z['rows']),'strict entire support exterior')
 stripcells+=len(z['rows']);print('REPLAY_STRIP42',j,flush=True)
# Malformed proof, coverage, scope, and actual arithmetic negative controls.
def rejected(label,fn):
 try:fn()
 except (ValueError,AssertionError,KeyError,TypeError,IndexError):print('NEGATIVE_CONTROL_REJECTED',label,flush=True)
 else:raise ValueError('negative control accepted '+label)
for label,mut in [('missing_coarse',lambda q:q['coarse'].pop()),('duplicate_fine',lambda q:q['fine'].__setitem__(12,q['fine'][11])),('reordered_fine',lambda q:q['fine'].reverse()),('changed_scope',lambda q:q.__setitem__('N',41)),('wrong_source',lambda q:q.__setitem__('source_sha256','0'*64)),('wrong_final',lambda q:q['fine'][12]['final'].__setitem__('D','0')),('missing_trace',lambda q:q['fine'][12]['trace'].pop())]:
 q=copy.deepcopy(proof);mut(q);rejected(label,lambda:structure(q,route,targets,strip))
q=copy.deepcopy(route);q['rows'][12]['radii'][-1]='4';rejected('unlicensed_radius_order',lambda:structure(proof,q,targets,strip))
q=copy.deepcopy(targets);q['rows'][3]['p'][0]='0';rejected('strip_probability_gap',lambda:structure(proof,route,q,strip))
rejected('actual_false_radius',lambda:support(mom,F('1')))
h=copy.deepcopy(targets['rows'][20]);h['H']='2';h['rho']='1.85';h['beta_upper']='.9'
def false_strip():
 z=exterior.from_hypotheses(h,F('.1'));need(all(F(r['upper'])<0 for r in z['rows']),'false strip arithmetic')
rejected('actual_false_strip',false_strip)
rejected('duplicate_json_key',lambda:json.loads('{"x":1,"x":2}',object_pairs_hook=unique))
rejected('boolean_integer_swap',lambda:need(same({'x':True},{'x':1}),'strict bool distinction'))
print('PASS_FIXED_LEFT42_ACQUISITION_AND_STRIP_0575',15,'coarse',55,'fine',45,'active',stripcells,'strip_cells',13,'negative_controls',flush=True)
