"""New exact central acquisition at floor42, with explicitly bound premises.

INITIAL42 supplies raw R<=r and the WEIGHTED invariant nD<=42*d.
Every zero-barrier update preserves that invariant. Actual support is
contracted only after the entire exterior cover has strictly negative contact.
The independent local theorem and complementary p cover are not asserted here.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import coupled_panel_core as c
import corrected_phase_callback_v2 as correction
import panel_exterior as exterior
correction.install(c.k)
N=42;CAP=F('.4247');SCALE=10**6
assert __debug__ and not sys.flags.optimize and exterior.N==N
def need(v,s):
    if not v:raise ValueError(s)
def up(x):return c.k.up(x,SCALE)+F(1,SCALE)
def down(x):return c.k.down(x,SCALE)-F(1,SCALE)
def enc(v):
    if isinstance(v,F):return str(v)
    if isinstance(v,list):return [enc(x)for x in v]
    if isinstance(v,dict):return {k:enc(x)for k,x in v.items()}
    return v
def bounded(z):
    if z.get('excluded'):return dict(excluded=True,reason=z['reason'],stage=z['stage'])
    out={k:z[k]for k in ('pl','pu')}
    for key in ('raw','D','theta','rho','beta','lambda_max','inward_d_max','Hplus','Hminus'):
        if key in z:out[key]=up(z[key])
    for key in ('A','B','beta_lo'):
        if key in z:out[key]=down(z[key])
    if 'quadratics'in z:
        out['quadratics']=[{k:(down(v)if k in ('Qraw','Qbudget')else up(v))for k,v in q.items()if k in ('A','Fplus','Fminus','Qraw','Qbudget')}for q in z['quadratics']]
    out['joint_inward_noise']=True
    return out
def radius_gates(z):
    h=max(z['Hplus'],z['Hminus']);rho=z['rho'];bl=z['beta_lo'];bu=z['beta']
    need(0<=bl<=bu<1 and 0<h<2,'central support row domain')
    vals=[]
    for j in range(54):
        a=F('2.5')+F(j,40);b=a+F(1,40)
        vals.extend((exterior.support_cell(h,rho,bl,bu,a,b),exterior.support_cell(h,rho,bl,bu,-b,-a)))
    need(len(vals)==108 and max(vals)<0,'full central actual-radius contraction')
    return dict(cells=108,maximum=max(vals),sha256=sha256(json.dumps(enc(vals),separators=(',',':')).encode()).hexdigest())
def strip_gates(z):
    hyp=dict(p=[str(z['pl']),str(z['pu'])],theta=str(z['theta']),rho=str(z['rho']),beta_upper=str(z['beta']),H=str(max(z['Hplus'],z['Hminus'])))
    result=exterior.from_hypotheses(hyp)
    vals=[F(row['upper'])for row in result['rows']]
    need(vals and max(vals)<0,'full transformed-support strip contraction')
    return dict(cells=len(vals),maximum=max(vals),sha256=sha256(json.dumps(result['rows'],sort_keys=True,separators=(',',':')).encode()).hexdigest())
def build(emit=False):
    initial_path=Path('initial42_candidate.json');blob=initial_path.read_bytes();initial=json.loads(blob)
    need(initial['name']=='INITIAL42_R384'and len(initial['panels'])==100,'named complete INITIAL42 source')
    prep=[];fine=[]
    for j in range(38,48):
        source=initial['panels'][j]
        need(source['cells']>0,'nonempty initial parent')
        row={key:F(source[key])for key in ('pl','pu','raw','D','theta','rho','beta')}
        need(row['pl']==F(j,100)and row['pu']==F(j+1,100),'same closed source cell')
        out=bounded(c.cell(N,F('3.84'),CAP,row,steps=48))
        need(not out.get('excluded')and'quadratics'in out,'selected central parent survives')
        out['radius_proof']=radius_gates(out);prep.append(out)
        if emit:print('EXACT_CENTRAL42_PREP',j,enc({k:out[k]for k in ('raw','D','theta','rho','Hplus','Hminus')}),flush=True)
        for i in range(5):
            index=5*j+i
            row={key:out[key]for key in ('raw','D','theta','rho','beta')}
            row.update(pl=F(index,500),pu=F(index+1,500))
            z=bounded(c.cell(N,F('2.5'),CAP,row,steps=48))
            z.update(index=index-190,pl=row['pl'],pu=row['pu'])
            if not z.get('excluded'):z['strip_proof']=strip_gates(z)
            fine.append(z)
            if emit:print('EXACT_CENTRAL42_FINE',index,'EXCLUDED'if z.get('excluded')else enc({k:z[k]for k in ('raw','D','theta','lambda_max','inward_d_max')}),flush=True)
        checkpoint=dict(schema='CENTRAL42_ACQUISITION_V1',N=N,source_sha256=sha256(blob).hexdigest(),prep=prep,fine=fine)
        if emit:Path('central42_acquisition_progress.json').write_text(json.dumps(enc(checkpoint),indent=2)+'\n')
    need(len(prep)==10 and len(fine)==50,'complete ordered central cover')
    return dict(schema='CENTRAL42_ACQUISITION_V1',N=N,current_score_cap=CAP,source_sha256=sha256(blob).hexdigest(),weighted_invariant='n*D <= 42*D_row',joint_resource='din/din0 + lambda/Lambda <= 1 on every surviving final row',prep=prep,fine=fine)
