"""Fixed exact single39 stage acceptance with typed proof comparison and source binding."""
from pathlib import Path
import json,hashlib,sys,ast,copy
H=Path(__file__).resolve().parent
STAGES={'acquisition':('acquisition39_core','acquisition39_candidate.json',['acquisition39_plan.json','../initial/initial39_candidate.json']),'confinement':('confinement39_core','confinement39_candidate.json',['confinement39_plan.json','acquisition39_candidate.json']),'profiles':('profile39_core','profiles39_candidate.json',['confinement39_candidate.json'])}
def need(v,s):
 if not v:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def closure(start):
 seen=set();todo=[start,'accept_stage39.py']
 while todo:
  name=todo.pop()
  if name in seen:continue
  seen.add(name)
  for node in ast.walk(ast.parse((H/name).read_text())):
   mods=[a.name for a in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)else[]
   for mod in mods:
    if mod and(H/(mod+'.py')).is_file():todo.append(mod+'.py')
 return seen
def validate(a,b):need(same(a,b),'typed complete exact proof mismatch')
def reject(label,fn,out):
 try:fn()
 except(ValueError,TypeError,KeyError,AssertionError):out.append(label);return
 raise ValueError('negative control accepted '+label)
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize,'unoptimized interpreter')
 need(len(sys.argv)==2 and sys.argv[1]in STAGES,'one fixed stage')
 stage=sys.argv[1];module,proof,targets=STAGES[stage]
 manifest=read(H/f'{stage}39_manifest.json');need(manifest['schema']=='SINGLE39_FIXED_STAGE_INPUTS_V1'and manifest['stage']==stage,'fixed manifest scope')
 files=closure(module+'.py')|set(targets)|{proof}
 need(set(manifest['sha256'])==files,'complete explicit source and target closure')
 for name,digest in manifest['sha256'].items():need(sha(H/name)==digest,'immutable stage input '+name)
 c=__import__(module);expected=c.enc(c.build(True));actual=read(H/proof);validate(actual,expected)
 control=[]
 mutations=[('wrong index',lambda z:z.update(N=40)),('boolean index',lambda z:z.update(N=True)),('missing schema',lambda z:z.pop('schema')),('extra scope',lambda z:z.update(extra=True)),('changed source digest',lambda z:z.update(source_sha256='0'*64))]
 listkey='fine'if stage=='acquisition'else'rows'
 mutations.extend([('missing row',lambda z:z[listkey].pop()),('reordered rows',lambda z:z[listkey].reverse()),('duplicate row',lambda z:z[listkey].__setitem__(1,z[listkey][0])),('false row index',lambda z:z[listkey][0].update(index=False))])
 for label,fn in mutations:
  bad=copy.deepcopy(actual);fn(bad);need(not same(bad,actual),'active mutation');reject(label,lambda:validate(bad,expected),control)
 reject('duplicate JSON key',lambda:json.loads('{"N":39,"N":40}',object_pairs_hook=unique),control)
 reject('unknown stage',lambda:need('unknown'in STAGES,'fixed stage'),control)
 print(json.dumps(dict(status='PASS_SINGLE39_FIXED_'+stage.upper(),scope='Single39, current excess39*a39>=741/4000, decrement<=33/100, currentcap.4226 and acquired preceding stage. The full theorem requires the separate source-DAG composition.',proof_sha256=sha(H/proof),manifest_sha256=sha(H/f'{stage}39_manifest.json'),source_sha256=manifest['sha256'],negative_controls=control,rows=len(actual[listkey])),indent=2),flush=True)
