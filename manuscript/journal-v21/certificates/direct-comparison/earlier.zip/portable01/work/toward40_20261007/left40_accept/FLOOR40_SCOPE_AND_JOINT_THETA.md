# Floor40 scope and the noise-conditioned variance bound

Mathematical status: independently derived extension of the existing analytic estimates. Execution status: finite-band initial support freshly passes. A full q=.19 finite-band route failed at radius2.725 and was not promoted; its rerouting exploration was stopped when the weaker indexed premise below was selected. The selected zero-decrement band replay is in progress. The old single40 certificates are unchanged.

## 1. Exact noise-conditioned variance

For the one common law let p be its sign probability, theta its conditional variance defect, and lambda=n*p*(1-p)*theta/(1-theta). On a closed probability cell let v_min=min p(1-p)>0. On a closed noise cell lambda<=b, for n>=40,

    40*v_min*theta <= lambda*(1-theta) <= b*(1-theta).

Hence theta<=b/(40*v_min+b). Intersecting this with the global theta ceiling is valid, including b=0. This is an actual-law implication, not an independent optimization of theta and lambda.

The separate joint source inequality din/din0+lambda/Lambda<=1 gives din<=din0*(1-a/Lambda) when lambda>=a. Both restrictions hold for that same law on [a,b], so they may simultaneously enter Sperner. Other scalar and coherent phase-quadratic bounds remain valid on the smaller domain. The dynamic theta bound can improve the conditional beta interval and endpoint geometry; no recomputation of the original joint intercepts is needed.

## 2. Which invariant is required

For a floor N=40, the resource row's D entry must mean **n*D_actual<=40*d_row**. It then also implies D_actual<=d_row, which is enough for all probability/geometry and bounded-moment estimates. A proof of only D_actual<=d_row would not license the finite-band noise intercept computed with40.

Each Fourier contact update bounds

    kappa*n*D_actual <= budget_N(H),   kappa=997/15000.

Thus replacing d_row by budget_N/(kappa*40), and taking its minimum with the previous d_row, preserves the weighted invariant. A negative budget is a contradiction directly.

For a same-law resource lower bound

    D_actual >= binary+6(1-theta)(A+B)*din+K*theta,

multiply by n, use n>=40 and theta=(1-theta)*lambda/(n*pq), then use theta<=Theta and pq<=pqmax. The weighted invariant yields

    40*residual >=40*(1-Theta)*6(A+B)*din
                   +(1-Theta)*K*lambda/pqmax.

This gives exactly the floor40 joint intercepts exported by the coupled core. Their outward rounding preserves the inequality.

## 3. The signed initializer and coupled core

The signed initializer's only uses of nmax are its index-domain gate and score floor .4095+K/nmax. Here K=0, so changing the declared ceiling40 to42 does not change any arithmetic coefficient. Its iteration must be read with the weighted invariant above. The same exact source table therefore has a separate floor40 interpretation once its all-index analytic estimates are invoked; its original single40 execution label is not silently changed.

The index-dependent Fourier error envelopes decrease for actual n>=N after the retained explicit gates:

- a0=(n-1)/(2n) and b0=(45-M)(1-2/n)/96 increase; their inverse powers and the sixth-order positive remainder coefficients decrease.
- The paired multiplier (n/(n-1))^(3/2) and its products with1/(n-1) decrease. Paired coefficient rectangles depend on the same actual moments, not on n.
- The positive HIGH pieces use n^(-1), n^(-1/2), and sqrt(n)*exp(-c*n); the latter decreases when2*N*c>1, exactly the retained monotonicity gates. The rational Mills factor r(x)=(x+2)/(x^2+4*x+2) is positive and decreasing.
- The optional improved zero-piece sqrt(n)*exp(-x)*r(x), x=n*k*b^2, decreases for x>=1/4: after multiplying its logarithmic derivative by a positive denominator, the numerator is4-10x-22x^2-13x^3-2x^4, already negative at1/4 and decreasing thereafter. This is the retained branch gate.
- The improved comparator uses sqrt(n)*exp(-n/8)*(2*r(n/8)+g/3), decreasing for n>=5.

These are monotonicity statements for the analytic envelopes. The outward-rounded exponential routine need not itself be monotone as a function of its argument: it is evaluated only atN to bound the analytic endpoint value.

The density floor is phi_N=phi(0)*(1-5*raw/(2N)); it encloses the actual density from below for n>=N. The signed coefficient reductions range over [phi_N,.4]. In particular, the corrected paired curvature is C*rho+min(phi_N*g0,.4*g0)/2, with g0=3.16*rho-3-d. This handles either sign. The general curvature includes its explicit negative-part correction for the same reason. It is not justified by assuming every signed term separately decreases in n.

The conserved phase price uses the smaller factor1-5*raw/(2N) and the weaker defect ceiling d. Its coefficient is explicitly checked positive. Thus the same floor40 phase-quadratic envelopes and phase roots hold under the weighted invariant.

## 4. Contact support: one essential upper-endpoint change

The transformed exterior calculation drops each potentially negative Gaussian error coefficient and divides nonnegative remainders byN^j. Its excess contribution uses max(Q,0)*.54/N under a_n<=.54/n. Its deletion scale and scale-error terms likewise use floorN. Consequently its formula is valid throughout40<=n<=42 under the stated moment, score, decrement and actual-support premises.

The fifth-order all-H support theorem is different. It retains a **favorable** fifth derivative term. Its lower coefficient must use1/[120*(L-1)] with the upper index endpoint L, while its upper coefficient uses1/[120*(N-1)]. Therefore calls target(40,40,...) prove only the single40 statement; target(40,42,...) must be checked for the finite band. For the selected indexed theorem, retain n=40 with delta40<=.19 and add n in{41,42} with delta_n=0. The project defines delta_n=n(C_{n-1}-C_n)_+, so a least failure after a nonpositive predecessor has exactly delta_n=0. The private indexed replay checks both target(40,40,0,R,.19) and target(40,42,0,R,0) at every selected radius contraction and records both proofs. No old single40 support PASS is promoted by renaming.

Fresh initial-band support already passes target(40,42,0,3.84,.19). The stronger q=.19 assumption on the entire band was unnecessary and its first attempted fixed route failed at fine cell156, radius109/40. The new indexed object retains the original resource/confinement targets and tests the zero-decrement band gates instead.

## 5. Sperner at a floor

The first and profile confinement inequalities are floor estimates, retaining their original domain and strict gates. The two-deletion factor is bounded by sqrt(max((40/39)^3,40/38)); the binomial mode bound uses J>=38 and the wider endpoint interval obtained at38. All moment charges involving n are weakened to40; positive errors divided by n are enlarged by dividing by40. Expressions containing a retained negative moment penalty are derived before this replacement, and the required nonnegative inverse terms are executable gates. Gaussian density lower bounds use1-H^2/(2*40), with signed upper/lower endpoints retained separately.

This proves a new finite-band interpretation of a floor40 Sperner certificate under the weighted source invariant. It does not, by itself, prove a local comparison or justify changing a negative correction I/n into I/40. The final local comparator must use its independently checked finite-band signed correction (or prove a uniform sign).
