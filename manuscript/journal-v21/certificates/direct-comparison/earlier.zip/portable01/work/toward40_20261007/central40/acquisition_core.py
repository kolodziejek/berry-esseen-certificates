"""Single N40 central/upper acquisition from a source-bound INITIAL40.

Premises: actual positive extremal witness; n=40; current score <.4226;
0<=a40<=.54/40; decrement<=.19; actual support[-3.84,3.84].
INITIAL40 supplies a complete source-law moment table. This module only
acquires the probability part [.38,1]; LEFT coverage is a separate edge.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import candidate_panel40 as c
import corrected_phase_callback_extended as correction
import panel_exterior40 as exterior
correction.install(c.k)
N=40;CAP=F('.4226');SCALE=10**6
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def need(v,s):
 if not v:raise ValueError(s)
def enc(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,list):return [enc(x)for x in v]
 if isinstance(v,dict):return {k:enc(x)for k,x in v.items()}
 return v
def decode(v):
 if isinstance(v,str):
  try:return F(v)
  except(ValueError,ZeroDivisionError):return v
 if isinstance(v,list):return [decode(x)for x in v]
 if isinstance(v,dict):return {k:decode(x)for k,x in v.items()}
 return v
def up(x):return c.k.up(x,SCALE)+F(1,SCALE)
def down(x):return c.k.down(x,SCALE)-F(1,SCALE)
def bounded(z):
 if z.get('excluded'):return dict(excluded=True,reason=z['reason'],stage=z['stage'])
 out={k:z[k]for k in ('pl','pu')}
 for key in ('raw','D','theta','rho','beta','lambda_max','inward_d_max','Hplus','Hminus'):
  if key in z:out[key]=up(z[key])
 for key in ('A','B','beta_lo'):
  if key in z:out[key]=down(z[key])
 if 'quadratics'in z:
  out['quadratics']=[{k:(down(v)if k in ('Qraw','Qbudget')else up(v))for k,v in q.items()if k in ('A','Fplus','Fminus','Qraw','Qbudget')}for q in z['quadratics']]
 out['joint_inward_noise']=True
 return out
def summary(values):
 need(values and max(values)<0,'strict contact cover')
 return dict(cells=len(values),maximum=max(values),sha256=sha256(json.dumps(enc(values),separators=(',',':')).encode()).hexdigest())
def radius_gates(z):
 h=max(z['Hplus'],z['Hminus']);rho=z['rho'];bl=z['beta_lo'];bu=z['beta']
 need(0<=bl<=bu<1 and 0<h<2,'central radius domain')
 vals=[]
 for j in range(54):
  a=F('2.5')+F(j,40);b=a+F(1,40)
  vals.extend((exterior.support_cell(h,rho,bl,bu,a,b),exterior.support_cell(h,rho,bl,bu,-b,-a)))
 need(len(vals)==108,'both closed radial halves to3.85')
 return summary(vals)
def strip_gates(z):
 hyp=dict(p=[str(z['pl']),str(z['pu'])],theta=str(z['theta']),rho=str(z['rho']),beta_upper=str(z['beta']),H=str(max(z['Hplus'],z['Hminus'])),radius='2.5')
 result=exterior.from_hypotheses(hyp,F('.55'));vals=[F(row['upper'])for row in result['rows']]
 return summary(vals)
def build(emit=False):
 blob=Path('initial40_candidate.json').read_bytes();initial=decode(json.loads(blob))
 need(initial['format']=='INITIAL40_FULL_P_V1'and initial['name']=='INITIAL40_R384'and len(initial['panels'])==100,'complete INITIAL40 source')
 prep=[];fine=[]
 for j in range(38,100):
  source=initial['panels'][j]
  need(source['pl']==F(j,100)and source['pu']==F(j+1,100),'ordered closed initial cover')
  if source['cells']==0:
   need(j>=48,'central source has no unplanned emptiness');prep.append(dict(index=j,pl=source['pl'],pu=source['pu'],excluded=True,reason='initial empty'));continue
  row={key:source[key]for key in ('pl','pu','raw','D','theta','rho','beta')}
  z=bounded(c.cell(N,F('3.84'),CAP,row,steps=64));z.update(index=j,pl=row['pl'],pu=row['pu'])
  if j>=48:
   need(z.get('excluded'),'complete upper complement excluded by coupled resource')
  else:
   need(not z.get('excluded')and'quadratics'in z,'central parent survives')
   z['radius_proof']=radius_gates(z)
  prep.append(z)
  if emit:print('EXACT_CENTRAL40_PREP',j,'EXCLUDED'if z.get('excluded')else enc({k:z[k]for k in ('raw','D','Hminus')}),flush=True)
  if j<48:
   for i in range(5):
    index=5*j+i;row={key:z[key]for key in ('raw','D','theta','rho','beta')};row.update(pl=F(index,500),pu=F(index+1,500))
    q=bounded(c.cell(N,F('2.5'),CAP,row,steps=64));q.update(index=index,pl=row['pl'],pu=row['pu'])
    if not q.get('excluded'):q['strip_proof']=strip_gates(q)
    fine.append(q)
    if emit:print('EXACT_CENTRAL40_FINE',index,'EXCLUDED'if q.get('excluded')else enc({k:q[k]for k in ('raw','D','lambda_max','inward_d_max')}),flush=True)
  if emit:Path('acquisition_progress.json').write_text(json.dumps(enc(dict(prep=prep,fine=fine)),indent=2)+'\n')
 need(len(prep)==62 and len(fine)==50,'complete [.38,1] union with fine replacement')
 return dict(schema='SINGLE40_CENTRAL_UPPER_ACQUISITION_V1',N=40,current_score_cap=CAP,source_sha256=sha256(blob).hexdigest(),premises=dict(raw_support='[-3.84,3.84]',decrement='19/100',excess='0<=a40<=.54/40'),joint_resource='din/din0+lambda/Lambda<=1 on each surviving fine row',prep=prep,fine=fine)
