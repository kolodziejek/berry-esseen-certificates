"""Exact source binding for the separately proved indexed CENTRAL40 extension.

No fresh replay of old central arithmetic is claimed. Its unchanged positive
error contact polynomials and floor Sperner bounds are reused by the scope proof.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import fifth_heat50 as h
R=Path(__file__).resolve().parent;C=R.parent/'central40'
if not __debug__ or sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
def need(v,s):
 if not v:raise ValueError(s)
def H(p):return sha256(p.read_bytes()).hexdigest()
binding=json.loads((C/'CENTRAL40_ACCEPTED_STATUS.json').read_text())
need(binding['status']=='PASS_SOURCE_BOUND_CENTRAL40_COMPONENTS','accepted original central components')
W=R.parents[2]
for name,digest in binding['input_sha256'].items():need(H(W/name)==digest,'unchanged central source/proof input')
proofs={}
for component in('acquisition','confinement','profile'):
 p=C/(component+'_candidate.json');z=json.loads(p.read_text());need(z['N']==40,'unchanged floor40 arithmetic');proofs[p.name]=H(p)
acq=json.loads((C/'acquisition_candidate.json').read_text())
need(len(acq['prep'])==62 and len(acq['fine'])==50,'complete central/upper cover')
need(sum(z.get('radius_proof',{}).get('cells',0)for z in acq['prep'])==1080,'full central radial contact cover')
need(sum(z.get('strip_proof',{}).get('cells',0)for z in acq['fine'])==3044,'full central transformed exterior cover')
# The only all-H heat support obligation is initial radius3.84.
initial=h.target(40,42,F(0),F('3.84'),F(0))
need(initial['n_band']==[40,42]and initial['slow']=='0','explicit finite ceiling and zero decrement')
print(json.dumps(dict(status='PASS_CENTRAL40_INDEXED_SCOPE_BINDING',mathematical_status='New locally derived indexed extension; see FLOOR40_SCOPE_AND_JOINT_THETA.md and CENTRAL_INDEXED_EXTENSION.md',execution_status='Existing fixed central components remain fresh source-bound PASS; only added initial finite zero-decrement support freshly evaluated here',indexed_premise='n=40,delta<=.19 OR n in{41,42},delta=0',weighted_invariant='nD<=40*D_row',current_cap='.4226',deleted_cap='.4253',proof_sha256=proofs,initial_support_contract=dict(N=40,last=42,K='0',q='0',R='96/25'),initial_support=initial,central_radius_method='nonnegative Gaussian contact-error envelope at floor40; no favorable fifth-heat lower term',central_radius_cells=1080,central_strip_cells=3044),indent=2),flush=True)
