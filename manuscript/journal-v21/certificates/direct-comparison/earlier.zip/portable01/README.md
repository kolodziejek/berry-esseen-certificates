# Earlier737 exact comparison package

From this extracted directory, run one command with a new output destination:

```
python3 -I -B replay.py /absolute/path/to/NEW_OUTPUT
```

The command verifies every selected package file and freshly accepts all737
family/index/n objects using exact Python integer/Fraction arithmetic. It
does not import NumPy or SciPy. Python3.12.12 was tested; -O and -OO are
rejected. No compiler, network or system installation is needed. The
published ZIP digest is the external integrity anchor; FILES.json detects
accidental changes inside the package but is not a separate trust authority.

The complete original actual discovery, fresh exact readback and adverse
controls are preserved under runs/earlier_local_comparison_20261104/
analytic_complete01. Their absolute argv paths record where those original
processes ran; they are historical observations, not claims of execution in
your extracted directory. A new replay writes its own actual paths, runtime,
source hashes, outputs and exit code. The preserved run_complete01.py has
fixed historical destinations and should not be rerun in this package.

The mathematical result is a direct-score implication for the specified
earlier acquired laws: positive39 at target CE+741/(4000*39), and the
listed actual40--46 cases at target CE. It retains the same-law contact,
initialization, Fourier/acquisition and independent coarse-strip hypotheses.
The25 original upstream files are included and bound for source/interface
integrity; this command does NOT replay or prove their analytic acquisition
ancestors. It also does not prove the other index ranges or the full theorem
by itself. See work/earlier_local_comparison_20261104/analytic/INTERFACE.md
for the complete reduction and source scope, and
work/earlier_local_comparison_20261104/integration/review_sturm/
for the strict global-polynomial reader's self-contained soundness proof.

Discovery is separate: the preserved discovery source uses NumPy/SciPy
only to propose candidates. Exact acceptance reconstructs all constants,
binary caps, global majorants,48-corner tensors and complete coverage. The
objects do not contain an assumed PASS flag that replaces these checks.
