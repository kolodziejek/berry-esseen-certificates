"""Verify selected package bytes, then replay all737 exact implications."""
from pathlib import Path, PurePosixPath
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized Python required')
if len(sys.argv)not in(2,3)or(len(sys.argv)==3 and sys.argv[2]!='--verify-only'):raise SystemExit('usage: python3 -I -B replay.py NEW_OUTPUT [--verify-only]')
out=Path(sys.argv[1]).resolve()
if out.exists():raise FileExistsError('create-only replay output already exists')
if out==ROOT or ROOT in out.parents:raise ValueError('write new replay evidence outside the immutable package')
seen=set()
for row in json.loads((ROOT/'FILES.json').read_text())['files']:
    rel=PurePosixPath(row['path'])
    if rel.is_absolute()or '..'in rel.parts or str(rel)!=row['path']or row['path']in seen:raise ValueError('unsafe or duplicate package path')
    seen.add(row['path'])
    p=ROOT/row['path']
    if p.is_symlink()or not p.is_file()or p.stat().st_size!=row['bytes']or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:raise ValueError('package byte mismatch '+row['path'])
if {str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()}!=seen|{'FILES.json'}:raise ValueError('extra or missing package files')
if len(sys.argv)==3:
    print('PACKAGE_BYTES_VERIFIED; no mathematical replay was run')
    raise SystemExit(0)
cmd=[sys.executable,'-I','-B',str(ROOT/'work/earlier_local_comparison_20261104/reader/capture.py'),'acceptance',str(out),str(ROOT/'runs/earlier_local_comparison_20261104/analytic_complete01/discovery/objects'),'--complete']
raise SystemExit(subprocess.run(cmd).returncode)
