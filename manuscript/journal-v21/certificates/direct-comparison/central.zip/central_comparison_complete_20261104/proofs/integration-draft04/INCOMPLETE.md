This is an intentionally preserved incomplete staging attempt, not a usable
proof bundle. The staged `main.tex` matched the draft04 compilation, but the
current `direct_comparison.tex` had changed. The source-pin check rejected the
copy before adding that file or the PDF.

Actual failed capture:
`runs/central_comparison_20261104/finite_portable_analytic_draft01`, return code 1.
The expected old source SHA was
`0af72c6a1e63c288850078b4b27024dccd45b352595e811e5ed20c6b9244c856`;
the observed new source SHA was
`1f55bd1506f03606e1801c19e5013324cb4dc149c43da0dbcbd4b42b532bb719`.

No numerical source, proof object, or mathematical target was changed by this
failed archival operation. Select the separately identified later complete
analytic draft for reading.
