# Central comparison replacement

The acquired central comparison is complete for all integers `n >= 47`.
Its finite and infinite-tail components have explicit proofs and exact
acceptance records. This is a completed comparison module; the original
acquisition, early-support and Bernoulli-theorem premises remain explicit.

The package concerns the original 45 central probability rows covering
`0.38 <= p <= 0.47`. Its premises are the manuscript's attained/contact
acquisition and the early `.55` conditional-support strip. It does not establish
those premises anew and is not a stand-alone proof of the global theorem.

The replacement has two parts:

- **Finite indices, 47 through 999.** An exact joint-defect argument excludes
  16,977 of the 42,885 row/index pairs. The remaining 25,908 pairs require closed
  covers of probability, count, phase, noise, and conditional moments. Each
  quartic is checked on the entire real line, and its expected score is checked
  over the full continuous parameter cell. Separate exact acceptance passed for every retained pair after relocation.
- **Every index at least 1000.** The preserved four-page tail proof and exact
  checker cover all 45 rows. Twenty-six rows are excluded by the weighted
  defect budget; the other nineteen share one envelope with four quartics and
  twenty displayed positive coefficients. This part has completed exact
  acceptance and rejection controls in the preserved original runs.

The finite binary-gap computation is already complete: 25,908 row/index pairs,
73,566 licensed count pairs, and 1,593,120 closed branch cells. It checks both
sides of every CDF jump. The minimum certified gap is
`2991/100000000000`; this is a lower bound on the gap, not an asserted optimum.

## What is checked

The incoming and outgoing conditional-count events are bounded using one
common conditional distribution. The fourth-moment bound follows from the
same bounded conditional supports and independence. It is not an independent
choice of a worst distribution for each count. Concavity reduces the resulting
moment inequalities to a fixed finite set of corners. This reduction is an
analytic premise proved in the accompanying mathematical text; a program PASS
does not replace it.

The proposed translated quartic has the form `Q(W-u)`. Exact polynomial
positivity on its closed step intervals and outer rays establishes the
conditional-count majorization, including event collisions. Its expected score
has bidegree at most `(6,4)` after clearing positive denominators. Positive exact
tensor Bernstein coefficients then prove the desired inequality everywhere on
each closed probability/phase cell. Noise and conditional moments have already
been reduced to their rigorously justified endpoint cases. All original
probability and finite-index targets are fixed outside the candidate objects.

## Software and execution boundaries

Acceptance uses Python integers, `fractions.Fraction`, integer square roots,
and reviewed exact polynomial routines. It requires no NumPy or SciPy.
Floating-point SciPy optimization proposes quartics; each proposal must pass
the exact global and score gates. A numerical solver failure is not a
mathematical exclusion.

The tested exact runtime is unoptimized CPython 3.12.14. Always use `-I -B`;
never use `-O` or `-OO`. Create fresh output directories. Discovery records
separately identify their Miniforge/NumPy/SciPy runtime.

The package preserves the original relative workspace hierarchy. The exact
source bytes therefore need no path adapter. Historical command paths and
execution identities in archived receipts remain historical; they are not
rewritten to look like new executions.

Completed gap arithmetic was run in the original workspace. Relocation checks
every source/input byte and performs one complete critical gap-panel smoke.
The full finite comparison replay passed from the relocated package. The
tail's original complete exact acceptance records are preserved. A new additive
supervisor also completed the full tail acceptance and 21 rejection controls
after relocation, plus the four-quartic common-envelope check; its numerical
readers remained unchanged. These are distinct execution statements.

The gap construction and replay use the same exact arithmetic implementation.
Likewise the separate cover replay uses the same reviewed exact checker used
to reject proposals during discovery. Neither is called an independent
implementation. The separate mathematical audits and negative controls have
their own recorded scopes.

## Reproduction commands

From the package root, select an unoptimized Python executable as `PY` and use
fresh names for all outputs. The finite full acceptance entrypoints are:

```sh
"$PY" -I -B work/central_comparison_20261104/finite/campaign/launch_cover_replays.py \
  proof_objects/cover runs/reproduce-central-covers
"$PY" -I -B work/central_comparison_20261104/finite/campaign/collect_cover_replays.py \
  --input runs/reproduce-central-covers/shard0 \
  --input runs/reproduce-central-covers/shard1 \
  --input runs/reproduce-central-covers/shard2 \
  --input runs/reproduce-central-covers/shard3 \
  --output runs/reproduce-central-union
```

The tail's portable reproduction supervisor is:

```sh
"$PY" -I -B replay_tail.py runs/reproduce-central-tail
```

This additive supervisor uses `tempfile.TemporaryDirectory` for the child
working directory and captures actual commands, streams, exit codes and source
hashes. It calls the unchanged exact readers and has no `/private/tmp`
requirement. The older Mac-specific capture wrapper remains preserved as
historical evidence and is not the recommended reproduction command.

To reproduce all finite binary gaps, including grid construction and separate
exact acceptance, use the existing four-shard launcher and collector:

```sh
"$PY" -I -B work/central_comparison_20261104/finite/campaign/launch_gap_shards.py \
  runs/reproduce-central-gaps
"$PY" -I -B work/central_comparison_20261104/finite/campaign/collect_gaps.py \
  --input runs/reproduce-central-gaps/shard0/accept \
  --input runs/reproduce-central-gaps/shard1/accept \
  --input runs/reproduce-central-gaps/shard2/accept \
  --input runs/reproduce-central-gaps/shard3/accept \
  --output runs/reproduce-central-gap-union
```

Its mathematical table must agree exactly with the table already pinned by the
comparison reader. Execution-path metadata naturally differs after relocation,
so compare the fields below, rather than the entire result-file hash. Do not run
the one-time data binder again or replace the pinned input table.

```sh
"$PY" -I -B - <<'PY'
from pathlib import Path
import json
old = json.loads(Path('work/central_comparison_20261104/finite/campaign/native/gaps_campaign.json').read_text())
new = json.loads(Path('runs/reproduce-central-gap-union/RESULT.json').read_text())
for key in ('status', 'row_n_pairs', 'count_pairs', 'closed_branch_cells',
            'minimum_epsilon', 'gaps', 'sources'):
    if old[key] != new[key]:
        raise SystemExit('Reproduced mathematical gap table differs: ' + key)
print('Exact finite gap table and source identities agree.')
PY
```

The complete finite acceptance contains 112,438 quartics and 34,694 exact
exclusions: all 147,132 required count/sign roots, with no subdivisions. The
checker evaluated 94,447,920 exact score Bernstein coefficients. The full
comparison replay and subsequent whole-census join passed; 24 new capture and
coverage mutations were rejected. The completed gap captures separately passed
21 admission-mutation controls. The tail passed its 21 native rejection controls.


## Reading and evidence map

- `COMPLETION.json` records the final conditional mathematical scope, complete
  finite census and distinct execution histories. `FILES.json` gives every
  packaged file's size and SHA256; it excludes its own hash to avoid circularity.
- `proofs/integration-draft05/main.pdf` is the 12-page generic direct-comparison
  argument, with the central-specific scalar and index specialization. Its
  pending-assertion labels preserve the draft's actual pre-completion status;
  use `COMPLETION.json` for the subsequently completed central numerical result.
  The draft also discusses another finite branch outside this package's scope.
- `runs/finite_left_replacement_20261104/audit_central_tail_build04/build/central_tail.pdf`
  is the separate four-page central-tail proof. Its source is under
  `work/finite_left_replacement_20261104/audit/central_transfer/`.
- `proof_objects/cover/shard0` through `shard3` contain all 25,908 exact finite
  candidates. Their complete fresh acceptance is recorded under
  `runs/central_comparison_20261104/finite_portable_cover_replays01`; the full
  coverage result is `finite_portable_cover_union01/accepted/RESULT.json` in
  the same parent directory.
- `runs/central_comparison_20261104/finite_portable_tail_replay01` records the
  fresh portable full tail check and common-envelope check. Its accepted result
  is byte-identical to the original complete tail result.

The full finite-union RESULT SHA256 is
`edbc026fc8f4052a343787852c38a2376b103e028babbd95ffaaf96d69295132`.
The selected original and relocated accepted tail RESULT share SHA256
`86a163cd5239075f4650e1ce53f57f9ef31bfab468f3db61328b901e0f6e9f92`.

All native acceptance records are included. Large disposable mutation-fixture
copies are omitted; their code, actual process/streams, rejection results and
explicit synthetic-fixture descriptors are retained. An incomplete historical
draft04 staging attempt is preserved and marked as failed; it is not an
accepted proof or a numerical failure.

This package does not claim formal verification in a proof assistant. Its
rigor rests on the printed analytic implications, the reviewed exact program
semantics, complete externally fixed coverage, and the stated standard Python
integer/rational trusted stack. Hashes establish byte integrity, not the truth
of the analytic reductions.
