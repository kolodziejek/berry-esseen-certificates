"""Fixed direct-contact support lemmas on declared rational hypothesis rows."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys
from panel_exterior import support_cell,from_hypotheses
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent
SHA='5678ba9a7fa618b2f32eb222a12cd81df588bd12153882ee91fb54c90505a15b'


def need(v,s):
    if not v:raise ValueError(s)


def read(blob):
    need(hashlib.sha256(blob).hexdigest()==SHA,'fixed named hypothesis rows')
    doc=json.loads(blob)
    need(doc['schema']=='CONDITIONAL_SUPPORT47_ROWS_V1','schema')
    need(len(doc['radius'])==10 and len(doc['exterior'])==45,'complete selected rows')
    for kind,step in [('radius',F('.01')),('exterior',F('.002'))]:
        for i,h in enumerate(doc[kind]):
            l,u=map(F,h['p'])
            need(l<=F('.38')+i*step<F('.38')+(i+1)*step<=u,'p row coverage')
    return doc


def radius_rows(h,start=F('2.5')):
    hmax,rho=F(h['h']),F(h['rho']);bl,bu=map(F,h['beta'])
    need(0<=bl<=bu<1 and 0<hmax<=2 and 1<=rho<=F('1.85'),'radius row domain')
    finish=F('3.85');count=int((finish-start)*40)
    need(count>0 and F(count,40)==finish-start,'exact regular closed cover')
    out=[]
    for sign in [-1,1]:
        for j in range(count):
            a=start+F(j,40);b=a+F(1,40)
            l,r=(a,b)if sign>0 else(-b,-a)
            out.append(dict(sign=sign,interval=[str(l),str(r)],
               upper=str(support_cell(hmax,rho,bl,bu,l,r))))
    return out


def main():
    need(len(sys.argv)==1,'no target overrides')
    blob=(HERE/'support47_hypotheses.json').read_bytes();doc=read(blob)
    allrows=[];counts=[];worst=[];digest=hashlib.sha256()
    for kind in ['radius','exterior']:
        rows=[]
        for i,h in enumerate(doc[kind]):
            part=radius_rows(h)if kind=='radius'else from_hypotheses(h)['rows']
            for z in part:
                need(F(z['upper'])<0,'strict actual-contact exclusion')
                digest.update((kind+':'+str(i)+':'+json.dumps(z,sort_keys=True)+'\n').encode())
            rows.extend(part)
        counts.append(len(rows));worst.append(str(max(F(z['upper'])for z in rows)))
        allrows.append(rows)
    need(counts[0]==1080,'full central radius cover')
    controls=0
    for mutation in ['missing_radius','missing_exterior','duplicate','reorder','altered']:
        bad=json.loads(blob)
        if mutation=='missing_radius':bad['radius'].pop()
        elif mutation=='missing_exterior':bad['exterior'].pop()
        elif mutation=='duplicate':bad['radius'].append(bad['radius'][0])
        elif mutation=='reorder':bad['exterior'].reverse()
        else:bad['radius'][0]['rho']='1'
        try:read(json.dumps(bad).encode())
        except ValueError:controls+=1
        else:raise AssertionError('changed named hypotheses accepted')
    need(max(F(z['upper'])for z in radius_rows(doc['radius'][0],F('2.3')))>0,
         'substantively false radius2.3 rejected');controls+=1
    print(json.dumps(dict(status='FRESH_PASS_CONDITIONAL_SUPPORT47',
       hypotheses='n>=47, actual positive attained contact, 0<=a<=.7/n, decrement<=.19; plus each declared rational moment/threshold row.',
       conclusions=['For ten central rows, prior|X|<=3.84 implies |X|<2.5.',
                    'For45 shared comparator rows, prior|X|<=2.5 implies fullYstrip(-.55,1.55).'],
       acquisition_status='All entry row hypotheses remain unacquired; this is no cutoff50 theorem.',
       cells=counts,worst_upper=worst,controls=controls,gate_sha256=digest.hexdigest(),
       interpreter=sys.version,source_sha256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()for name in
          ['accept_support47.py','support47_hypotheses.json','panel_exterior.py','gaussian_core.py','panel_exterior_proof.tex']}),indent=2))


if __name__=='__main__':main()
