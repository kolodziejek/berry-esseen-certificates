"""Fixed45row, n>=1000 explicit central-tail certificate acceptance."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,importlib.util,json,sys
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized Python required')
HERE=Path(__file__).resolve().parent
CORE_PIN='bc502fcd18dabca671bd5c6c0abb22ef7015e7dbced1ae39fb326319bc2d9626'
corepath=HERE/'check_all45.py'
if hashlib.sha256(corepath.read_bytes()).hexdigest()!=CORE_PIN:raise ValueError('fixed analytical target source')
spec=importlib.util.spec_from_file_location('fixed_central_tail_targets',corepath)
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)

def need(v,s):
    if not v:raise ValueError(s)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
def strict_json(text):
    def pairs(seq):
        d={}
        for k,v in seq:need(k not in d,'duplicate JSON key');d[k]=v
        return d
    def invalid(x):raise ValueError('nonfinite JSON '+x)
    return json.loads(text,object_pairs_hook=pairs,parse_constant=invalid)
def header():return {'schema':'EARLY_CENTRAL45_N1000_EXPLICIT_QUARTIC_V1','N':1000,'A':'11/20','U':'2/25','K':'1/20','core_sha256':CORE_PIN}
def propose():return header()|{'rows':core.encode([core.test(i,1000)for i in range(45)])}
def accept(obj):
    need(type(obj)is dict and set(obj)==set(header())|{'rows'},'fixed object fields')
    need(canonical({k:obj[k]for k in header()})==canonical(header()),'fixed tail target and sources')
    need(type(obj['rows'])is list and len(obj['rows'])==45,'complete45row cover')
    statuses=[];transfers=[];excluded=[];leaves=0
    for i,claim in enumerate(obj['rows']):
        need(type(claim)is dict and type(claim.get('row'))is int and claim['row']==i,'ordered unique original probability row')
        calculated=core.encode(core.test(i,1000,supplied=claim))
        need(calculated['status']in('PASS_SUFFICIENT_CENTRAL_ROW_FINITE_TRANSFER','EXCLUDED_BY_WEIGHTED_DEFECT','ONLY_ZERO_NOISE_BY_BUDGET'),'complete exact row acceptance')
        need(canonical(claim)==canonical(calculated),'exact reconstructed constants, domain, conclusions and polynomial leaves')
        statuses.append(calculated['status'])
        if calculated['status']=='PASS_SUFFICIENT_CENTRAL_ROW_FINITE_TRANSFER':
            transfers.append(i)
            leaves+=sum(v['leaves']for b in calculated['checks']for v in b['variance_endpoints'])
        else:excluded.append(i)
    margin=min(F(obj['rows'][i]['constants']['repair_margin'])for i in transfers)
    return {'status':'PASS_EXACT_COMPLETE_EARLY_CENTRAL45_N_GE_1000_TAIL','probability_rows':45,'transfer_rows':transfers,'defect_excluded_rows':excluded,'quartic_targets':4*len(transfers),'Bernstein_leaves':leaves,'minimum_normalized_repair_margin':str(margin),
      'mathematical_scope':'Conditional on original attained/contact central acquisition and independently licensed early .55 strip, all n>=1000 and all p/phases/noise in all45 rows; positive noise gives C<CB, zero noise uses the binary theorem.',
      'remaining':'No claim for n47..999, no new acquisition, and no replacement of the complete manuscript before independent analytic and finite-base joins.'}

def controls(obj):
    rejected=[]
    def trial(name,edit):
        z=copy.deepcopy(obj);edit(z)
        try:accept(z)
        except(ValueError,KeyError,TypeError,IndexError):rejected.append(name)
        else:raise AssertionError('accepted mutant '+name)
    trial('missing_row',lambda z:z['rows'].pop())
    trial('duplicate_row',lambda z:z['rows'].append(z['rows'][0]))
    trial('reordered_rows',lambda z:z['rows'].reverse())
    trial('boolean_row_index',lambda z:z['rows'][0].update(row=False))
    trial('smaller_n_target',lambda z:z.update(N=47))
    trial('floating_n_target',lambda z:z.update(N=1000.0))
    trial('changed_noise_domain',lambda z:z.update(U='1/10'))
    trial('changed_support',lambda z:z.update(A='17/40'))
    trial('changed_loss_target',lambda z:z.update(K='0'))
    trial('changed_core_pin',lambda z:z.update(core_sha256='0'*64))
    trial('false_defect_exclusion',lambda z:z['rows'][19].update(status='EXCLUDED_BY_WEIGHTED_DEFECT'))
    trial('changed_repair_constant',lambda z:z['rows'][19]['constants'].update(kappa='0'))
    trial('missing_phase_branch',lambda z:z['rows'][19]['checks'].pop())
    trial('missing_variance_endpoint',lambda z:z['rows'][19]['checks'][0]['variance_endpoints'].pop())
    def first(z):return z['rows'][19]['checks'][0]['variance_endpoints'][0]['coefficients']
    trial('missing_Bernstein_leaf',lambda z:first(z).pop())
    trial('duplicate_Bernstein_leaf',lambda z:first(z).append(first(z)[0]))
    trial('negative_Bernstein_coefficient',lambda z:first(z)[0]['bernstein'].__setitem__(0,'-1'))
    trial('changed_positive_Bernstein_coefficient',lambda z:first(z)[0]['bernstein'].__setitem__(0,'100'))
    for text in ('{"N":1000,"N":1000}','{"rows":[{"x":1,"x":1}]}','{"x":NaN}'):
        try:strict_json(text)
        except ValueError:rejected.append('invalid_JSON_'+str(len(rejected)))
        else:raise AssertionError('ambiguous JSON accepted')
    return rejected

def main():
    out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
    obj=strict_json(Path(sys.argv[2]).read_text())if len(sys.argv)>2 else propose()
    result=accept(obj);result['negative_controls']=controls(obj)
    (out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n');(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
