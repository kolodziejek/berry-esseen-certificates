# Acquired central tail: final bounded deliverable

Mathematical status: locally derived conditional implication, for all 45 original central rows and every integer n >= 1000. The original attainment/contact acquisition, early .55 strip and Bernoulli theorem remain explicit premises. This does not prove the separate range 47 <= n < 1000.

Execution status: fresh exact PASS. Source-only common-envelope proof replaces 76 row-specific quartic checks by four quartics with 20 printed positive coefficients, after exact scalar verification on every row. The original detailed checks remain preserved.

- `central_tail.tex`: self-contained four-page new comparison proof; `INTERFACE.md`: fuller derivation.
- `check_all45.py`: scalar premises and canonical per-row fixed targets.
- `accept_all45.py`: exact object admission and 21 rejection controls.
- `common_envelope.py`: fixed single envelope and four-quartic calculation.
- `capture.py`: actual argv, streams, return code and before/after source hashes.

Fresh evidence roots, relative to the workspace:

- `runs/finite_left_replacement_20261104/audit_central_all45_capture01`: exact discovery/admission and controls; 26 excluded rows, 19 transfer rows, 76 quartics.
- `runs/finite_left_replacement_20261104/audit_central_all45_readback01`: separate admission of that serialized object, no forward forest discovery; rc0, 21 controls, stable sources.
- `runs/finite_left_replacement_20261104/audit_central_common01`: four quartics / 20 coefficients, final margin 19847/500000.
- `runs/finite_left_replacement_20261104/audit_central_tail_build04`: actual compile, stdout/stderr/process, final PDF and four inspected page PNGs. Earlier build records remain preserved.

Exact conclusion for positive noise lambda: rhoB*(C-CB) <= -(19847/500000)*lambda < -.039*lambda. Noise zero uses the binary theorem at its actual threshold; it is not identified with the nearest-jump score without justification. The phase choice and all event collisions are explicit in the proof.

## Fresh reproduction in this workspace

Use unoptimized Python; create new output paths.

```sh
PY=/Users/bkolodziejek/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
$PY -I -B work/finite_left_replacement_20261104/audit/central_transfer/capture.py NEW_READBACK runs/finite_left_replacement_20261104/audit_central_all45_capture01/accepted/proof_object.json
$PY -I -B work/finite_left_replacement_20261104/audit/central_transfer/common_envelope.py runs/finite_left_replacement_20261104/audit_central_all45_capture01/accepted/proof_object.json NEW_COMMON
```

The current adapter intentionally binds original workspace source paths; relocation requires an explicit portable path adapter, not a claim that archived outputs are fresh computation. Exact rationals, integer square roots and the separately reviewed inverse Bernstein reader are used; floating search is absent from acceptance.
