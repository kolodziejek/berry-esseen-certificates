# Finite-n transfer of the central quartic loss

This note derives a conditional sufficient test from the original acquired
central law and its early .55 strip. It is not a complete new central proof:
a successful tail test leaves all smaller finite indices to be covered.

## Actual variables and the exact score identity

Let p in[pl,pu] subset(0,1/2), q=1-p, v=pq, Y=B+U with P(B=1)=p,
centered conditional laws U0,U1, s=q Var(U0)+p Var(U1), lambda=n*s,
w=v+s and ell=1/sqrt(w). The licensed early strip and central gap give
`|Ui|<=A=.55`, `U0<=a0`, `U1>=-a1`, `d=a0+a1<=d0<pl`.
Write the actual threshold as x=np+H/ell=k+u, |u|<=1/2, delta=k-np.
All counts use these same two conditional laws. Put pi_k=Pr(Bin(n,p)=k),
b=sqrt(n)*pi_k, rhoB=(1-2v)/sqrt(v), and

`f(u)=[Phi((delta+u)/sqrt(nw))-Phi(delta/sqrt(nw))]/pi_k`,
`Q=Pr(sum Y<=k+u)-Pr(Bin(n,p)<=k)`.

Direct subtraction of the signed scores gives exactly

`rhoB*(C-CB)=b*(Q/pi_k-f(u))+R`,
`R=sqrt(n)*[Phi(delta/sqrt(nv))-Phi(delta/sqrt(nw))]+C*(rhoB-rho)`.

Here CB is the binary closed-jump score at k. The finite-n comparison needs
only a positive lower b bound once a strictly negative normalized loss is
proved. It does not need an upper b bound, exact binomial CDF evaluation, or
a quantitative binary gap. The existing binary theorem CB<=CE then finishes
the positive-noise case; noise zero is the binary law itself, at its actual
threshold, and is treated separately.

## Shared inward/noise budget

The acquired original joint defect gives simultaneously
`D>=P0+I*d+beta*theta`, where theta=s/(v+s), P0 is a lower bound for the
Bernoulli defect on the p cell, and

`I <= 6*(1-Theta)*sqrt((1-Theta)/vmax)*(1-d0)`,
`beta <= min(3*(sqrt(10)+1)*B_lo,3*(sqrt(10)+3)*A_lo)-3*P0/2`.

Require I,beta>0. The same original contact resource, under C>=CE and
nonnegative excess, gives `nD<=BUD`, with
`BUD=min(47*Drow,T/(997/15000))`; a signed H refinement may improve it.
From the early strip, s<=A*((1-p)*a0+p*a1)<=A*(1-pl)*d=M*d.
For every n>=N and an already proved lambda<=Lambda_old,

`lambda <= (BUD-N*P0)/[I/M+beta/(vmax+Lambda_old/N)]`,
`d <= (BUD/N-P0)/I`.

Negative remaining budget excludes the cell. These formulas lower the
admissible noise and inward displacement, without subsequent confinement.
For the critical row19, P0=0 is sufficient, and the displayed formula
already proves lambda<.08 for all n>=47 using the original raw inputs.

## Required finite normalization, derived explicitly

Choose a common positive noise ceiling U and a candidate N. Put

`dN=min(d0,(BUD/N-P0)/I)`, `c=1-dN>0`,
`Delta=max(1,Hmax*sqrtUpper(vmax+U/N)+1/2)`.

Then all actual n>=N have |delta|<=Delta. Choose the exact enclosing segment
`a=pl-Delta/N`, `b=pu+Delta/N`, and require 0<a<b<1/2, N*a>1.
Let va=a(1-a) and

`L=(1-2a)/va`, `E=(1-2a)/va^2`, `F=1/(12va)`,
`Z=L*Delta/2+F+E*Delta^3/(6N)`.

These are upper bounds for the log-variance derivative, absolute third
entropy derivative, factorial remainder coefficient and their combined
finite error. Indeed Stirling's finite remainder 0<r_j<1/(12j) and Taylor's
formula on the segment give

`b=phi(0)/sqrt(v) * exp(-delta^2/(2nv)+zeta)`, `|zeta|<=Z/n`.

The three contributions are bounded by L*|delta|/(2n),
E*|delta|^3/(6n^2), and1/(12n*va). The entropy derivative here is with
respect to its first argument, so its third derivative is
`(2h-1)/(h^2*(1-h)^2)`, independent of p. All counts are positive integers
by the segment gate.

Thus a valid mass lower bound is

`m=phi0_lower/sqrtUpper(vmax) * [1-(Delta^2/(2vmin)+Z)/N]>0`.

For the phase derivative, exact cancellation gives

`log f'=-log(1+s/v)/2 +delta^2/(2nv)`
`        -(delta+u)^2/(2n(v+s))-zeta`.

Decomposing the middle two terms and using |u|<=1/2 proves
`|log f'|<=B/n`, where

`B=U/(2vmin)+Delta^2*U/(2N*vmin^2)`
`  +(Delta+1/4)/(2vmin)+Z`.

If B/N<1, the elementary exponential inequalities give
`a_lo=1-B/N <= f' <= a_hi=1/(1-B/N)`.
Consequently `f(u)>=a_lo*u` for u>=0 and `f(u)>=a_hi*u` for u<=0.
The upper coefficient is needed on negative phases; replacing it by the
lower coefficient would reverse the required bound.

For the incoming masses, require Delta+pu<2 and
`1-(Delta-1)/(N*pl)>0`. The binomial recursion then makes every rising
factor after the first at most1, and all legal incoming ratios obey

`pi_(k+i)/pi_k <= R0`
`R0=1+(pu+Delta-1)/[N*vmin*(1-(Delta-1)/(N*pl))]`.

The exact own variance satisfies
`t=Var(W_k)=lambda+delta*(s1-s0)` and |s1-s0|<=s/pl, hence
`omega_minus*lambda <= t <= omega_plus*lambda`,
`omega_plus/minus=1+/-Delta/(N*pl)`. Require omega_minus>0.
No estimate of a different count's variance is needed by the joint staircase.

Finally the inward signs imply

`(v+s)^(3/2)*(rho-rhoB) >= s*[6p-3p^2-3/2-d-3*(1-2v)*s/(8v)]`.

A lower bracket is
`J=6pl-3pl^2-3/2-dN-3*(1-2vmin)*U/(8*vmin*N)>0`.
With C>=cstar=.4, the actual normal interpolation and cubic gain give

`R<=kappa*lambda/n`,
`kappa=phi0_upper*Delta/(2*vmin*sqrtLower(vmin))`
`      -cstar*J/[(vmax+U/N)*sqrtUpper(vmax+U/N)]`.

For delta<=0 the normal interpolation is nonpositive; the displayed Delta
bound conservatively covers both signs. Positivity of J must be checked
before using the lower score cstar. One may use max(0,kappa)/N when
eliminating n; using kappa/N for negative kappa would be incorrect.

These are the genuinely needed normalizations: mass lower bound, signed
phase slopes, incoming ratio, own variance interval, and the signed cubic
repair. All hold for every n>=N by finite bounds, not by a fixed-law limit.

## An explicit global majorant with exact zero at the atom

Let `Q0(z)=-z-z^2/2+z^4/2`. For a>0,c>0,R0>=0 define t0=a*c and

`eta=max(0,(1-t0^2)/2)+max(0,R0/t0-1)/t0`,
`P(z)=Q0(a*z)+eta*(a*z)^2`.

This majorizes `-1{z>0}+R0*floor((-z)/c)_+` for every real z.
For z>=0, `Q0(z)+1=(z-1)^2*(z^2+2z+2)/2>=0`.
For -c<z<=0, Q0(-y)=y*(1-y/2+y^3/2)>=0 for all y>=0:
the cubic factor has its minimum at1/sqrt(3), with positive value.
For z<=-c, let y=-a*z>=t0. Then

`P(z)-R0*y/t0 = y*(1-R0/t0)+y^2*[eta+(y^2-1)/2]>=0`.

The first eta summand offsets (y^2-1)/2; the second offsets the possible
negative linear term because y>=t0. This proves even the linear left-ray
envelope, including every floor knot. At z=0, P(0)=0 exactly, which is
essential for a noise-relative conclusion near lambda=0. No positive
constant padding or strict Sturm endpoint gate is used for this family.

Take a=a_lo on positive phases and a=a_hi on negative phases. The joint
count coupling, with increments at least c, supplies `Q/pi_k<=E P(W_k-u)`.
The exact linear term of this expectation is a*u, canceled by the matching
lower bound on f(u). With A=.55, centering, support and independence imply
`|E W_k^3|<=A*t` and `E W_k^4<=A^2*t+3*t^2`.
For h=|u|, therefore

`f(u)-E P(W_k-u) >= L(t,h)`
`L(t,h)=a^2*(1/2-eta)*(t+h^2)`
`       -a^4/2*(A^2*t+3*t^2+4*A*h*t+6*h^2*t+h^4)`.

L is concave in t. Its minimum on the actual variance interval is bounded
by its values t=omega_minus*lambda and t=omega_plus*lambda. Each of these
minus K*lambda is concave in lambda. It is therefore enough to check
lambda=0,U. At lambda=0, all h in[0,1/2] are covered by
`1/2-eta-a^2/8>=0`. At lambda=U, the test is just a univariate quartic in h
on[0,1/2], checked by exact Bernstein coefficients with a full dyadic cover.
There are four such quartics (two phase slopes, two variance endpoints).

If all these gates hold for K>0 and `m*K-max(0,kappa)/N>0`, the master
identity proves

`rhoB*(C-CB) <= -[m*K-max(0,kappa)/N]*lambda <0`

for every positive lambda in the stated domain. This implication is uniform
in the law, n, phase and moving threshold. It is not an inference from an
n=infinity calculation.

## r=1/n formulation and limits of the conclusion

The exact variance/skew formulas are rational in r:

`t=lambda*[1+r*delta*(alpha-p)/(pq)]`,
`S3=lambda*[(1-alpha)*(1-r*delta/q)*gamma0`
`           +alpha*(1+r*delta/p)*gamma1]`.

Normalization envelopes can likewise retain r instead of substituting1/N.
After splitting the positive-part branches of eta and clearing proved
positive denominators, the sufficient tests are polynomial inequalities on
closed boxes in p,r,lambda,u. Bernstein certificates can prove such a box
including r=0. A pilot only at r=0 cannot prove the box. In particular,
`f(u)=u+O(r*|u|)` cannot be absorbed into a lambda-relative error uniformly
as lambda tends to zero. The matched-slope family removes that problem.

Failure of a particular quartic/constant test is only failure of this
sufficient bound. It is not a counterexample. A successful n>=N result
still leaves47<=n<N and any other parameter rows unproved by this route.
