"""Coarsen the checked19 tail rows to one rational envelope and four quartics."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized Python required')
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import accept_all45 as source
core=source.core;poly=core.poly
C={'D':F(1067,1000),'c':F(19987,20000),'R':F(20039,20000),'B':F(931,250),'mass_lower':F(4011,5000),'kappa':F(52,125)}
LOWERS=((13449,2641,2242,12252,1883),(13492,2626,2116,11962,1377),(14250,3114,2845,13442,3186),(14296,3100,2717,13145,2665))
def main():
    src=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
    obj=source.strict_json(src.read_text());admission=source.accept(obj);assert admission['transfer_rows']==list(range(9,28))
    for row in(obj['rows'][i]for i in range(9,28)):
        r=row['constants']
        assert all(F(r[k])<=C[k]for k in('D','R','B','kappa'))
        assert all(C[k]<=F(r[k])for k in('c','mass_lower'))
    A,U,K,N=F(11,20),F(2,25),F(1,20),1000;omegas=(1-F(1067,398000),1+F(1067,398000));cases=[]
    for sign,a in(('positive',1-C['B']/N),('negative',1/(1-C['B']/N))):
        t0=a*C['c'];eta=max(F(0),(1-t0*t0)/2)+max(F(0),C['R']/t0-1)/t0
        phase0=F(1,2)-eta-a*a/8;assert phase0>=F(9,25)
        for omega in omegas:
            t=omega*U
            P=[a*a*(F(1,2)-eta)*t-a**4*(A*A*t+3*t*t)/2-K*U,-2*a**4*A*t,a*a*(F(1,2)-eta)-3*a**4*t,0,-a**4/2]
            target=poly.affine(P,F(0),F(1,2));coefficients=poly.bernstein(target)
            assert all(x>=F(y,10**6)>0 for x,y in zip(coefficients,LOWERS[len(cases)]))
            forest=[{'path':'','bernstein':list(map(str,coefficients))}];poly.accept_tree(forest,target)
            cases.append({'phase':sign,'a':str(a),'eta':str(eta),'omega':str(omega),'zero_noise_phase_margin':str(phase0),'Bernstein':list(map(str,coefficients)),'lower_numerators_over_1000000':LOWERS[len(cases)]})
    margin=C['mass_lower']*K-C['kappa']/N;assert margin==F(19847,500000)>F(39,1000)
    result={'status':'PASS_ONE_ENVELOPE_FOUR_QUARTICS_CENTRAL_N1000','inherited_tail_admission':admission['status'],'original_proof_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
      'common_constants':{k:str(v)for k,v in C.items()},'quartics':cases,'final_margin':str(margin),'scope':'same conditional45row n>=1000 tail; no finite47..999 conclusion'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'quartics':len(cases),'score_coefficients':20,'final_margin':str(margin)}))
if __name__=='__main__':main()
