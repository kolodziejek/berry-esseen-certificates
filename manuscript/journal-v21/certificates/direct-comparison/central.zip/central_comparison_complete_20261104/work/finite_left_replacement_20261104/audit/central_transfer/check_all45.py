"""Exact sufficient finite-n gates for the acquired complete acquired45row central domain.

This probes an explicit analytic majorant family; no all-central or full
manuscript theorem is claimed. A full successful census covers all n>=N. Smaller indices remain separate.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import hashlib,importlib.util,json,sys
if not __debug__ or sys.flags.optimize:raise RuntimeError("unoptimized Python required")
HERE=Path(__file__).resolve().parent;AUDIT=HERE.parent;ROOT=HERE.parents[3]
sys.path.insert(0,str(AUDIT))
assert hashlib.sha256((AUDIT/'quartic_global.py').read_bytes()).hexdigest()=='0760d772b6cf1858ed139a1fe179490cb1e523a5d685a37a25271a10b349aa35'
import quartic_global as poly
native=AUDIT/'native/finite_binomial_core.py'
assert hashlib.sha256(native.read_bytes()).hexdigest()=='939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f'
spec=importlib.util.spec_from_file_location('transfer_scalar_normal',native)
scalar=importlib.util.module_from_spec(spec);spec.loader.exec_module(scalar)
assert F('.39886')<scalar.PHI_LO<scalar.PHI_HI<F('.4')

def rootlo(x):return F(isqrt(x.numerator*10**24//x.denominator),10**12)
def rootup(x):return rootlo(x)+F(1,10**12)
def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return list(map(encode,x))
    return x

def data(index,N):
    path=ROOT/'work/below50_20260929/local/conditional_input47.json'
    pin='b9d2aa15ad96181f5a8eb846e76ae296d2c2c8ed1a5975c6f389c2f7d14ff2b7'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pin
    rows=json.loads(path.read_text())['panels'];assert len(rows)==45 and type(index)is int and 0<=index<45
    for j,r in enumerate(rows):assert r['index']==j and list(map(F,r['p']))==[F(190+j,500),F(191+j,500)]
    row=rows[index];pl,pu=map(F,row['p']);A=F(11,20);U=F(2,25)
    theta,d0,H=F(row['theta']),F(row['d0']),max(F(row['H_minus']),F(row['H_plus']))
    assert 0<=theta<1 and 0<=d0<=A and d0<pl
    sig,shi=F(3162277660,10**9),F(3162277661,10**9);assert sig*sig<10<shi*shi
    pstarlo,pstarhi=(4-shi)/2,(4-sig)/2
    distance=max(F(0),pstarlo-pu,pl-pstarhi)
    P0=(6+2*sig)*distance**2/rootup(pu*(1-pu))
    I=6*(1-theta)*rootlo((1-theta)/(pu*(1-pu)))*(1-d0)
    beta=min(3*(sig+1)*F(row['B_lo']),3*(sig+3)*F(row['A_lo']))-F(3,2)*P0
    budget=min(47*F(row['D']),F(row['T'])/F(997,15000));M=(1-pl)*A;E=budget-N*P0
    assert I>0 and beta>0 and M>0
    if E<0:return {'status':'EXCLUDED_BY_WEIGHTED_DEFECT','row':index,'N':N,'remaining_budget':E,'P0':P0,'budget':budget}
    if E==0:return {'status':'ONLY_ZERO_NOISE_BY_BUDGET','row':index,'N':N,'remaining_budget':E,'P0':P0,'budget':budget}
    price=I/M+beta/(pu*(1-pu)+F(row['lambda_max'])/N)
    cap=min(F(row['lambda_max']),E/price)
    acq={'source_sha256':pin,'noise_cap':cap,'noise_cap_target':U,'noise_cap_margin':U-cap,'inward_bound_coefficient':(budget-N*P0)/I,'P0':P0,'remaining_budget':E}
    return {'row':row,'pl':pl,'pu':pu,'A':A,'U':U,'H':H,'I':I,'budget':budget,'acquisition':acq}

def test(index,N,K=F(1,20),supplied=None):
    z=data(index,N)
    if 'status'in z:return z
    row,pl,pu,A,U,H,I,budget,acq=[z[k]for k in('row','pl','pu','A','U','H','I','budget','acquisition')]
    if acq['noise_cap']>U:return {'row':index,'N':N,'status':'NOT_CERTIFIED_NOISE_DOMAIN','acquisition':acq}
    vl=pl*(1-pl);vh=pu*(1-pu)
    d=min(F(row['d0']),acq['inward_bound_coefficient']/N);c=1-d
    D=max(F(1),H*rootup(vh+U/N)+F(1,2))
    left=pl-D/N;right=pu+D/N;assert 0<left<right<F(1,2)and N*left>1
    vf=left*(1-left);logv=(1-2*left)/vf;entropy=(1-2*left)/vf**2;factorial=1/(12*vf)
    Z=logv*D/2+factorial+entropy*D**3/(6*N)
    B=U/(2*vl)+D*D*U/(2*N*vl*vl)+(D+F(1,4))/(2*vl)+Z
    x=B/N;assert 0<x<1
    alo=1-x;ahi=1/(1-x)
    R=1+(pu+D-1)/(N*vl*(1-(D-1)/(N*pl)))
    assert pu+D<2 and R>=1 and c>0
    omega=(1-D/(N*pl),1+D/(N*pl));assert omega[0]>0
    m=F('.39886')/rootup(vh)*(1-(D*D/(2*vl)+Z)/N);assert m>0
    Qstar=6*pl-3*pl*pl-F(3,2)-d-3*(1-2*vl)*U/(8*vl*N);assert Qstar>0
    kappa=F('.4')*D/(2*vl*rootlo(vl))-F('.4')*Qstar/((vh+U/N)*rootup(vh+U/N))
    repair_margin=m*K-max(F(0),kappa)/N
    checks=[];success=repair_margin>0
    for branch_index,(name,a) in enumerate([('positive_phase',alo),('negative_phase',ahi)]):
        t0=a*c;eta=max(F(0),(1-t0*t0)/2)+max(F(0),R/t0-1)/t0
        zero_condition=F(1,2)-eta-a*a/8
        branch={'sign':name,'a':a,'eta':eta,'zero_noise_phase_margin':zero_condition,'variance_endpoints':[]}
        if zero_condition<0:success=False
        for variance_index,w in enumerate(omega):
            t=w*U
            # h=|u| in[0,.5]; lower f-EQ minus K*lambda at lambda=U.
            P=[a*a*(F(1,2)-eta)*t-a**4*(A*A*t+3*t*t)/2-K*U,
               -2*a**4*A*t,a*a*(F(1,2)-eta)-3*a**4*t,F(0),-a**4/2]
            restricted=poly.affine(P,F(0),F(1,2))
            try:
                leaves=poly.propose_tree(restricted,16,10000)if supplied is None else supplied['checks'][branch_index]['variance_endpoints'][variance_index]['coefficients']
                poly.accept_tree(leaves,restricted)
                result={'status':'PASS_EXACT_ALL_PHASES','leaves':len(leaves),'coefficients':leaves}
            except ValueError as e:
                success=False;result={'status':'NOT_CERTIFIED','reason':str(e),'endpoint_values':[P[0],sum(P[j]*F(1,2)**j for j in range(5))]}
            branch['variance_endpoints'].append({'omega':w,**result})
        checks.append(branch)
    return {'row':index,'N':N,'target_loss_per_lambda':K,'status':'PASS_SUFFICIENT_CENTRAL_ROW_FINITE_TRANSFER'if success else'NOT_CERTIFIED',
      'scope':'conditional on original indexed central row and independently licensed early .55 strip; lambda<=.08 derived from original joint budget; all n>=N, phases and positive noise if PASS',
      'acquisition':acq,'constants':{'D':D,'c':c,'R':R,'B':B,'mass_lower':m,'kappa':kappa,'repair_margin':repair_margin},'checks':checks}

def main():
    out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
    N=int(sys.argv[2])if len(sys.argv)>2 else 1000
    assert N>=47
    ans=[test(i,N)for i in range(45)]
    (out/'RESULT.json').write_text(json.dumps(encode(ans),indent=2)+'\n')
    print(json.dumps([{'row':r['row'],'N':r['N'],'status':r['status'],'repair_margin':float(r['constants']['repair_margin'])if 'constants'in r else None}for r in ans]))
    assert all(r['status']in('PASS_SUFFICIENT_CENTRAL_ROW_FINITE_TRANSFER','EXCLUDED_BY_WEIGHTED_DEFECT','ONLY_ZERO_NOISE_BY_BUDGET')for r in ans),'not every central row certified'
if __name__=='__main__':main()
