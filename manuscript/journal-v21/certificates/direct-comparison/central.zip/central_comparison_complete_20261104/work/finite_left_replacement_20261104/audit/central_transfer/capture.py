from pathlib import Path
import hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
files=list(HERE.glob('*.py'))+[HERE.parent/'quartic_global.py',HERE.parent/'native/finite_binomial_core.py',ROOT/'work/below50_20260929/local/conditional_input47.json']
def pins():return {str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files}
before=pins();argv=[sys.executable,'-I','-B',str(HERE/'accept_all45.py'),str(out/'accepted')]
if len(sys.argv)>2:argv.append(str(Path(sys.argv[2]).resolve()))
t=time.monotonic()
with (out/'stdout.txt').open('wb')as so,(out/'stderr.txt').open('wb')as se:r=subprocess.run(argv,cwd='/private/tmp',stdout=so,stderr=se)
rec={'argv':argv,'cwd':'/private/tmp','python':sys.version,'returncode':r.returncode,'elapsed_seconds':time.monotonic()-t,'source_before':before,'source_after':pins()}
rec['sources_unchanged']=rec['source_before']==rec['source_after'];(out/'PROCESS.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'returncode':r.returncode,'seconds':rec['elapsed_seconds'],'sources_unchanged':rec['sources_unchanged']}))
if r.returncode or not rec['sources_unchanged']:raise SystemExit(1)
