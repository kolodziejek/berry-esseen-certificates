"""Exact sufficient finite-n gates for the acquired critical central row only.

This probes an explicit analytic majorant family; no all-central or full
manuscript theorem is claimed. Every successful N covers all n>=N.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;AUDIT=HERE.parent;ROOT=HERE.parents[3]
sys.path.insert(0,str(AUDIT))
import quartic_global as poly

def rootlo(x):return F(isqrt(x.numerator*10**24//x.denominator),10**12)
def rootup(x):return rootlo(x)+F(1,10**12)
def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return list(map(encode,x))
    return x

def data():
    path=ROOT/'work/below50_20260929/local/conditional_input47.json'
    pin='b9d2aa15ad96181f5a8eb846e76ae296d2c2c8ed1a5975c6f389c2f7d14ff2b7'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pin
    row=json.loads(path.read_text())['panels'][19];pl,pu=map(F,row['p']);A=F(11,20);U=F(2,25)
    assert [pl,pu]==[F(209,500),F(21,50)]
    theta,d0,H=F(row['theta']),F(row['d0']),max(F(row['H_minus']),F(row['H_plus']))
    sig=F(3162277660,10**9);assert sig*sig<10
    I=6*(1-theta)*rootlo((1-theta)/(pu*(1-pu)))*(1-d0)
    beta=min(3*(sig+1)*F(row['B_lo']),3*(sig+3)*F(row['A_lo']))
    budget=min(47*F(row['D']),F(row['T'])/F(997,15000));M=(1-pl)*A
    price=I/M+beta/(pu*(1-pu)+F(row['lambda_max'])/47)
    assert I>0 and beta>0 and budget/price<U
    return row,pl,pu,A,U,H,I,budget,{'source_sha256':pin,'noise_cap':budget/price,'noise_cap_target':U,'noise_cap_margin':U-budget/price,'inward_bound_coefficient':budget/I}

def test(N,K=F(1,20)):
    row,pl,pu,A,U,H,I,budget,acq=data();vl=pl*(1-pl);vh=pu*(1-pu)
    d=min(F(row['d0']),budget/(I*N));c=1-d
    D=max(F(1),H*rootup(vh+U/N)+F(1,2))
    left=pl-D/N;right=pu+D/N;assert 0<left<right<F(1,2)and N*left>1
    vf=left*(1-left);logv=(1-2*left)/vf;entropy=(1-2*left)/vf**2;factorial=1/(12*vf)
    Z=logv*D/2+factorial+entropy*D**3/(6*N)
    B=U/(2*vl)+D*D*U/(2*N*vl*vl)+(D+F(1,4))/(2*vl)+Z
    x=B/N;assert 0<x<1
    alo=1-x;ahi=1/(1-x)
    R=1+(pu+D-1)/(N*vl*(1-(D-1)/(N*pl)))
    assert pu+D<2 and R>=1 and c>0
    omega=(1-D/(N*pl),1+D/(N*pl));assert omega[0]>0
    m=F('.39886')/rootup(vh)*(1-(D*D/(2*vl)+Z)/N);assert m>0
    Qstar=6*pl-3*pl*pl-F(3,2)-d-3*(1-2*vl)*U/(8*vl*N);assert Qstar>0
    kappa=F('.4')*D/(2*vl*rootlo(vl))-F('.4')*Qstar/((vh+U/N)*rootup(vh+U/N))
    repair_margin=m*K-max(F(0),kappa)/N
    checks=[];success=repair_margin>0
    for name,a in [('positive_phase',alo),('negative_phase',ahi)]:
        t0=a*c;eta=max(F(0),(1-t0*t0)/2)+max(F(0),R/t0-1)/t0
        zero_condition=F(1,2)-eta-a*a/8
        branch={'sign':name,'a':a,'eta':eta,'zero_noise_phase_margin':zero_condition,'variance_endpoints':[]}
        if zero_condition<0:success=False
        for w in omega:
            t=w*U
            # h=|u| in[0,.5]; lower f-EQ minus K*lambda at lambda=U.
            P=[a*a*(F(1,2)-eta)*t-a**4*(A*A*t+3*t*t)/2-K*U,
               -2*a**4*A*t,a*a*(F(1,2)-eta)-3*a**4*t,F(0),-a**4/2]
            restricted=poly.affine(P,F(0),F(1,2))
            try:
                leaves=poly.propose_tree(restricted,16,10000);poly.accept_tree(leaves,restricted)
                result={'status':'PASS_EXACT_ALL_PHASES','leaves':len(leaves),'coefficients':leaves}
            except ValueError as e:
                success=False;result={'status':'NOT_CERTIFIED','reason':str(e),'endpoint_values':[P[0],sum(P[j]*F(1,2)**j for j in range(5))]}
            branch['variance_endpoints'].append({'omega':w,**result})
        checks.append(branch)
    return {'N':N,'target_loss_per_lambda':K,'status':'PASS_SUFFICIENT_CRITICAL_ROW_FINITE_TRANSFER'if success else'NOT_CERTIFIED',
      'scope':'conditional on original central row19 and independently licensed early .55 strip; lambda<=.08 derived from original joint budget; all n>=N, phases and positive noise if PASS',
      'acquisition':acq,'constants':{'D':D,'c':c,'R':R,'B':B,'mass_lower':m,'kappa':kappa,'repair_margin':repair_margin},'checks':checks}

def main():
    out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
    ans=[test(n)for n in (47,100,200,500,1000)]
    (out/'RESULT.json').write_text(json.dumps(encode(ans),indent=2)+'\n')
    print(json.dumps([{'N':r['N'],'status':r['status'],'repair_margin':float(r['constants']['repair_margin'])}for r in ans]))
if __name__=='__main__':main()
