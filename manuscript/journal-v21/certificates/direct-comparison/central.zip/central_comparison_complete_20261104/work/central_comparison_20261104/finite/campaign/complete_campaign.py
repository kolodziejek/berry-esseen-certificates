"""Require all fixed finite central pairs, then replay every exact cover."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from inputs import PAIRS,PAIR_SET,CAPS,MAX_N,need
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict_json(text):
    def pairs(xs):
        out={}
        for k,v in xs:
            need(k not in out,'duplicate JSON key');out[k]=v
        return out
    def invalid(token):raise ValueError('nonfinite JSON number '+token)
    return json.loads(text,object_pairs_hook=pairs,parse_constant=invalid)
def inspect(inputs):
    records={}
    for root in inputs:
        need(root.exists()and not root.is_symlink(),'ordinary selected input root')
        files=sorted(root.glob('pair_*.json'))if root.is_dir()else[root]
        need(files,'nonempty selected root')
        for path in files:
            need(path.is_file()and not path.is_symlink(),'ordinary candidate file')
            obj=strict_json(path.read_text())
            need(type(obj)is dict and type(obj.get('row'))is int and type(obj.get('n'))is int,'strict pair identity')
            key=(obj['row'],obj['n']);need(key not in records,'duplicate complete pair')
            records[key]=(path,obj,sha(path))
    return records,sorted(PAIR_SET-set(records)),sorted(set(records)-PAIR_SET)
def source_pins():
    names=['inputs.py','partition.py','binomial_gap.py','gap_campaign.py','collect_gaps.py','bind_complete_gaps.py','complete_campaign.py',
      'root/cover.py','root/enclosures.py','root/cover_central.py','root/discover_cover.py','root/discover_central.py',
      'construction/quartic_gate.py','construction/quartic_gate24.py','construction/shifted_quartic_gate.py','construction/shifted_quartic_fast.py',
      'audit/quartic_global.py','audit/quartic_sturm.py','native/central.json','native/support47_hypotheses.json',
      'native/finite_binomial_core.py','native/gaps_campaign.json']
    return {name:{'bytes':(HERE/name).stat().st_size,'sha256':sha(HERE/name)}for name in names}
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',action='append',required=True);p.add_argument('--output',required=True)
    p.add_argument('--discovery-result',action='append',default=[]);p.add_argument('--inventory-only',action='store_true');a=p.parse_args()
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    records,missing,extra=inspect([Path(x).absolute()for x in a.input])
    inv={'schema':'COMPLETE_CENTRAL_FINITE_CAMPAIGN_INVENTORY_V1','expected':len(PAIRS),'provided':len(records),
      'missing':missing,'extra':extra,'mathematical_acceptance_claimed':False,
      'files':{'%d,%d'%key:{'path':str(v[0].resolve()),'sha256':v[2]}for key,v in sorted(records.items())}}
    (out/'INVENTORY.json').write_text(json.dumps(inv,indent=2)+'\n')
    need(not missing and not extra,'incomplete/extraneous finite central census')
    if a.inventory_only:
        print(json.dumps({'status':'COMPLETE_CENTRAL_BYTE_CENSUS_ONLY','pairs':len(records)}));return
    before=source_pins()
    spec=importlib.util.spec_from_file_location('complete_finite_central_cover',HERE/'root/cover_central.py')
    cover=importlib.util.module_from_spec(spec);spec.loader.exec_module(cover)
    discovery=[]
    for name in a.discovery_result:
        path=Path(name).resolve();need(path.is_file()and not path.is_symlink(),'ordinary discovery receipt')
        obj=strict_json(path.read_text());need(type(obj)is dict and type(obj.get('sources'))is dict,'discovery source record')
        for source,pin in obj['sources'].items():
            if source in before:need(pin==before[source]['sha256'],'matching discovery/acceptance source epoch')
        discovery.append({'path':str(path),'sha256':sha(path),'scope':'Actual construction record, not a replacement for exact readback.'})
    results=[]
    for key in PAIRS:
        path,obj,pin=records[key];need(sha(path)==pin,'unchanged candidate before readback')
        r=cover.accept_pair(obj);need((r['row'],r['n'])==key,'same accepted pair')
        results.append(r)
        if len(results)%100==0:print(json.dumps({'accepted':len(results),'total':len(PAIRS)}),flush=True)
    need(before==source_pins(),'all exact acceptance sources unchanged')
    need(all(sha(path)==pin for path,obj,pin in records.values()),'all proof objects unchanged')
    result={'status':'PASS_EXACT_COMPLETE_CENTRAL_FINITE_COMPARISON','pairs':len(results),'rows':45,'finite_n_domain':[47,MAX_N],
      'results':results,'caps':CAPS,'source_before':before,'source_after':source_pins(),'discovery_records':discovery,
      'seconds':time.monotonic()-started,'python':sys.version,
      'mathematical_scope':'Complete acquired central branch for finite47<=n<=999 using the exact joint-defect cap and all retained closed probability/count/phase/noise/shared-moment covers. Acquisition/early support premises remain inherited.',
      'separate_obligations':'No n>=1000 theorem or global all-law composition is inferred here.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('results','caps','source_before','source_after','discovery_records')},indent=2))
if __name__=='__main__':main()
