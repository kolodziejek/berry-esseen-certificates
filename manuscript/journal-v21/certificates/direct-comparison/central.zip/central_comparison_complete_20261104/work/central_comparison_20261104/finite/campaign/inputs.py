"""Fixed complete finite central domain and original early-strip input binding."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
MAX_N=999
PINS={'central.json':'b9d2aa15ad96181f5a8eb846e76ae296d2c2c8ed1a5975c6f389c2f7d14ff2b7',
      'support47_hypotheses.json':'5678ba9a7fa618b2f32eb222a12cd81df588bd12153882ee91fb54c90505a15b',
      'finite_binomial_core.py':'939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f'}
def need(v,s):
    if not v:raise ValueError(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
need(__debug__ and not sys.flags.optimize,'unoptimized exact acceptance')
for name,pin in PINS.items():need(sha(ROOT/'native'/name)==pin,'fixed native input '+name)
RAW=json.loads((ROOT/'native/central.json').read_text())
SUPPORT=json.loads((ROOT/'native/support47_hypotheses.json').read_text())
ROWS=RAW['panels'];EXTERIOR=SUPPORT['exterior']
need(len(ROWS)==len(EXTERIOR)==45,'all original central rows and early-strip hypotheses')
for i,(row,strip)in enumerate(zip(ROWS,EXTERIOR)):
    need(type(row['index'])is int and row['index']==i,'ordered raw row')
    need(list(map(F,row['p']))==[F(190+i,500),F(191+i,500)],'complete closed probability panel')
    need(row['p']==strip['p'],'early-strip p projection')
    for key in ('rho','theta'):need(F(row[key])==F(strip[key]),'early-strip '+key)
    need(F(row['beta_hi'])==F(strip['beta_upper']),'early-strip beta')
    need(max(F(row['H_plus']),F(row['H_minus']))==F(strip['H']),'early-strip signed H')
    need(0<=F(row['d0'])<F(row['p'][0]) and F(row['d0'])<=F(11,20),'same-law inward/support domains')

# The .55 bound is the conclusion of the separately reviewed early support
# theorem on these exact rows, not a consequence of this byte projection.
# candidate_amplitude is deliberately neither read nor used as a premise.

# Complete finite index restriction from the same simultaneous joint bound.
SIGMA_LO=F(3162277660,10**9);SIGMA_HI=F(3162277661,10**9)
KAPPA=F(997,15000)
need(SIGMA_LO**2<10<SIGMA_HI**2,'critical probability enclosure')
def lower(x):return F(x.numerator*10**10//x.denominator,10**10)
def root_upper(x):return F(isqrt(x.numerator*10**24//x.denominator)+1,10**12)
CAPS=[]
for i,row in enumerate(ROWS):
    pl,pu=map(F,row['p']);distance=max(F(0),(4-SIGMA_HI)/2-pu,pl-(4-SIGMA_LO)/2)
    P0=lower((6+2*SIGMA_LO)*distance**2/root_upper(pu*(1-pu)))
    beta=lower(min(3*(SIGMA_LO+1)*F(row['B_lo']),3*(SIGMA_LO+3)*F(row['A_lo']))-F(3,2)*P0)
    need(beta>0,'joint noise price licenses D>=P0')
    budget=min(47*F(row['D']),F(row['T'])/KAPPA)
    need(budget>0 and P0>=0,'raw weighted-budget domain')
    quotient=budget/P0 if P0 else None
    cap=quotient.numerator//quotient.denominator if quotient is not None else None
    last=min(MAX_N,cap)if cap is not None else MAX_N
    CAPS.append({'row':i,'p':row['p'],'P0':str(P0),'beta':str(beta),'budget':str(budget),
                 'joint_n_upper':cap,'last_finite_n':last,'pairs':max(0,last-46)})
PAIRS=tuple((r['row'],n)for r in CAPS for n in range(47,r['last_finite_n']+1))
PAIR_SET=frozenset(PAIRS)
need(len(PAIRS)==len(PAIR_SET)and len(CAPS)==45,'unique full finite domain')
