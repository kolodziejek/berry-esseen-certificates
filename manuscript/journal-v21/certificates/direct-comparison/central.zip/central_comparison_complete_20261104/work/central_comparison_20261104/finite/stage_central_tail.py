"""Stage frozen central-tail proof, complete runtime closure, and old captures.

Only byte integrity and a relocated import are checked here. The all45 tail
arithmetic was checked in the separately preserved original completed runs.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
TAIL = Path('work/finite_left_replacement_20261104/audit/central_transfer')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def need(value, text):
    if not value:
        raise ValueError(text)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized staging')
    portable = Path(args.portable).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    manifest = WORKSPACE / TAIL / 'FINAL_FILES.json'
    final = json.loads(manifest.read_text())
    selected = set(final['files'])
    selected.add(str(TAIL / 'FINAL_FILES.json'))
    for rel, pin in final['files'].items():
        p = WORKSPACE / rel
        need(p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], 'frozen final tail selection ' + rel)
    extras = [
        'work/finite_left_replacement_20261104/audit/quartic_global.py',
        'work/finite_left_replacement_20261104/audit/native/finite_binomial_core.py',
        'work/below50_20260929/local/conditional_input47.json',
        'work/below50_20260929/root/accept_support47.py',
        'work/below50_20260929/root/support47_hypotheses.json',
        'work/below50_20260929/root/panel_exterior.py',
        'work/below50_20260929/root/gaussian_core.py',
        'work/below50_20260929/root/panel_exterior_proof.tex']
    selected.update(extras)
    roots = ['audit_central_all45_capture01', 'audit_central_all45_readback01',
             'audit_central_common01', 'audit_central_tail_build04']
    observations = []
    for name in roots:
        root = WORKSPACE / 'runs/finite_left_replacement_20261104' / name
        process = json.loads((root / 'PROCESS.json').read_text())
        need(type(process['returncode']) is int and process['returncode'] == 0, 'completed actual tail capture')
        if 'sources_unchanged' in process:
            need(process['sources_unchanged'] is True, 'source-stable original tail arithmetic')
        observations.append({'root': str(root.relative_to(WORKSPACE)), 'process_sha256': sha(root/'PROCESS.json'),
                             'actual_returncode': process['returncode']})
        for path in root.rglob('*'):
            need(not path.is_symlink(), 'no symlinks in stopped evidence')
            if path.is_file():
                selected.add(str(path.relative_to(WORKSPACE)))
    records = []
    for name in sorted(selected):
        src = WORKSPACE / name
        need(src.is_file() and not src.is_symlink(), 'ordinary stopped source/input')
        pin = sha(src)
        dst = portable / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        with dst.open('xb') as f:
            f.write(src.read_bytes())
        need(sha(dst) == pin and sha(src) == pin, 'exact source/destination byte identity')
        records.append({'path': name, 'bytes': dst.stat().st_size, 'sha256': pin})
    spec = importlib.util.spec_from_file_location('relocated_tail_smoke', portable/TAIL/'accept_all45.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    need(module.core.ROOT == portable, 'relative original hierarchy resolves portable root')
    need(module.core.AUDIT.is_relative_to(portable), 'portable exact polynomial reader')
    need(Path(module.core.poly.__file__).is_relative_to(portable), 'no original quartic module import')
    need(Path(module.core.scalar.__file__).is_relative_to(portable), 'portable rational Gaussian core')
    need(module.header()['N'] == 1000, 'same imported fixed tail target')
    for f in records:
        need(sha(portable/f['path']) == f['sha256'], 'staged tail bytes unchanged')
    result = {'status': 'FROZEN_CENTRAL_TAIL_STAGED_AND_IMPORTED', 'files': records,
              'original_completed_captures': observations, 'final_files_sha256': sha(manifest),
              'module_root': str(module.core.ROOT), 'imported_header': module.header(),
              'scope': 'All45 n>=1000 conditional tail: original fresh exact captures preserved unchanged. This staging checks bytes and import closure only; it does not rerun the tail arithmetic or establish finite n<1000.',
              'early_support_scope': 'Original contact-support source/interface is included as an inherited premise; no new support/acquisition acceptance is claimed.',
              'stager_sha256': sha(Path(__file__))}
    target = portable/'TAIL_STAGE.json'
    with target.open('x') as f:
        f.write(json.dumps(result, indent=2)+'\n')
    (out/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': result['status'], 'files': len(records), 'tail_stage_sha256': sha(target)}))


if __name__ == '__main__':
    main()
