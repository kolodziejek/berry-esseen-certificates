"""Freeze completed construction objects for relocated separate acceptance.

This is byte selection/provenance checking, not mathematical acceptance.
Only completed actual producer captures are copied. The same candidate bytes
are then supplied as untrusted inputs to the unchanged portable exact reader.
"""
from pathlib import Path
import argparse, hashlib, json, sys

HERE = Path(__file__).resolve().parent
C = HERE / 'campaign'
sys.path.insert(0, str(C))
from inputs import PAIRS, PAIR_SET, need
from partition import SHARD_PAIRS
from complete_campaign import source_pins, strict_json


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('construction')
    ap.add_argument('portable')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized staging')
    src = Path(args.construction).resolve()
    portable = Path(args.portable).resolve()
    stage = strict_json((portable / 'SOURCE_STAGE.json').read_text())
    before = source_pins()
    for f in stage['files']:
        p = portable / f['path']
        need(p.is_file() and not p.is_symlink() and p.stat().st_size == f['bytes'] and sha(p) == f['sha256'],
             'unchanged staged input ' + f['path'])
    relocated = portable / 'work/central_comparison_20261104/finite/campaign'
    for name, pin in before.items():
        p = relocated / name
        need(p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'],
             'exact original/portable source equality ' + name)
    dstroot = portable / 'proof_objects/cover'
    dstroot.mkdir(parents=True, exist_ok=False)
    evidence = portable / 'evidence/construction'
    evidence.mkdir(parents=True, exist_ok=False)
    copied = []
    objects = []
    seen = set()

    def copy(srcfile, relative):
        need(srcfile.is_file() and not srcfile.is_symlink(), 'ordinary stopped source ' + str(srcfile))
        pin = sha(srcfile)
        dst = portable / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        with dst.open('xb') as stream:
            stream.write(srcfile.read_bytes())
        need(sha(dst) == pin and sha(srcfile) == pin, 'source/destination byte identity')
        rec = {'path': str(relative), 'source': str(srcfile), 'bytes': dst.stat().st_size, 'sha256': pin}
        copied.append(rec)
        return rec

    launch = strict_json((src / 'RESULT.json').read_text())
    need(launch['status'] == 'COMPLETED_DISCOVERY_SHARDS' and launch['sources_unchanged'] is True,
         'completed source-stable construction')
    need([x['shard'] for x in launch['results']] == list(range(4)) and
         all(type(x['returncode']) is int and x['returncode'] == 0 for x in launch['results']),
         'four actual successful supervisor observations')
    for index in range(4):
        run = src / f'shard{index}'
        start = strict_json((run / 'STARTED.json').read_text())
        process = strict_json((run / 'PROCESS.json').read_text())
        need(type(process['returncode']) is int and process['returncode'] == 0 and process['inputs_unchanged'] is True,
             'actual completed unchanged producer')
        for name in ('stdout', 'stderr'):
            need(sha(run / (name + '.txt')) == process[name + '_sha256'], 'actual stream integrity')
        argv = start['command']
        rows = sorted({r for r, n in SHARD_PAIRS[index]})
        need(argv[1:] == ['-I', '-B', str(C / 'root/discover_central.py'), str(run / 'objects'),
                           '--rows', ','.join(map(str, rows)), '--ns', 'all', '--maxdepth', '22', '--maxnodes', '10000'],
             'exact selected construction scope and entrypoint')
        for name, pin in before.items():
            need(start['inputs'].get(str(C / name)) == pin['sha256'], 'same original source epoch ' + name)
        summary = strict_json((run / 'objects/RESULT.json').read_text())
        need([(r['row'], r['n']) for r in summary['results']] == list(SHARD_PAIRS[index]),
             'complete ordered producer pair record')
        need(all(r['status'] == 'COMPLETE_EXACTLY_ACCEPTED' for r in summary['results']),
             'no unresolved producer record')
        paths = sorted((run / 'objects').glob('pair_*.json'))
        actual = {}
        for path in paths:
            obj = strict_json(path.read_text())
            need(type(obj) is dict and type(obj.get('row')) is int and type(obj.get('n')) is int,
                 'strict object pair identity')
            key = (obj['row'], obj['n'])
            need(key not in actual and key not in seen, 'unique selected object')
            actual[key] = path
            seen.add(key)
        need(set(actual) == set(SHARD_PAIRS[index]), 'complete fixed disjoint shard candidates')
        for key in SHARD_PAIRS[index]:
            path = actual[key]
            relative = Path(f'proof_objects/cover/shard{index}/objects') / path.name
            rec = copy(path, relative)
            objects.append({'row': key[0], 'n': key[1], **rec})
        for name in ('STARTED.json', 'PROCESS.json', 'stdout.txt', 'stderr.txt',
                     'objects/RESULT.json', 'objects/PROGRESS.json', 'objects/PROGRESS.jsonl'):
            copy(run / name, Path(f'evidence/construction/shard{index}') / name)
        for name in (f'shard{index}.wrapper.stdout', f'shard{index}.wrapper.stderr'):
            copy(src / name, Path('evidence/construction') / name)
    need(seen == PAIR_SET and len(objects) == len(PAIRS), 'complete entire fixed finite candidate census')
    for name in ('PLAN.json', 'RESULT.json'):
        copy(src / name, Path('evidence/construction') / name)
    need(before == source_pins(), 'original source bytes unchanged')
    result = {'status': 'COMPLETE_CENTRAL_CANDIDATES_STAGED_FOR_SEPARATE_REPLAY',
              'pairs': len(objects), 'objects': objects, 'files': copied,
              'sources': before, 'stager_sha256': sha(Path(__file__)),
              'scope': 'Complete byte census and actual completed construction provenance only. Relocated exact replay remains required; discovery output is not used as proof acceptance.'}
    target = portable / 'OBJECT_STAGE.json'
    with target.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'pairs': len(objects), 'stage_sha256': sha(target)}))


if __name__ == '__main__':
    main()
