"""Bounded domain/schema/unchanged-formula controls; no campaign arithmetic."""
from pathlib import Path
import ast,copy,hashlib,json,sys
HERE=Path(__file__).resolve().parent;WORKSPACE=HERE.parents[2];CAMPAIGN=HERE/'campaign'
sys.path.insert(0,str(CAMPAIGN))
import gap_campaign as reader
from inputs import PAIRS,PAIR_SET,need
from partition import SHARD_PAIRS,SHARD_ROWS,SHARD_WEIGHTS
from complete_campaign import inspect,strict_json
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def functions(path):
    return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
def main():
    out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=False);before=reader.pins()
    need(len(PAIRS)==25908 and len(PAIR_SET)==25908,'fixed complete census')
    need(sum(SHARD_WEIGHTS)==25908 and set().union(*map(set,SHARD_PAIRS))==PAIR_SET,'complete disjoint full scope')
    need(sum(map(len,SHARD_PAIRS))==25908,'no duplicate shard pairs')
    unchanged={}
    for file,names in [('binomial_gap.py',['endpoint','cdf_curvature','normal_curvature','round_up','round_down','panel']),
                       ('root/enclosures.py',['p0_lower','qmax','resource','binomial','parameters','encode'])]:
        old,new=functions(HERE/file),functions(CAMPAIGN/file)
        need(all(old[name]==new[name]for name in names),'unchanged reviewed numerical functions '+file)
        unchanged[file]=names
    originals=[]
    for i in range(4):
        path=WORKSPACE/f'runs/central_comparison_20261104/finite_gap_shards01/shard{i}/build/proposed/proof_object.json'
        obj=reader.strict_json(path.read_text());reader.validate(obj,i);originals.append({'path':str(path),'sha256':sha(path)})
    obj=reader.strict_json(Path(originals[0]['path']).read_text());rejected=[]
    def trial(name,change):
        bad=copy.deepcopy(obj);change(bad)
        try:reader.validate(bad,0)
        except(ValueError,KeyError,TypeError):rejected.append(name)
        else:raise AssertionError('accepted '+name)
    trial('missing_pair',lambda z:z['pairs'].pop())
    trial('duplicate_pair',lambda z:z['pairs'].append(copy.deepcopy(z['pairs'][0])))
    trial('reordered_pairs',lambda z:z['pairs'].reverse())
    trial('wrong_shard',lambda z:z.update(shard=1))
    trial('boolean_shard',lambda z:z.update(shard=False))
    trial('narrowed_probability',lambda z:z['pairs'][0].update(p=['.381','.382']))
    trial('missing_count',lambda z:z['pairs'][0]['counts'].pop())
    trial('changed_integer',lambda z:z['pairs'][0].update(n=1000))
    trial('boolean_integer',lambda z:z['pairs'][0].update(n=True))
    trial('floating_grid',lambda z:z['pairs'][0].update(subdivisions=8.0))
    trial('weakened_gap_target',lambda z:z.update(minimum_epsilon='0'))
    trial('one_jump_branch',lambda z:z.update(both_jump_sides=False))
    trial('open_probability',lambda z:z.update(closed_probability=False))
    trial('changed_source',lambda z:z['sources'].update(**{'inputs.py':'0'*64}))
    candidate=WORKSPACE/'runs/central_comparison_20261104/finite_cover_build02/objects/pair_19_999.json'
    rec,missing,extra=inspect([candidate]);need(len(rec)==1 and len(missing)==25907 and not extra,'one pair cannot close full campaign')
    try:inspect([candidate,candidate])
    except ValueError:rejected.append('duplicate_whole_candidate')
    else:raise AssertionError('duplicate whole candidate')
    for name,text in [('duplicate_json','{"n":47,"n":999}'),('nonfinite_json','{"n":NaN}')]:
        try:strict_json(text)
        except ValueError:rejected.append(name)
        else:raise AssertionError(name)
    need(before==reader.pins(),'all active gap sources unchanged')
    need(all(sha(Path(r['path']))==r['sha256']for r in originals),'all active proposed objects unchanged')
    result={'status':'PASS_BOUNDED_CENTRAL_CAMPAIGN_CONTROLS','pairs':25908,'shard_weights':SHARD_WEIGHTS,
      'unchanged_numerical_function_AST':unchanged,'rejections':rejected,'missing_pairs_detected':len(missing),
      'sources':before,'read_only_proposals':originals,
      'scope':'Domain/census/schema and source-equivalence controls only; running exact gap acceptance and later whole score comparison remain separate.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
