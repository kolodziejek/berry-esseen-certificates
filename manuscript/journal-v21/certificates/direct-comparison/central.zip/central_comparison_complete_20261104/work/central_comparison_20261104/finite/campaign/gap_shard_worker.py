"""One fixed gap shard: discovery followed by a fresh exact captured replay."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;WORKSPACE=HERE.parents[3]
sys.path.insert(0,str(HERE))
import gap_campaign as reader
from inputs import need
CAPTURE=WORKSPACE/'work/certificate_consolidation_20261104/capture_process.py'
CAPTURE_PIN='48e67827d2eaca9f60c8877bc7113ff98a1c5e73bd2f5e69fe12efecbe8d7727'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('output');p.add_argument('--shard',type=int,choices=range(4),required=True);a=p.parse_args()
    need(__debug__ and not sys.flags.optimize and sha(CAPTURE)==CAPTURE_PIN,'reviewed unoptimized capture supervisor')
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);before=reader.pins();start=time.monotonic();records=[]
    for phase in ('build','accept'):
        run=out/phase;destination=run/('proposed'if phase=='build'else'accepted')
        command=[sys.executable,'-I','-B',str(CAPTURE)]
        for name in before:command+=['--input',str((HERE/name).resolve())]
        candidate=out/'build/proposed/proof_object.json'
        if phase=='accept':command+=['--input',str(candidate)]
        command += [str(run),'--',sys.executable,'-I','-B',str(HERE/'gap_campaign.py'),phase,str(destination)]
        if phase=='accept':command+=['--object',str(candidate)]
        command+=['--shard',str(a.shard)]
        with(out/(phase+'.wrapper.stdout')).open('xb')as stdout,(out/(phase+'.wrapper.stderr')).open('xb')as stderr:
            child=subprocess.run(command,cwd=WORKSPACE,stdout=stdout,stderr=stderr)
        records.append({'phase':phase,'command':command,'returncode':child.returncode,
          'stdout_sha256':sha(out/(phase+'.wrapper.stdout')),'stderr_sha256':sha(out/(phase+'.wrapper.stderr'))})
        if child.returncode:break
    need(before==reader.pins(),'gap sources unchanged through both phases')
    result={'status':'COMPLETED_EXACT_GAP_SHARD_REPLAY'if len(records)==2 and all(r['returncode']==0 for r in records)else'GAP_SHARD_PHASE_FAILED',
      'shard':a.shard,'phases':records,'sources':before,'seconds':time.monotonic()-start,
      'scope':'Only the selected fixed shard; complete four-shard join remains separate.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    if result['status']!='COMPLETED_EXACT_GAP_SHARD_REPLAY':raise SystemExit(1)
if __name__=='__main__':main()
