"""Exact bivariate gates for one global Q(W-u), preserving phase as a variable.

This is separate from the immutable unshifted kernels. The caller supplies
a phase-zero all-real majorant Q of the coupled payoff and a sign-correct
positive phase coefficient. Gate tensors have bidegree at most (6,4).
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import hashlib
import quartic_gate24 as base
EXPECTED=Path(__file__).with_name('quartic_gate24.py').resolve()
BASE_PIN='e1e99806639ce4cb382c239c3748007a6da3acb7e7757495bb7258e7f7809d04'
base.need(Path(base.__file__).resolve()==EXPECTED and hashlib.sha256(EXPECTED.read_bytes()).hexdigest()==BASE_PIN,'fixed inward-support kernel dependency')
need=base.need

def lift(poly,udegree=0,factor=1):
    factor=F(factor);return{(j,udegree):F(x)*factor for j,x in enumerate(poly)if x*factor!=0}
def add(*polys):
    out={}
    for p in polys:
        for key,x in p.items():out[key]=out.get(key,F(0))+F(x)
    return{k:x for k,x in out.items()if x!=0}
def scale(poly,factor):
    factor=F(factor);return{k:x*factor for k,x in poly.items()if x*factor!=0}
def evaluate(poly,p,u):
    p,u=F(p),F(u);return sum(x*p**i*u**j for(i,j),x in poly.items())

def affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi,ul,uh,phasecoef):
    ul,uh,phasecoef=map(F,(ul,uh,phasecoef))
    need(F(phase)==0,'shifted interface uses variable phase, old scalar phase must be zero')
    need(-F(1,2)<=ul<=uh<=F(1,2)and(uh<=0 or ul>=0),'closed sign-split phase cell')
    need(phasecoef>0,'positive sign-correct phase coefficient')
    old=base.affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,0,varcoef,cgain,blo,bhi)
    out=[]
    for record in old:
        # (n*v)^2 * phasecoef*u; all other scalar terms are unchanged.
        constant=add(lift(record['constant']),lift(base.V2,1,phasecoef*n*n))
        linear=[]
        # Q(W-u)=sum_h q_h sum_j<=h binom(h,j) W^j (-u)^(h-j).
        for h in range(5):
            linear.append(add(*(lift(record['linear'][j],h-j,comb(h,j)*(-1)**(h-j))for j in range(h+1))))
        out.append({k:v for k,v in record.items()if k not in('constant','linear')}|{'constant':constant,'linear':tuple(linear)})
    need(len(out)==24 and all(i<=6 and j<=4 for z in out for poly in[z['constant'],*z['linear']]for i,j in poly),'fixed complete bivariate gate scope')
    return out

def gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi,q,ul,uh,phasecoef):
    q=tuple(map(F,q));need(len(q)==5 and q[4]>=0,'translated quartic has nonnegative leading coefficient')
    rows=affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi,ul,uh,phasecoef)
    return[add(row['constant'],*(scale(poly,x)for poly,x in zip(row['linear'],q)))for row in rows]

def bernstein(poly,pl,pu,ul,uh,degree=(6,4)):
    """Exact tensor coefficients on the whole closed p/u rectangle: 7x5 by default."""
    pl,pu,ul,uh=map(F,(pl,pu,ul,uh));dp,du=degree
    need(pl<pu and ul<=uh and type(dp)is int and type(du)is int and dp>=0 and du>=0,'tensor rectangle and degrees')
    need(all(type(i)is int and type(j)is int and 0<=i<=dp and 0<=j<=du for i,j in poly),'power tensor degree')
    affine={}
    for(i,j),coef in poly.items():
        coef=F(coef)
        for a in range(i+1):
          for b in range(j+1):
            value=coef*comb(i,a)*pl**(i-a)*(pu-pl)**a*comb(j,b)*ul**(j-b)*(uh-ul)**b
            affine[a,b]=affine.get((a,b),F(0))+value
    return tuple(tuple(sum(value*F(comb(i,a),comb(dp,a))*F(comb(j,b),comb(du,b))
      for(a,b),value in affine.items()if a<=i and b<=j)for j in range(du+1))for i in range(dp+1))

def bernstein_affine(record,pl,pu,ul,uh):
    return {'constant':bernstein(record['constant'],pl,pu,ul,uh),
            'linear':tuple(bernstein(z,pl,pu,ul,uh)for z in record['linear'])}

def bracket_gates(n,pl,pu,L,U,A0,A1,d0):
    return base.bracket_gates(n,pl,pu,L,U,A0,A1,d0)

def direct_loss(n,k,p,lam,u,A0,A1,gap,phasecoef,varcoef,cgain,b,q,alpha,gamma,J4):
    """Uncleared independent expectation expansion, for constructor controls."""
    p,lam,u,gap,phasecoef,varcoef,cgain,b,gamma,J4=map(F,(p,lam,u,gap,phasecoef,varcoef,cgain,b,gamma,J4))
    q=tuple(map(F,q));v=p*(1-p);t=lam*(F(n-k,n)/(1-p)if alpha==0 else F(k,n)/p)
    moments=(F(1),F(0),t,t*gamma,J4*t+3*t*t)
    shifted=[sum(F(comb(h,j))*(-u)**(h-j)*moments[j]for j in range(h+1))for h in range(5)]
    Eq=sum(a*x for a,x in zip(q,shifted))
    G=3*p-gamma if alpha==0 else 3*(1-p)+gamma
    price=cgain*lam/n*(G-F(3,2)*(1-2*v)-3*(1-2*v)*lam/(8*n*v))
    return gap+phasecoef*u+varcoef*lam+price-b*Eq
