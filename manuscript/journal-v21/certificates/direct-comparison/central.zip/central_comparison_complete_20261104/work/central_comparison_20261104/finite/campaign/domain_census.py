"""Read the complete finite domain; performs no Gaussian or quartic work."""
from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from inputs import PAIRS,PAIR_SET,CAPS,MAX_N,PINS,need
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
need(len(CAPS)==45 and len(PAIRS)==len(PAIR_SET),'unique complete census')
need(all((i,n)in PAIR_SET for i in range(45)for n in range(47,CAPS[i]['last_finite_n']+1)),'every retained integer')
need(all((i,CAPS[i]['last_finite_n']+1)not in PAIR_SET for i in range(45)),'no index past declared finite scope')
result={'status':'PASS_EXACT_CENTRAL_FINITE_DOMAIN_ONLY','rows':45,'n_domain':[47,MAX_N],
  'pair_count':len(PAIRS),'caps':CAPS,'pairs':[list(x)for x in PAIRS],
  'sources':{'inputs.py':sha(HERE/'inputs.py'),'domain_census.py':sha(Path(__file__))},'native_inputs':PINS,
  'mathematical_scope':'Same-law joint defect and raw weighted/signed budget restrict the finite comparison to precisely these pairs; no score comparison or tail theorem is asserted.',
  'execution_scope':'Exact rational cap and ordered integer census only; no finite gap or quartic campaign executed.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in('pairs','caps')},indent=2))
