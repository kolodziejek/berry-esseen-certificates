"""Complete union of four actual source/output-bound exact cover replays."""
from pathlib import Path
import argparse,hashlib,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from inputs import PAIRS,PAIR_SET,CAPS,MAX_N,need
from partition import SHARD_PAIRS
from complete_campaign import strict_json
from replay_cover_shard import source_pins
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read_shard(run,index):
    need(run.is_dir()and not run.is_symlink(),'ordinary completed replay root')
    files=[run/'STARTED.json',run/'PROCESS.json',run/'stdout.txt',run/'stderr.txt',run/'accepted/RESULT.json']
    need(all(p.is_file()and not p.is_symlink()for p in files),'complete ordinary replay captures')
    pins={str(p):sha(p)for p in files};start=strict_json(files[0].read_text());process=strict_json(files[1].read_text())
    need(type(process['returncode'])is int and process['returncode']==0 and process['inputs_unchanged']is True,'actual unchanged complete replay')
    for name in ('stdout','stderr'):need(sha(run/(name+'.txt'))==process[name+'_sha256'],'actual captured stream')
    argv=start['command'];need(len(argv)==10 and argv[1:5]==['-I','-B',str(HERE/'replay_cover_shard.py'),'--input'],'exact native replay entrypoint')
    need(argv[6]=='--output'and Path(argv[7]).resolve()==run/'accepted'and argv[8:]==['--shard',str(index)],'fixed selected shard/output command')
    current=source_pins()
    for name,pin in current.items():need(start['inputs'].get(str((HERE/name).resolve()))==pin['sha256'],'complete actual source input '+name)
    summary=strict_json((run/'stdout.txt').read_text().splitlines()[-1])
    need(summary['result_sha256']==sha(files[-1]),'complete actual output byte binding')
    result=strict_json(files[-1].read_text())
    need(result['status']=='PASS_EXACT_CENTRAL_FINITE_COVER_SHARD'and type(result['shard'])is int and result['shard']==index,'same completed shard identity')
    need(type(result['pairs'])is int and result['pairs']==len(SHARD_PAIRS[index])and result['sources']==current,'complete current source/census')
    need(Path(result['input_root']).resolve()==Path(argv[5]).resolve(),'same selected candidate directory')
    need(len(result['results'])==len(SHARD_PAIRS[index]),'complete accepted pair results')
    expected_keys={'%d,%d'%key for key in SHARD_PAIRS[index]};need(set(result['inputs'])==expected_keys,'complete exact candidate input census')
    for record,key in zip(result['results'],SHARD_PAIRS[index]):
        need(type(record['row'])is int and type(record['n'])is int and (record['row'],record['n'])==key,'same ordered accepted pair')
        need(record['status']=='PASS_EXACT_COMPLETE_TRANSLATED_CENTRAL_ALL45_FINITE_PAIR','whole native per-pair success')
        inp=result['inputs']['%d,%d'%key];path=Path(inp['path'])
        need(path.parent.resolve()==Path(argv[5]).resolve()and path.is_file()and not path.is_symlink(),'ordinary same-root candidate')
        need(sha(path)==inp['sha256'],'accepted candidate remains unchanged')
    need(pins=={str(p):sha(p)for p in files},'all completed replay bytes unchanged during union')
    return result,{'run':str(run),'files':pins,'actual_returncode':0,'output_bound_in_stdout':True}
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',action='append',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    need(len(a.input)==4,'four ordered replay roots');out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
    before=source_pins();results={};receipts=[]
    for i,name in enumerate(a.input):
        result,receipt=read_shard(Path(name).resolve(),i);receipts.append(receipt)
        for r in result['results']:
            key=(r['row'],r['n']);need(key not in results,'disjoint accepted pair ownership');results[key]=r
    need(set(results)==PAIR_SET,'complete full finite central cover')
    need(before==source_pins(),'unchanged whole source closure')
    rows=[results[key]for key in PAIRS]
    result={'status':'PASS_EXACT_COMPLETE_CENTRAL_FINITE_COMPARISON','pairs':len(rows),'rows':45,'finite_n_domain':[47,MAX_N],
      'results':rows,'caps':CAPS,'source_before':before,'source_after':source_pins(),'accepted_replays':receipts,
      'collector_sha256':sha(Path(__file__)),
      'mathematical_scope':'All acquired central laws with47<=n<=999 are covered by joint-defect index exclusions or complete exact closed count/p/phase/noise/shared-moment comparisons; original acquisition and early support premises retained.',
      'execution_scope':'Four actual source/output-bound full per-pair arithmetic replays joined without repeating their arithmetic.',
      'separate_obligations':'n>=1000 and global theorem composition are separate analytic inputs.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'pairs':len(rows),'result_sha256':sha(out/'RESULT.json')}),flush=True)
if __name__=='__main__':main()
