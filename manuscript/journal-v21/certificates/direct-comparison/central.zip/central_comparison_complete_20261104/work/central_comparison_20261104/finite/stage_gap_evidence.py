"""Copy stopped gap/capture/smoke evidence without rewriting execution identity."""
from pathlib import Path
import argparse, hashlib, json, sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
RUNS = Path('runs/central_comparison_20261104')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def need(value, message):
    if not value:
        raise ValueError(message)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized evidence selection')
    portable, out = map(lambda p: Path(p).resolve(), (args.portable, args.output))
    out.mkdir(parents=True, exist_ok=False)
    selected = set()
    completed = [
        'finite_gap_shards_capture01', 'finite_gap_collect01', 'finite_gap_bind01',
        'finite_campaign_controls01', 'finite_gap_capture_controls01',
        'finite_portable_sources01', 'finite_portable_smoke01', 'finite_portable_tail01']
    observations = []
    for name in completed:
        root = WORKSPACE / RUNS / name
        p = json.loads((root / 'PROCESS.json').read_text())
        need(type(p['returncode']) is int and p['returncode'] == 0 and p['inputs_unchanged'] is True,
             'actual completed source-stable selected run')
        for stream in ('stdout', 'stderr'):
            need(sha(root / (stream + '.txt')) == p[stream + '_sha256'], 'actual captured stream identity')
        observations.append({'root': str(root.relative_to(WORKSPACE)), 'process_sha256': sha(root/'PROCESS.json')})
        for leaf in ('STARTED.json', 'PROCESS.json', 'stdout.txt', 'stderr.txt'):
            selected.add(str(RUNS / name / leaf))
        for leaf in ('checked/RESULT.json', 'checked/SYNTHETIC_FIXTURE.json'):
            if (root / leaf).is_file():
                selected.add(str(RUNS / name / leaf))
    for name in ('finite_gap_shards01', 'finite_gap_collect01'):
        root = WORKSPACE / RUNS / name
        for p in root.rglob('*'):
            need(not p.is_symlink(), 'no selected evidence symlinks')
            if p.is_file():
                selected.add(str(p.relative_to(WORKSPACE)))
    helpers = ['check_campaign_controls.py', 'check_gap_capture_controls.py',
               'check_portable_smoke.py', 'stage_portable_sources.py', 'stage_central_tail.py',
               'stage_completed_objects.py', 'check_cover_capture_controls.py', 'stage_gap_evidence.py']
    for name in helpers:
        selected.add(str((HERE / name).relative_to(WORKSPACE)))
    records = []
    for name in sorted(selected):
        src = WORKSPACE / name
        need(src.is_file() and not src.is_symlink(), 'ordinary selected stopped file')
        pin = sha(src)
        dst = portable / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        with dst.open('xb') as stream:
            stream.write(src.read_bytes())
        need(sha(dst) == pin and sha(src) == pin, 'exact copied evidence bytes')
        records.append({'path': name, 'bytes': dst.stat().st_size, 'sha256': pin})
    result = {'status': 'STOPPED_CENTRAL_GAP_EVIDENCE_STAGED', 'files': records,
              'completed_captures': observations, 'source_sha256': sha(Path(__file__)),
              'scope': 'Archival identity only; no new numerical acceptance. Original command paths and runtime records are retained verbatim.',
              'disposable_fixture_exclusion': 'The gap mutation runs retain control code, actual process/streams, RESULT and synthetic-fixture descriptor. Reusable synthetic fixture trees and mutated large copies are omitted; no native acceptance data are omitted.'}
    target = portable / 'GAP_EVIDENCE_STAGE.json'
    with target.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'files': len(records), 'stage_sha256': sha(target)}))


if __name__ == '__main__':
    main()
