"""Discover a grid, then independently replay exact gaps on the fixed full finite central domain."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import binomial_gap as core
from inputs import PAIRS,PINS,ROWS,need
from partition import SHARD_PAIRS
TARGET=F(1,100000000)
SCHEMA='FIXED_CENTRAL_FINITE_BERNOULLI_GAP_SHARD_V1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pins():
    out={name:sha(HERE/name)for name in ['inputs.py','partition.py','binomial_gap.py','gap_campaign.py']}
    for name,pin in PINS.items():
        actual=sha(HERE/'native'/name);need(actual==pin,'unchanged pinned native input '+name);out['native/'+name]=actual
    return out
def strict_json(text):
    def pairs(xs):
        out={}
        for k,v in xs:
            need(k not in out,'duplicate JSON key');out[k]=v
        return out
    return json.loads(text,object_pairs_hook=pairs)
def record(i,n,sub):return {'row':i,'n':n,'p':ROWS[i]['p'],'counts':core.count_domain(i,n),'subdivisions':sub}
def validate(obj,shard):
    need(type(shard)is int and 0<=shard<4,'external fixed shard index')
    need(type(obj)is dict and set(obj)=={'schema','shard','sources','minimum_epsilon','closed_probability','both_jump_sides','pairs'},'fixed gap object fields')
    need(type(obj['shard'])is int and obj['shard']==shard,'same externally selected shard')
    need(obj['schema']==SCHEMA and obj['sources']==pins() and obj['minimum_epsilon']==str(TARGET),'fixed target/source scope')
    need(obj['closed_probability']is True and obj['both_jump_sides']is True,'closed probability and both atom branches')
    need(type(obj['pairs'])is list and len(obj['pairs'])==len(SHARD_PAIRS[shard]),'complete fixed shard census')
    for d,(i,n)in zip(obj['pairs'],SHARD_PAIRS[shard]):
        need(type(d)is dict and set(d)=={'row','n','p','counts','subdivisions'},'exact domain fields')
        sub=d['subdivisions'];need(type(sub)is int and sub in [2**j for j in range(3,13)],'permitted complete regular grid')
        want=record(i,n,sub)
        need(json.dumps(d,sort_keys=True)==json.dumps(want,sort_keys=True),'original closed p/index/count domain')
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['build','accept']);p.add_argument('output');p.add_argument('--object');p.add_argument('--shard',type=int,choices=range(4),required=True);a=p.parse_args()
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);before=pins()
    if a.mode=='build':
        specs=[];history=[]
        for i,n in SHARD_PAIRS[a.shard]:
            for j in range(3,13):
                sub=2**j;r=core.panel(i,n,sub);minimum=min(F(z['epsilon'])for z in r['rows'])
                history.append({'row':i,'n':n,'subdivisions':sub,'minimum_epsilon':str(minimum)})
                print(json.dumps(history[-1]),flush=True)
                if minimum>=TARGET:specs.append(record(i,n,sub));break
            else:raise ValueError('fixed positive gap target unresolved for '+str((i,n)))
        obj={'schema':SCHEMA,'shard':a.shard,'sources':before,'minimum_epsilon':str(TARGET),
             'closed_probability':True,'both_jump_sides':True,'pairs':specs}
        validate(obj,a.shard);need(before==pins(),'unchanged construction sources')
        (out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n')
        (out/'DISCOVERY.json').write_text(json.dumps({'history':history,'scope':'Exact grid discovery only; separate acceptance required.'},indent=2)+'\n')
        return
    need(a.object is not None,'explicit proposed object')
    obj=strict_json(Path(a.object).read_text());validate(obj,a.shard);results=[]
    for d in obj['pairs']:
        r=core.panel(d['row'],d['n'],d['subdivisions'])
        need(r['count_cover']==d['counts']and all(F(z['epsilon'])>=TARGET for z in r['rows']),'exact fixed positive gap gate')
        results.append(r)
        if len(results)%100==0:print(json.dumps({'accepted':len(results),'total':len(SHARD_PAIRS[a.shard]),'shard':a.shard}),flush=True)
    need(before==pins(),'unchanged exact gap sources')
    result={'status':'PASS_EXACT_CENTRAL_FINITE_BERNOULLI_GAP_SHARD','shard':a.shard,'row_n_pairs':len(SHARD_PAIRS[a.shard]),
        'count_pairs':sum(len(r['rows'])for r in results),
        'closed_branch_cells':sum(2*r['subdivisions']*len(r['rows'])for r in results),
        'minimum_epsilon':str(min(F(z['epsilon'])for r in results for z in r['rows'])),
        'gaps':results,'sources':before,
        'mathematical_scope':'One externally fixed complete finite central shard on original closed p/count/jump domains, under inherited same-law acquisition and early support premises.',
        'execution_scope':'Fresh exact recomputation of proposed grids; whole-four-shard union, noisy comparison and n>=1000 are separate.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps({**{k:v for k,v in result.items()if k not in ('gaps','sources')},
      'result_sha256':sha(out/'RESULT.json'),'proof_sha256':sha(out/'proof_object.json')}),flush=True)
if __name__=='__main__':main()
