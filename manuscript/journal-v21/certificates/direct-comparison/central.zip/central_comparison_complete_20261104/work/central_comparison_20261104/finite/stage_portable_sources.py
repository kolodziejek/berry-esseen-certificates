"""Create-only relocation of frozen source/input bytes; no proof promotion."""
from pathlib import Path
import argparse, hashlib, json, shutil, sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
CAMPAIGN = HERE / 'campaign'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output')
    args = parser.parse_args()
    if not __debug__ or sys.flags.optimize:
        raise ValueError('Unoptimized staging required')
    target = Path(args.output).resolve()
    target.mkdir(parents=True, exist_ok=False)
    names = [
        'collect_gaps.py', 'collect_cover_replays.py', 'gap_shard_worker.py',
        'replay_cover_shard.py', 'complete_campaign.py', 'construction/quartic_gate24.py',
        'construction/shifted_quartic_fast.py', 'construction/shifted_quartic_gate.py',
        'construction/quartic_gate.py', 'root/enclosures.py', 'root/discover_central.py',
        'root/discover_cover.py', 'root/cover_central.py', 'root/cover.py', 'launch_covers.py',
        'audit/quartic_global.py', 'audit/quartic_sturm.py', 'inputs.py',
        'launch_cover_replays.py', 'binomial_gap.py', 'gap_campaign.py',
        'launch_gap_shards.py', 'bind_complete_gaps.py', 'native/finite_binomial_core.py',
        'native/gaps_campaign.json', 'native/support47_hypotheses.json', 'native/central.json',
        'partition.py', 'PREPARATION.json', 'GAP_BINDING.json', 'domain_census.py']
    selections = [(CAMPAIGN / name, (CAMPAIGN / name).relative_to(WORKSPACE)) for name in names]
    capture = WORKSPACE / 'work/certificate_consolidation_20261104/capture_process.py'
    selections.append((capture, capture.relative_to(WORKSPACE)))
    for i in range(4):
        proof = WORKSPACE / f'runs/central_comparison_20261104/finite_gap_shards01/shard{i}/accept/accepted/proof_object.json'
        selections.append((proof, Path(f'proof_objects/gaps/shard{i}.json')))
    records = []
    for src, rel in selections:
        if not src.is_file() or src.is_symlink():
            raise ValueError('Expected ordinary frozen source/input: ' + str(src))
        pin = sha(src)
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        with dst.open('xb') as f:
            f.write(src.read_bytes())
        if sha(dst) != pin or sha(src) != pin:
            raise ValueError('Byte identity changed while copying: ' + str(src))
        records.append({'path': str(rel), 'source': str(src.relative_to(WORKSPACE)),
                        'bytes': dst.stat().st_size, 'sha256': pin})
    result = {'status': 'FROZEN_CENTRAL_SOURCE_AND_GAP_CANDIDATES_RELOCATED',
              'files': records, 'file_count': len(records),
              'scope': 'Byte-identical portable inputs only. Full noisy finite comparison remains pending.',
              'stager_sha256': sha(Path(__file__))}
    (target / 'SOURCE_STAGE.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'files': len(records),
                      'source_stage_sha256': sha(target / 'SOURCE_STAGE.json')}))


if __name__ == '__main__':
    main()
