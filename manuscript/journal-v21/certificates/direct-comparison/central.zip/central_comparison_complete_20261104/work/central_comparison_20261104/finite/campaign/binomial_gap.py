"""Exact complete finite central gaps; original generic curvature/normal bodies unchanged."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import importlib.util,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from inputs import PAIRS,PAIR_SET,PINS,ROWS,need
spec=importlib.util.spec_from_file_location('central_pinned_normal',HERE/'native/finite_binomial_core.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
def count_domain(i,n):
    need(type(i)is int and type(n)is int and (i,n)in PAIR_SET,'licensed finite central pair')
    row=ROWS[i];pl,pu=map(F,row['p']);theta=F(row['theta'])
    ell=C.root((1-theta)/(pu*(1-pu)))[0];need(ell>0,'positive acquired span')
    xmin=n*pl-F(row['H_minus'])/ell-F(1,2)
    xmax=n*pu+F(row['H_plus'])/ell+F(1,2)
    return list(range(max(0,C.ceildiv(xmin.numerator,xmin.denominator)),min(n,xmax.numerator//xmax.denominator)+1))
def endpoint(n,p,ks):
    """Both binomial jump limits and Gaussian CDF for selected actual counts."""
    a,M=p.numerator,p.denominator;den=M**n;b=(M-a)**n;cum=0;ans={}
    for j in range(n+1):
        prev=cum;cum+=b
        if j in ks:
            phlo,phhi=C.cdf_at(n,j,a,M)
            ans[j]=(prev*C.S//den,C.ceildiv(prev*C.S,den),cum*C.S//den,C.ceildiv(cum*C.S,den),phlo,phhi)
        if j<n:
            v=b*(n-j)*a;d=(j+1)*(M-a);need(v%d==0,'integer binomial mass recurrence');b=v//d
    need(cum==den and set(ans)==set(ks),'complete selected count sums')
    return ans

def cdf_curvature(n,j,l,u):
    if j==-1 or j==n:return F(0)
    need(0<=j<n,'binomial CDF derivative index')
    p=max(l,min(u,F(j,n-1)))
    d=n*comb(n-1,j)*p**j*(1-p)**(n-1-j)
    return d*max(abs((n-1)*l-j),abs((n-1)*u-j))/(l*(1-l))

def normal_curvature(n,k,l,u):
    v=l*(1-l);sr=C.root(v)[0];sn=C.root(F(n))[0]
    a=max(abs(k-n*l),abs(k-n*u));B=max(k+(n-2*k)*l,k+(n-2*k)*u)
    need(B>0 and sr>0 and sn>0,'normal derivative denominators')
    z=a/(sn*sr);z1=B/(2*sn*v*sr)
    z2=abs(n-2*k)/(2*sn*v*sr)+3*B*(1-2*l)/(4*sn*v*v*sr)
    return F(2,5)*(z2+z*z1*z1)

def round_up(q,scale=10**12):return F(C.ceildiv(q.numerator*scale,q.denominator),scale)

def round_down(q,scale=10**12):return F(q.numerator*scale//q.denominator,scale)

def panel(i,n,subdiv):
    need(type(subdiv)is int and 1<=subdiv<=4096,'subdivision integer')
    ks=count_domain(i,n);r=ROWS[i];pl,pu=map(F,r['p']);h=(pu-pl)/subdiv
    left=endpoint(n,pl,ks);best={k:{'+':F(0),'-':F(0)}for k in ks}
    for a in range(subdiv):
        l=pl+a*h;u=l+h;right=endpoint(n,u,ks);v=u*(1-u);factor=C.root(n*v)[1]/(1-2*v)
        for k in ks:
            normal=normal_curvature(n,k,l,u)
            for sign,j,li,ri in [('+',k,3,4),('-',k-1,5,0)]:
                dleft=F(left[k][li]-left[k][ri],C.S);dright=F(right[k][li]-right[k][ri],C.S)
                M=normal+cdf_curvature(n,j,l,u)
                d=max(F(0),max(dleft,dright)+M*h*h/8)
                best[k][sign]=max(best[k][sign],factor*d)
        left=right
    rholo=(1-2*pu*(1-pu))/C.root(pu*(1-pu))[1]
    out=[]
    for k in ks:
        caps={s:round_up(b)for s,b in best[k].items()};cap=max(caps.values());eps=round_down(C.CE_LO-cap)
        out.append({'k':k,'score_caps':{s:str(q)for s,q in caps.items()},'epsilon':str(eps),'rhoB_epsilon':str(round_down(rholo*eps))})
    return {'row':i,'n':n,'p':r['p'],'subdivisions':subdiv,'count_cover':ks,'rhoB_lower':str(rholo),'rows':out}
