"""Final byte/evidence join after actual whole finite acceptance, no new math."""
from pathlib import Path
import argparse, hashlib, json, sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
R = Path('runs/central_comparison_20261104')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def completed(root):
    process = read(root / 'PROCESS.json')
    need(type(process['returncode']) is int and process['returncode'] == 0 and process['inputs_unchanged'] is True,
         'actual completed unchanged capture ' + str(root))
    for name in ('stdout', 'stderr'):
        need(sha(root / (name + '.txt')) == process[name + '_sha256'], 'actual complete stream binding')
    return process


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized final admission')
    portable = Path(args.portable).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    need((portable / 'README.md').is_file(), 'final reader-facing README must exist before inventory')
    need(not (portable / 'COMPLETION.json').exists() and not (portable / 'FILES.json').exists(),
         'create-only final completion and inventory')
    c = portable / 'work/central_comparison_20261104/finite/campaign'
    sys.path.insert(0, str(c))
    import collect_cover_replays as collector
    from inputs import PAIRS, PAIR_SET, CAPS
    replay = WORKSPACE / R / 'finite_portable_cover_replays01'
    union = WORKSPACE / R / 'finite_portable_cover_union01'
    controls = WORKSPACE / R / 'finite_portable_cover_controls01'
    complete = completed(union)
    completed(controls)
    summary = collector.strict_json((union / 'stdout.txt').read_text().splitlines()[-1])
    resultpath = union / 'accepted/RESULT.json'
    need(summary['result_sha256'] == sha(resultpath), 'actual whole-union output bytes')
    result = collector.strict_json(resultpath.read_text())
    need(result['status'] == 'PASS_EXACT_COMPLETE_CENTRAL_FINITE_COMPARISON' and result['pairs'] == 25908
         and result['rows'] == 45 and result['finite_n_domain'] == [47, 999], 'fixed entire finite scope')
    need(result['source_before'] == result['source_after'] == collector.source_pins(), 'unchanged exact portable acceptance closure')
    need(result['caps'] == CAPS and len(result['results']) == len(PAIRS)
         and [(r['row'], r['n']) for r in result['results']] == list(PAIRS), 'exact ordered full pair/cap census')
    accepted = []
    observed = {}
    for index in range(4):
        shard, receipt = collector.read_shard(replay / f'shard{index}', index)
        accepted.append(receipt)
        for row in shard['results']:
            key = (row['row'], row['n'])
            need(key not in observed, 'disjoint actual accepted replay records')
            observed[key] = row
    need(set(observed) == PAIR_SET and [observed[key] for key in PAIRS] == result['results'],
         'union equals four actual accepted outputs')
    need(accepted == result['accepted_replays'], 'exact whole-union provenance')
    control = read(controls / 'checked/RESULT.json')
    need(control['status'] == 'PASS_BOUNDED_CENTRAL_COVER_CAPTURE_CONTROLS' and control['rejections'] == 24
         and all(x['rejected'] is True for x in control['controls']), 'complete bounded admission controls')
    need(control['sources'] == collector.source_pins(), 'controls test final acceptance source closure')
    tail_stage = read(portable / 'TAIL_STAGE.json')
    for f in tail_stage['files']:
        need(sha(portable / f['path']) == f['sha256'], 'original tail evidence/source bytes remain unchanged')
    tailroot = Path('runs/finite_left_replacement_20261104/audit_central_all45_readback01')
    tail = read(portable / tailroot / 'accepted/RESULT.json')
    need(tail['status'] == 'PASS_EXACT_COMPLETE_EARLY_CENTRAL45_N_GE_1000_TAIL'
         and tail['probability_rows'] == 45 and len(tail['negative_controls']) == 21,
         'selected original complete tail scope')
    tail_replay = WORKSPACE / R / 'finite_portable_tail_replay01'
    completed(tail_replay)
    fresh_tail = read(tail_replay / 'checked/RESULT.json')
    need(fresh_tail['status'] == 'PASS_RELOCATED_COMPLETE_CENTRAL_TAIL'
         and fresh_tail['rows'] == 45 and fresh_tail['n_lower'] == 1000,
         'complete fresh portable tail supervisor')
    need(fresh_tail['sources']['replay_tail.py']['sha256'] == sha(portable/'replay_tail.py')
         and fresh_tail['sources']['TAIL_STAGE.json']['sha256'] == sha(portable/'TAIL_STAGE.json'),
         'unchanged portable tail supervisor and fixed selection')
    tail_summary = read(tail_replay / 'stdout.txt')
    need(tail_summary['result_sha256'] == sha(tail_replay / 'checked/RESULT.json'),
         'actual relocated tail output byte binding')
    need(fresh_tail['accepted_result_sha256'] == sha(tail_replay / 'checked/accepted/RESULT.json')
         == sha(portable / tailroot / 'accepted/RESULT.json'),
         'relocated complete tail reproduces exact original result bytes')
    need(fresh_tail['common_result_sha256'] == sha(tail_replay / 'checked/common/RESULT.json'),
         'actual common-envelope output bytes retained')
    selected = set()
    capture_names = ['finite_cover_launch01', 'finite_portable_objects01',
                     'finite_portable_cover_replays_capture01', 'finite_portable_cover_union01',
                     'finite_portable_cover_controls01', 'finite_portable_gap_evidence01',
                     'finite_portable_analytic_draft02']
    for name in capture_names:
        root = WORKSPACE / R / name
        completed(root)
        for leaf in ('STARTED.json', 'PROCESS.json', 'stdout.txt', 'stderr.txt'):
            selected.add(str(R / name / leaf))
        for leaf in ('accepted/RESULT.json', 'checked/RESULT.json', 'checked/SYNTHETIC_FIXTURE.json'):
            if (root / leaf).is_file():
                selected.add(str(R / name / leaf))
    # All full native replay captures are preserved; disposable mutant trees
    # are deliberately not duplicated in this publication package.
    for replay_root in (replay, tail_replay):
        for p in replay_root.rglob('*'):
            need(not p.is_symlink(), 'ordinary stopped replay tree')
            if p.is_file():
                selected.add(str(p.relative_to(WORKSPACE)))
    failed = WORKSPACE / R / 'finite_portable_analytic_draft01'
    need(read(failed / 'PROCESS.json')['returncode'] == 1, 'preserved failed draft selection')
    for name in ('STARTED.json', 'PROCESS.json', 'stdout.txt', 'stderr.txt'):
        selected.add(str(R / 'finite_portable_analytic_draft01' / name))
    for name in ('stage_integration_draft.py', 'stage_integration_draft_v2.py', 'finalize_portable.py', 'archive_portable.py'):
        selected.add(str((HERE / name).relative_to(WORKSPACE)))
    copied = []
    for name in sorted(selected):
        src = WORKSPACE / name
        need(src.is_file() and not src.is_symlink(), 'ordinary stopped evidence')
        pin = sha(src)
        dst = portable / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            need(dst.is_file() and not dst.is_symlink() and sha(dst) == pin,
                 'already staged identical evidence only')
        else:
            with dst.open('xb') as stream:
                stream.write(src.read_bytes())
        need(sha(src) == sha(dst) == pin, 'unchanged selected original/copy bytes')
        copied.append({'path': name, 'bytes': dst.stat().st_size, 'sha256': pin})
    totals = {key: sum(r[key] for r in result['results']) for key in ('quartics', 'excluded', 'splits')}
    totals['maxdepth'] = max(r['maxdepth'] for r in result['results'])
    totals['score_Bernstein_coefficients'] = 24 * 7 * 5 * totals['quartics']
    completion = {'status': 'PASS_COMPLETE_ACQUIRED_CENTRAL_COMPARISON',
                  'mathematical_scope': 'Original45 acquired central rows, all integer n>=47, conditional on original attainment/contact acquisition, early .55 support and the stated Bernoulli theorem. This is a comparison-module completion, not a new stand-alone global theorem.',
                  'finite': {'n': [47, 999], 'row_n_pairs': 25908, 'joint_defect_excluded_pairs': 16977,
                             'result': str((R / 'finite_portable_cover_union01/accepted/RESULT.json')),
                             'result_sha256': sha(resultpath), **totals},
                  'tail': {'n_lower': 1000, 'rows': 45, 'result': str(tailroot / 'accepted/RESULT.json'),
                           'result_sha256': sha(portable / tailroot / 'accepted/RESULT.json'),
                           'relocated_result': str(R / 'finite_portable_tail_replay01/checked/RESULT.json'),
                           'relocated_result_sha256': sha(tail_replay / 'checked/RESULT.json')},
                  'execution_boundaries': {
                      'finite_gaps': 'Fresh complete original-workspace exact replay; every portable byte checked plus one relocated critical panel smoke, not another whole gap replay.',
                      'finite_comparison': 'Fresh complete four-shard exact replay from relocated byte-identical source/candidate tree.',
                      'tail': 'Original exact acceptance preserved; fresh full relocated tail acceptance plus21 controls and four-quartic common envelope passed through the additive tempfile supervisor. Numerical readers remain unchanged.',
                      'implementation_independence': 'Construction and separate replay share reviewed exact arithmetic; no independent implementation claim.'},
                  'controls': {'gap_capture_rejections': 21, 'cover_capture_rejections': 24, 'tail_rejections': 21},
                  'analytic_explanation': 'proofs/integration-draft05/main.pdf is a preserved pre-completion analytic draft; its pending labels retain their historical status. The separate four-page tail proof is selected by TAIL_STAGE.json.',
                  'copied_final_evidence': copied,
                  'disposable_mutant_exclusion': 'Full native captures are included. Large reusable synthetic fixture trees are omitted; control code, actual process/streams, mutation results and explicit fixture descriptors are retained.'}
    with (portable / 'COMPLETION.json').open('x') as stream:
        stream.write(json.dumps(completion, indent=2) + '\n')
    files = []
    for path in sorted(portable.rglob('*')):
        need(not path.is_symlink(), 'no publication symlinks')
        if path.is_file():
            rel = str(path.relative_to(portable))
            need('__pycache__' not in path.parts and path.suffix != '.pyc', 'no runtime cache in package')
            need(path.stat().st_size < 100000000, 'publication file size bound')
            files.append({'path': rel, 'bytes': path.stat().st_size, 'sha256': sha(path)})
    canonical = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
    inventory = {'schema': 'COMPLETE_CENTRAL_COMPARISON_PORTABLE_FILES_V1', 'files': files,
                 'file_count': len(files), 'bytes': sum(f['bytes'] for f in files),
                 'tree_sha256': hashlib.sha256(canonical).hexdigest(), 'excludes_self': 'FILES.json'}
    with (portable / 'FILES.json').open('x') as stream:
        stream.write(json.dumps(inventory, indent=2) + '\n')
    report = {'status': completion['status'], 'files': inventory['file_count'], 'bytes': inventory['bytes'],
              'tree_sha256': inventory['tree_sha256'], 'inventory_sha256': sha(portable/'FILES.json'),
              'completion_sha256': sha(portable/'COMPLETION.json'), 'finite_totals': totals}
    (out / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
