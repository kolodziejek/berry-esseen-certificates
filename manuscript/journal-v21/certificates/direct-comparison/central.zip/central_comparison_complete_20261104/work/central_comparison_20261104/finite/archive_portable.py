"""Create-only ZIP plus complete decompressed-member identity verification."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, stat, sys, zipfile

PREFIX = 'central_comparison_complete_20261104'


def digest(stream):
    h = hashlib.sha256()
    total = 0
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        total += len(block)
        h.update(block)
    return total, h.hexdigest()


def sha(path):
    with path.open('rb') as stream:
        return digest(stream)[1]


def need(value, message):
    if not value:
        raise ValueError(message)


def safe(name):
    p = PurePosixPath(name)
    need(type(name) is str and name == str(p) and not p.is_absolute()
         and all(x not in ('', '.', '..') for x in p.parts)
         and '\\' not in name and '\x00' not in name, 'safe canonical relative file path')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('archive')
    ap.add_argument('union')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized publication verification')
    portable, archive, union, out = map(lambda p: Path(p).resolve(),
                                       (args.portable, args.archive, args.union, args.output))
    out.mkdir(parents=True, exist_ok=False)
    inventory = json.loads((portable / 'FILES.json').read_text())
    completion = json.loads((portable / 'COMPLETION.json').read_text())
    need(completion['status'] == 'PASS_COMPLETE_ACQUIRED_CENTRAL_COMPARISON', 'completed selected mathematical module')
    need(completion['finite']['result_sha256'] == sha(union), 'fresh whole-union binding')
    expected = {}
    for record in inventory['files']:
        name = record['path']
        safe(name)
        need(name not in expected, 'unique manifest member')
        expected[name] = {'bytes': record['bytes'], 'sha256': record['sha256']}
    need(len(expected) == inventory['file_count'] and sum(x['bytes'] for x in expected.values()) == inventory['bytes'],
         'complete manifest count and bytes')
    canonical = json.dumps(inventory['files'], sort_keys=True, separators=(',', ':')).encode()
    need(hashlib.sha256(canonical).hexdigest() == inventory['tree_sha256'], 'canonical complete tree hash')
    expected['FILES.json'] = {'bytes': (portable/'FILES.json').stat().st_size, 'sha256': sha(portable/'FILES.json')}
    actual = set()
    for path in portable.rglob('*'):
        need(not path.is_symlink(), 'no source symlinks')
        if path.is_file():
            actual.add(str(path.relative_to(portable)))
    need(actual == set(expected), 'entire publication tree equals final manifest plus manifest itself')
    for name, pin in expected.items():
        path = portable / name
        need(path.is_file() and path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], 'source member identity')
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, mode='x', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
        for name in sorted(expected):
            z.write(portable / name, PREFIX + '/' + name)
    verified = []
    with zipfile.ZipFile(archive, 'r') as z:
        infos = z.infolist()
        names = [entry.filename for entry in infos]
        wanted = {PREFIX + '/' + name for name in expected}
        need(len(names) == len(set(names)) and set(names) == wanted, 'unique exact one-prefix ZIP census')
        for entry in infos:
            safe(entry.filename)
            need(not entry.is_dir() and stat.S_IFMT(entry.external_attr >> 16) != stat.S_IFLNK,
                 'ordinary archived file, no symlink/directory surrogate')
            rel = entry.filename[len(PREFIX)+1:]
            pin = expected[rel]
            with z.open(entry) as stream:
                size, h = digest(stream)
            need(size == entry.file_size == pin['bytes'] and h == pin['sha256'],
                 'complete decompressed member byte identity ' + rel)
            verified.append({'path': entry.filename, 'bytes': size, 'sha256': h})
    for name, pin in expected.items():
        need(sha(portable/name) == pin['sha256'], 'published source bytes unchanged after archive roundtrip')
    tail = portable / completion['tail']['result']
    need(sha(tail) == completion['tail']['result_sha256'], 'selected original tail result binding')
    result = {'status': 'PASS_COMPLETE_CENTRAL_ARCHIVE_ROUNDTRIP', 'archive': str(archive),
              'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
              'prefix': PREFIX, 'member_count': len(verified), 'logical_bytes': sum(r['bytes'] for r in verified),
              'files_sha256': sha(portable/'FILES.json'), 'tree_sha256': inventory['tree_sha256'],
              'completion_sha256': sha(portable/'COMPLETION.json'),
              'fresh_union': str(union), 'fresh_union_sha256': sha(union),
              'original_tail_result_sha256': sha(tail), 'members': verified,
              'source_sha256': sha(Path(__file__)),
              'scope': 'Every archived member fully decompressed and compared by path/size/SHA256; no second filesystem extraction and no arithmetic replay.'}
    (out/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'members'}))


if __name__ == '__main__':
    main()
