"""Bounded mutation tests of completed relocated cover replay admissions.

Actual source/capture files and candidate objects remain untouched. Synthetic
fixture output hashes are regenerated only to test later semantic predicates;
these fixtures are explicitly not execution evidence or proof acceptance.
"""
from pathlib import Path
import argparse, copy, hashlib, json, shutil, sys


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def need(value, message):
    if not value:
        raise AssertionError(message)


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('actual')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized controls')
    portable = Path(args.portable).resolve()
    c = portable / 'work/central_comparison_20261104/finite/campaign'
    sys.path.insert(0, str(c))
    import collect_cover_replays as reader
    actual = Path(args.actual).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    sources = reader.source_pins()
    sources_extra = {str(p): sha(p) for p in (Path(__file__), c / 'collect_cover_replays.py')}
    real = [reader.read_shard(actual / f'shard{i}', i)[1] for i in range(4)]
    fixture = out / 'synthetic_fixture'
    shutil.copytree(actual / 'shard0', fixture)
    names = ['STARTED.json', 'PROCESS.json', 'stdout.txt', 'stderr.txt', 'accepted/RESULT.json']
    start = json.loads((fixture / 'STARTED.json').read_text())
    start['command'][7] = str(fixture / 'accepted')
    dump(fixture / 'STARTED.json', start)
    reader.read_shard(fixture, 0)
    baseline = {name: (fixture / name).read_bytes() for name in names}
    dump(out / 'SYNTHETIC_FIXTURE.json', {
        'scope': 'Disposable mutation fixture; not an actual process capture.',
        'source': str(actual / 'shard0'),
        'changes': ['Only STARTED output path changed for fixture baseline.',
                    'Semantic mutants consistently regenerate synthetic output/stream hashes.'],
        'baseline': {name: hashlib.sha256(data).hexdigest() for name, data in baseline.items()}})
    controls = []
    mutants = out / 'mutants'
    mutants.mkdir()

    def restore():
        for name, data in baseline.items():
            (fixture / name).write_bytes(data)

    def reject(name, file, change, rebound=False, missing=False):
        restore()
        target = fixture / file
        if missing:
            target.rename(fixture / 'intentionally_missing.json')
        elif file.endswith('.json'):
            obj = json.loads(target.read_text())
            change(obj)
            dump(target, obj)
        else:
            target.write_bytes(target.read_bytes() + b'\nCORRUPTED\n')
        if rebound:
            summary = json.loads((fixture / 'stdout.txt').read_text().splitlines()[-1])
            summary['result_sha256'] = sha(fixture / 'accepted/RESULT.json')
            dump(fixture / 'stdout.txt', summary)
            process = json.loads((fixture / 'PROCESS.json').read_text())
            process['stdout_sha256'] = sha(fixture / 'stdout.txt')
            dump(fixture / 'PROCESS.json', process)
        changed = {part: sha(fixture / part) if (fixture / part).exists() else None for part in names}
        try:
            reader.read_shard(fixture, 0)
        except (AssertionError, ValueError, KeyError, TypeError, FileNotFoundError) as exc:
            controls.append({'name': name, 'rejected': True, 'reason': str(exc),
                             'synthetic_rebinding': rebound, 'files': changed})
            if not missing:
                (mutants / (name + '.mutant')).write_bytes(target.read_bytes())
        else:
            raise AssertionError('Mutation admitted: ' + name)
        if missing:
            (fixture / 'intentionally_missing.json').rename(target)

    result_file = 'accepted/RESULT.json'
    reject('missing_process', 'PROCESS.json', None, missing=True)
    reject('nonzero_rc', 'PROCESS.json', lambda d: d.update(returncode=1))
    reject('boolean_rc', 'PROCESS.json', lambda d: d.update(returncode=False))
    reject('changed_inputs', 'PROCESS.json', lambda d: d.update(inputs_unchanged=False))
    reject('corrupt_stdout', 'stdout.txt', None)
    reject('uncaptured_output_change', result_file, lambda d: d.update(pairs=0))
    reject('source_input_hash', 'STARTED.json', lambda d: d['inputs'].update({str(c/'inputs.py'): '0'*64}))
    reject('wrong_output_argv', 'STARTED.json', lambda d: d['command'].__setitem__(7, str(out/'wrong')))
    reject('wrong_shard_argv', 'STARTED.json', lambda d: d['command'].__setitem__(9, '1'))
    reject('wrong_input_argv', 'STARTED.json', lambda d: d['command'].__setitem__(5, str(out/'wrong')))
    reject('boolean_shard', result_file, lambda d: d.update(shard=False), True)
    reject('boolean_pair_count', result_file, lambda d: d.update(pairs=True), True)
    reject('wrong_input_root', result_file, lambda d: d.update(input_root=str(out/'wrong')), True)
    reject('missing_pair', result_file, lambda d: d['results'].pop(), True)
    reject('duplicate_pair', result_file, lambda d: d['results'].__setitem__(1, copy.deepcopy(d['results'][0])), True)
    reject('reordered_pairs', result_file, lambda d: d['results'].reverse(), True)
    reject('boolean_row', result_file, lambda d: d['results'][0].update(row=False), True)
    reject('wrong_count_index', result_file, lambda d: d['results'][0].update(n=48), True)
    reject('invalid_pair_status', result_file, lambda d: d['results'][0].update(status='partial'), True)
    reject('source_map_type', result_file, lambda d: d.update(sources=[]), True)
    reject('missing_candidate_key', result_file, lambda d: d['inputs'].pop(next(iter(d['inputs']))), True)
    reject('extra_candidate_key', result_file, lambda d: d['inputs'].update({'0,46': next(iter(d['inputs'].values()))}), True)
    first = '0,47'
    reject('wrong_candidate_root', result_file, lambda d: d['inputs'][first].update(path=str(out/'wrong/object.json')), True)
    reject('wrong_candidate_hash', result_file, lambda d: d['inputs'][first].update(sha256='0'*64), True)
    restore()
    reader.read_shard(fixture, 0)
    need(sources == reader.source_pins(), 'unchanged arithmetic source closure')
    need(sources_extra == {name: sha(Path(name)) for name in sources_extra}, 'unchanged control/collector sources')
    for i, receipt in enumerate(real):
        need(receipt == reader.read_shard(actual / f'shard{i}', i)[1], 'actual captures untouched')
    result = {'status': 'PASS_BOUNDED_CENTRAL_COVER_CAPTURE_CONTROLS',
              'actual_shards_read': 4, 'rejections': len(controls), 'controls': controls,
              'actual_evidence': real, 'sources': sources, 'extra_sources': sources_extra,
              'scope': 'Readback and admission mutations only, with no native arithmetic replay; original proof objects and actual captures untouched.'}
    dump(out / 'RESULT.json', result)
    print(json.dumps({'status': result['status'], 'rejections': len(controls),
                      'result_sha256': sha(out / 'RESULT.json')}))


if __name__ == '__main__':
    main()
