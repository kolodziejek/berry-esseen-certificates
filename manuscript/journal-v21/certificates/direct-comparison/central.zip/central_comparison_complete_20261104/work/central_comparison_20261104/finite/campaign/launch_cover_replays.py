"""Replay the four fixed construction shards concurrently under exact captures."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;WORKSPACE=HERE.parents[3]
sys.path.insert(0,str(HERE))
from inputs import need
from replay_cover_shard import source_pins
CAPTURE=WORKSPACE/'work/certificate_consolidation_20261104/capture_process.py'
CAPTURE_PIN='48e67827d2eaca9f60c8877bc7113ff98a1c5e73bd2f5e69fe12efecbe8d7727'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('construction');p.add_argument('output');a=p.parse_args()
    need(__debug__ and not sys.flags.optimize and sha(CAPTURE)==CAPTURE_PIN,'reviewed unoptimized capture')
    construction=Path(a.construction).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
    before=source_pins();started=time.time();jobs=[]
    (out/'PLAN.json').write_text(json.dumps({'construction':str(construction),'sources':before,'launcher_sha256':sha(Path(__file__))},indent=2)+'\n')
    for i in range(4):
        source=construction/f'shard{i}'/'objects';need(source.is_dir(),'selected completed construction root')
        run=out/f'shard{i}';argv=[sys.executable,'-I','-B',str(CAPTURE)]
        for name in before:argv+=['--input',str((HERE/name).resolve())]
        argv += [str(run),'--',sys.executable,'-I','-B',str(HERE/'replay_cover_shard.py'),
          '--input',str(source),'--output',str(run/'accepted'),'--shard',str(i)]
        stdout=(out/f'shard{i}.stdout').open('xb');stderr=(out/f'shard{i}.stderr').open('xb')
        child=subprocess.Popen(argv,cwd=WORKSPACE,stdout=stdout,stderr=stderr);jobs.append((i,child,stdout,stderr,argv))
    results=[]
    for i,child,stdout,stderr,argv in jobs:
        code=child.wait();stdout.close();stderr.close()
        results.append({'shard':i,'command':argv,'returncode':code,'stdout_sha256':sha(out/f'shard{i}.stdout'),'stderr_sha256':sha(out/f'shard{i}.stderr')})
        print(json.dumps({'shard':i,'returncode':code}),flush=True)
    need(before==source_pins(),'all arithmetic sources unchanged through parallel replays')
    result={'status':'FOUR_CENTRAL_COVER_REPLAYS_COMPLETED'if all(r['returncode']==0 for r in results)else'CENTRAL_COVER_REPLAYS_HAVE_FAILURES',
      'results':results,'seconds':time.time()-started,'scope':'Actual shard replay observations; complete collect_cover_replays admission still required.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    if any(r['returncode']for r in results):raise SystemExit(1)
if __name__=='__main__':main()
