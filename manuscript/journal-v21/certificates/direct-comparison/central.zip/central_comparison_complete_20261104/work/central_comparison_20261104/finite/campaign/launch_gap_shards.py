"""Launch exactly four disjoint fixed gap shards; no whole-result promotion."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;WORKSPACE=HERE.parents[3]
sys.path.insert(0,str(HERE))
from inputs import PAIRS,need
from partition import SHARD_ROWS,SHARD_WEIGHTS
import gap_campaign as reader
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
    return reader.pins()|{name:sha(HERE/name)for name in ['gap_shard_worker.py','launch_gap_shards.py','collect_gaps.py','bind_complete_gaps.py']}
def main():
    need(__debug__ and not sys.flags.optimize,'unoptimized supervisor')
    out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=False);before=sources();started=time.time()
    plan={'schema':'FOUR_FIXED_CENTRAL_GAP_SHARDS_V1','pairs':len(PAIRS),'rows':SHARD_ROWS,'weights':SHARD_WEIGHTS,
      'sources':before,'python':sys.executable,'python_version':sys.version,'started_unix':started}
    (out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n');jobs=[]
    for i in range(4):
        argv=[sys.executable,'-I','-B',str(HERE/'gap_shard_worker.py'),str(out/f'shard{i}'),'--shard',str(i)]
        stdout=(out/f'shard{i}.stdout').open('xb');stderr=(out/f'shard{i}.stderr').open('xb')
        child=subprocess.Popen(argv,cwd=WORKSPACE,stdout=stdout,stderr=stderr)
        jobs.append((i,child,stdout,stderr,argv))
    results=[]
    for i,child,stdout,stderr,argv in jobs:
        code=child.wait();stdout.close();stderr.close()
        results.append({'shard':i,'command':argv,'returncode':code,
          'stdout_sha256':sha(out/f'shard{i}.stdout'),'stderr_sha256':sha(out/f'shard{i}.stderr')})
        print(json.dumps({'shard':i,'returncode':code}),flush=True)
    need(before==sources(),'all gap orchestration/acceptance sources unchanged')
    result={'status':'FOUR_GAP_SHARD_REPLAYS_COMPLETED'if all(r['returncode']==0 for r in results)else'GAP_SHARDS_HAVE_FAILURES',
      'results':results,'sources_unchanged':True,'seconds':time.time()-started,
      'scope':'Actual shard observations only; collect_gaps must verify complete source/output-bound union before binding.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    if any(r['returncode']for r in results):raise SystemExit(1)
if __name__=='__main__':main()
