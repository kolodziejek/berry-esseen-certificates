"""Preserve the reviewed analytic integration draft, without proof promotion."""
from pathlib import Path
import argparse, hashlib, json, sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('output')
    args = ap.parse_args()
    if not __debug__ or sys.flags.optimize:
        raise ValueError('unoptimized staging required')
    portable = Path(args.portable).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    target = portable / 'proofs/integration-draft04'
    target.mkdir(parents=True, exist_ok=False)
    src = WORKSPACE / 'work/direct_comparison_integration_20261104'
    run = WORKSPACE / 'runs/direct_comparison_integration_20261104/draft04'
    process = json.loads((run / 'PROCESS.json').read_text())
    if type(process['returncode']) is not int or process['returncode'] != 0 or process['sources_unchanged'] is not True:
        raise ValueError('expected completed source-stable draft compile')
    mapping = [(src / name, name) for name in ('main.tex', 'direct_comparison.tex')]
    mapping += [(run / name, name) for name in ('PROCESS.json', 'stdout.txt', 'stderr.txt')]
    mapping += [(run / 'build' / name, name) for name in ('main.pdf', 'main.log')]
    records = []
    for source, name in mapping:
        if not source.is_file() or source.is_symlink():
            raise ValueError('ordinary reviewed draft source required')
        pin = sha(source)
        if source.suffix == '.tex':
            if process['source_before'][str(source)] != pin or process['source_after'][str(source)] != pin:
                raise ValueError('current source differs from selected draft compile')
        dest = target / name
        with dest.open('xb') as f:
            f.write(source.read_bytes())
        if sha(dest) != pin or sha(source) != pin:
            raise ValueError('draft bytes changed while copying')
        records.append({'path': str(dest.relative_to(portable)), 'source': str(source.relative_to(WORKSPACE)),
                        'bytes': dest.stat().st_size, 'sha256': pin})
    result = {'status': 'REVIEWED_ANALYTIC_DRAFT_PRESERVED_WITH_PENDING_NUMERICS',
              'files': records, 'stager_sha256': sha(Path(__file__)),
              'scope': 'Generic finite direct-comparison proof and central scalar/index specialization. The draft itself retains its pending central/earlier numerical assertions and is not promoted as a completed manuscript.',
              'compile_scope': 'Selected standalone two-file TeX input closure plus actual broader workspace source-pin record; unrelated manuscript files in that historical record are not bundled here.',
              'no_new_layout_claim': True}
    (target / 'STATUS.json').write_text(json.dumps(result, indent=2) + '\n')
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'files': len(records), 'status_sha256': sha(target/'STATUS.json')}))


if __name__ == '__main__':
    main()
