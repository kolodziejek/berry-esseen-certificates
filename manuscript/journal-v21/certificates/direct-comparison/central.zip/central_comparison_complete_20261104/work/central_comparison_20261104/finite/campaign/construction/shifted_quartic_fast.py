"""Exact cached tensor Bernstein transform; all gate construction stays unchanged.

By tensor linearity, B[p^i*u^j] is the outer product of the univariate
degree-elevated monomial coefficients. Caches are bounded and immutable.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
from functools import lru_cache
import hashlib
import shifted_quartic_gate as slow
EXPECTED=Path(__file__).with_name('shifted_quartic_gate.py').resolve()
SLOW_PIN='20ffba75c8692132fb377f9aa9643acdb5e78aecf0b0a1522b8fba830d79716e'
slow.need(Path(slow.__file__).resolve()==EXPECTED and hashlib.sha256(EXPECTED.read_bytes()).hexdigest()==SLOW_PIN,'fixed original shifted kernel')
need=slow.need;affine_gates=slow.affine_gates;gates=slow.gates;bracket_gates=slow.bracket_gates
evaluate=slow.evaluate;add=slow.add;scale=slow.scale;lift=slow.lift;direct_loss=slow.direct_loss

@lru_cache(maxsize=256)
def _monomial_basis(a,b,degree):
    """Row e contains all degree-D Bernstein coefficients of x^e on[a,b]."""
    width=b-a
    return tuple(tuple(sum(F(comb(e,j))*a**(e-j)*width**j*F(comb(k,j),comb(degree,j))
      for j in range(min(e,k)+1))for k in range(degree+1))for e in range(degree+1))

@lru_cache(maxsize=512)
def _transform(terms,pl,pu,ul,uh,dp,du):
    BP=_monomial_basis(pl,pu,dp);BU=_monomial_basis(ul,uh,du)
    out=[[F(0)for _ in range(du+1)]for _ in range(dp+1)]
    for i,j,c in terms:
        left=BP[i];right=BU[j]
        for a in range(dp+1):
            factor=c*left[a]
            if factor:
                for b in range(du+1):
                    if right[b]:out[a][b]+=factor*right[b]
    return tuple(tuple(row)for row in out)

def bernstein(poly,pl,pu,ul,uh,degree=(6,4)):
    pl,pu,ul,uh=map(F,(pl,pu,ul,uh));dp,du=degree
    need(pl<pu and ul<=uh and type(dp)is int and type(du)is int and dp>=0 and du>=0,'tensor rectangle and degrees')
    need(all(type(i)is int and type(j)is int and 0<=i<=dp and 0<=j<=du for i,j in poly),'power tensor degree')
    terms=tuple(sorted((i,j,F(value))for(i,j),value in poly.items()if F(value)!=0))
    return _transform(terms,pl,pu,ul,uh,dp,du)

def bernstein_affine(record,pl,pu,ul,uh):
    return {'constant':bernstein(record['constant'],pl,pu,ul,uh),
            'linear':tuple(bernstein(z,pl,pu,ul,uh)for z in record['linear'])}

def clear_caches():
    _transform.cache_clear();_monomial_basis.cache_clear()
def cache_info():
    return {'monomial_bases':_monomial_basis.cache_info()._asdict(),'whole_transforms':_transform.cache_info()._asdict()}
