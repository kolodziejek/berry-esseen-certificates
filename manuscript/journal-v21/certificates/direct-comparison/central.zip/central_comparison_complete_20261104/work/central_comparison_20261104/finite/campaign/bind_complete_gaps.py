"""Bind a completed whole finite-gap replay; no target or arithmetic changes."""
from pathlib import Path
import argparse,hashlib,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from inputs import PAIRS,PAIR_SET,need
import gap_campaign as reader
from collect_gaps import validate_complete
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('run');a=p.parse_args()
    run=Path(a.run).resolve();process=json.loads((run/'PROCESS.json').read_text())
    need(type(process['returncode'])is int and process['returncode']==0 and process['inputs_unchanged']is True,'completed unchanged exact gap run')
    for name in ('stdout','stderr'):need(sha(run/(name+'.txt'))==process[name+'_sha256'],'actual stream identity')
    result=run/'accepted/RESULT.json';proof=run/'accepted/proof_object.json'
    obj=reader.strict_json(result.read_text());validate_complete(reader.strict_json(proof.read_text()))
    summary=reader.strict_json((run/'stdout.txt').read_text().splitlines()[-1])
    need(summary['result_sha256']==sha(result)and summary['proof_sha256']==sha(proof),'actual union output bytes bound to captured stdout')
    need(obj['status']=='PASS_EXACT_CENTRAL_ALL45_FINITE_BERNOULLI_GAPS'and obj['row_n_pairs']==len(PAIRS),'whole finite gap acceptance')
    need(len(obj['gaps'])==len(PAIRS)and {(r['row'],r['n'])for r in obj['gaps']}==PAIR_SET,'exact finite gap key cover')
    need(obj['sources']==reader.pins(),'same completed gap sources')
    target=HERE/'native/gaps_campaign.json';need(not target.exists(),'create-only complete gap data')
    pin=sha(result);target.write_bytes(result.read_bytes());need(sha(target)==pin,'copied exact gap result')
    enclosure=HERE/'root/enclosures.py';before=sha(enclosure);text=enclosure.read_text()
    marker='PENDING_FRESH_COMPLETE_CENTRAL_GAPS';need(text.count(marker)==1,'single pending data pin')
    enclosure.write_text(text.replace(marker,pin))
    receipt={'schema':'COMPLETE_CENTRAL_FINITE_GAP_BINDING_V1','run':str(run),'process_sha256':sha(run/'PROCESS.json'),
      'proof_sha256':sha(proof),'gap_sha256':pin,'enclosure_before':before,'enclosure_after':sha(enclosure),
      'change':'Only pending gap hash literal replaced. Sources used by completed gap replay unchanged; no prior pilot data promoted.'}
    (HERE/'GAP_BINDING.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
