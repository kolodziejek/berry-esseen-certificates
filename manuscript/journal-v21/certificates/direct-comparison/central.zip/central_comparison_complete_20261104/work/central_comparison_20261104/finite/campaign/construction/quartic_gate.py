"""Exact sixteen-corner quartic CP loss gates, cleared by (n*p*(1-p))^2.

The p interval stays continuous. No candidate polynomial or sampled value
is trusted as a positivity certificate. Analytic premises are in API.md.
"""
from fractions import Fraction as F
from math import comb
import sys
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized Python required')
def need(x,s):
    if not x:raise ValueError(s)
def trim(p):
    p=list(map(F,p))
    while len(p)>1 and p[-1]==0:p.pop()
    return tuple(p or[F(0)])
def add(*polys):
    out=[F(0)]*max((len(p)for p in polys),default=1)
    for p in polys:
        for i,z in enumerate(p):out[i]+=z
    return trim(out)
def scale(p,z):return trim([F(z)*x for x in p])
def mul(a,b):
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return trim(out)
def evaluate(p,x):
    x=F(x);out=F(0)
    for a in reversed(p):out=out*x+a
    return out
P=(F(0),F(1));Q=(F(1),F(-1));V=mul(P,Q);V2=mul(V,V);P2=mul(P,P);Q2=mul(Q,Q)
ONE_MINUS_TWO_V=add((F(1),),scale(V,-2))

def _domain(n,k,pl,pu,L,U,A0,A1,d0,cgain,blo,bhi):
    need(type(n)is int and type(k)is int and n>0 and 0<=k<=n,'actual integer n/count')
    need(0<F(pl)<F(pu)<F(1,2)and 0<=F(L)<=F(U),'closed continuous p/noise cell')
    need(F(A0)>0 and F(A1)>0 and 0<=F(d0)<1,'coarse signed endpoint domains')
    need(F(cgain)>=0 and 0<F(blo)<=F(bhi),'nonnegative gain price and positive mass')

def _parts(n,k,lam,alpha,gamma,b,A0,A1,gap,phase,varcoef,cgain):
    """Return q-independent polynomial and five affine q coefficients."""
    lam,gamma,b,A0,A1,gap,phase,varcoef,cgain=map(F,(lam,gamma,b,A0,A1,gap,phase,varcoef,cgain))
    G=add(scale(P,3),(-gamma,))if alpha==0 else add(scale(Q,3),(gamma,))
    base=scale(V2,n*n*(gap+phase+varcoef*lam))
    gain1=scale(mul(V2,add(G,scale(ONE_MINUS_TWO_V,-F(3,2)))),cgain*lam*n)
    gain2=scale(mul(V,ONE_MINUS_TWO_V),-cgain*F(3,8)*lam*lam)
    constant=add(base,gain1,gain2)
    # (n v)^2*lambda*V_alpha and (n v)^2*lambda^2*V_alpha^2.
    classcount=n-k if alpha==0 else k
    linear_moment=scale(mul(P2,Q)if alpha==0 else mul(P,Q2),lam*classcount*n)
    quadratic_moment=scale(P2 if alpha==0 else Q2,lam*lam*classcount*classcount)
    q0=scale(V2,-b*n*n);q1=(F(0),);q2=scale(linear_moment,-b)
    q3=scale(linear_moment,-b*gamma)
    q4=add(scale(linear_moment,-b*(A0*A1+(A1-A0)*gamma)),scale(quadratic_moment,-3*b))
    return constant,(q0,q1,q2,q3,q4)

def affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi):
    """Sixteen records: constant + sum(q[j]*linear[j]), each a power-p poly."""
    _domain(n,k,pl,pu,L,U,A0,A1,d0,cgain,blo,bhi)
    A0,A1,d0=map(F,(A0,A1,d0));out=[]
    for lam in map(F,(L,U)):
      for b in map(F,(blo,bhi)):
       for alpha,gamma in ((0,-A0),(0,d0),(1,-d0),(1,A1)):
        const,linear=_parts(n,k,lam,alpha,gamma,b,A0,A1,gap,phase,varcoef,cgain)
        out.append({'lambda':lam,'mass':b,'alpha':alpha,'gamma':gamma,'constant':const,'linear':linear})
    need(len(out)==16,'complete endpoint product');return out

def gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi,q):
    """Return sixteen exact power-p polynomials. Positivity licenses the loss.

    q is the five coefficients in powers of W, and q4 must be nonnegative.
    The caller checks bracket_gates as well as all-real q>=payoff separately.
    """
    q=tuple(map(F,q));need(len(q)==5 and q[4]>=0,'quartic nonnegative leading coefficient')
    records=affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi)
    return[add(z['constant'],*(scale(p,a)for p,a in zip(z['linear'],q)))for z in records]

def bracket_gates(n,pl,pu,L,U,A0,A1,d0):
    """Eight cubic-price bracket gates cleared by n*v>0, all moment/noise endpoints."""
    _domain(n,0,pl,pu,L,U,A0,A1,d0,0,1,1)
    A0,A1,d0=map(F,(A0,A1,d0));out=[]
    for lam in map(F,(L,U)):
      for alpha,gamma in ((0,-A0),(0,d0),(1,-d0),(1,A1)):
        G=add(scale(P,3),(-gamma,))if alpha==0 else add(scale(Q,3),(gamma,))
        out.append(add(scale(mul(V,add(G,scale(ONE_MINUS_TWO_V,-F(3,2)))),n),scale(ONE_MINUS_TWO_V,-F(3,8)*lam)))
    return out

def bernstein(poly,pl,pu,degree=6):
    """Exact coefficients on closed p=[pl,pu], degree-elevated if necessary."""
    poly=trim(poly);pl,pu=F(pl),F(pu)
    need(pl<pu and type(degree)is int and degree>=len(poly)-1,'Bernstein interval/degree')
    affine=[sum(poly[j]*comb(j,i)*pl**(j-i)*(pu-pl)**i for j in range(i,len(poly)))for i in range(len(poly))]
    return tuple(sum(affine[i]*F(comb(k,i),comb(degree,i))for i in range(min(k,len(affine)-1)+1))for k in range(degree+1))

def direct_loss(n,k,p,lam,A0,A1,gap,phase,varcoef,cgain,b,q,alpha,gamma):
    """Independent rational formula for bounded constructor controls, no clearing."""
    p,lam,A0,A1,gap,phase,varcoef,cgain,b,gamma=map(F,(p,lam,A0,A1,gap,phase,varcoef,cgain,b,gamma))
    q=tuple(map(F,q));v=p*(1-p);V_alpha=F(n-k,n)/(1-p)if alpha==0 else F(k,n)/p
    G=3*p-gamma if alpha==0 else 3*(1-p)+gamma
    cubic=cgain*lam/n*(G-F(3,2)*(1-2*v)-3*(1-2*v)*lam/(8*n*v))
    t=lam*V_alpha;S3=t*gamma
    Eq=q[0]+q[2]*t+q[3]*S3+q[4]*(A0*A1*t+(A1-A0)*S3+3*t*t)
    return gap+phase+varcoef*lam+cubic-b*Eq
