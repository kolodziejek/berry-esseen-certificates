"""Exact scalar enclosures for finite central cells; discovery never weakens gates."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,comb
from functools import lru_cache
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from inputs import PAIRS,PINS as INPUT_PINS,ROWS as INPUT_ROWS
RAW=ROOT/'native/central.json'
GAPS=ROOT/'native/gaps_campaign.json'
RAW_PIN=INPUT_PINS['central.json']
GAP_PIN='8d948583007948008c07885d366abb723eb3769f8aa05af3ce62f8f917fdf709'
SIGMA_LO=F(3162277660,10**9);KAPPA=F(997,15000);PHILO=F('.39886');PHIHI=F('.4');CELO=F('.4095')
def need(x,m):
    if not x:raise ValueError(m)
def lo(x,scale=10**10):return F(x.numerator*scale//x.denominator,scale)
def hi(x,scale=10**10):return F(x.numerator*scale//x.denominator+1,scale)
def sqrtlo(x):
    need(x>=0,'nonnegative square root');return F(isqrt(x.numerator*10**24//x.denominator),10**12)
def sqrthi(x):return sqrtlo(x)+F(1,10**12)
need(not sys.flags.optimize and __debug__,'unoptimized exact enclosures')
need(SIGMA_LO*SIGMA_LO<10 and PHILO/6>KAPPA and (3+SIGMA_LO)*PHILO/6>CELO,'strict scalar constant directions')
need(hashlib.sha256(RAW.read_bytes()).hexdigest()==RAW_PIN,'fixed raw input')
ROWS=json.loads(RAW.read_text())['panels']
need(hashlib.sha256(GAPS.read_bytes()).hexdigest()==GAP_PIN,'fixed freshly checked finite binomial gaps')
GAPDATA=json.loads(GAPS.read_text());GAPMAP={(r['row'],r['n']):r for r in GAPDATA['gaps']}
need(GAPDATA['row_n_pairs']==len(PAIRS) and len(GAPDATA['gaps'])==len(GAPMAP)==len(PAIRS) and set(GAPMAP)==set(PAIRS),'exact complete finite central census')
need(GAPDATA['status']=='PASS_EXACT_CENTRAL_ALL45_FINITE_BERNOULLI_GAPS','fresh central gap result')

def p0_lower(pl,pu):
    sigma_hi=F(3162277661,10**9)
    need(SIGMA_LO**2<10<sigma_hi**2,'directed critical probability enclosure')
    critical_lo=(4-sigma_hi)/2;critical_hi=(4-SIGMA_LO)/2
    distance=max(F(0),critical_lo-pu,pl-critical_hi)
    return lo((6+2*SIGMA_LO)*distance**2/sqrthi(pu*(1-pu)))
def qmax(q,a,b,sign):
    A=F(q['A']);linear=F(q['Fplus'if sign>0 else'Fminus']);quad=F(q['Qbudget'])
    need(quad>0 and 0<=a<=b,'concave quadratic domain')
    v=max(a,min(b,linear/(2*quad)));return A+linear*v-quad*v*v
def resource(index,n,k,pl,pu,ul,uh):
    row=ROWS[index];vl=pl*(1-pl);vh=pu*(1-pu)
    P0=p0_lower(pl,pu);b=min(3*(SIGMA_LO+1)*F(row['B_lo']),3*(SIGMA_LO+3)*F(row['A_lo']))
    beta=lo(b-F(3,2)*P0);need(beta>0,'positive noise price')
    cap=F(row['lambda_max']);rlo=k+ul-n*pu;rhi=k+uh-n*pl
    theta=F(row['theta']);d0=F(row['d0'])
    need(0<=theta<1 and 0<=d0<1,'inward resource domains')
    inward=lo(6*(1-theta)*sqrtlo((1-theta)/vh)*(1-d0))
    need(inward>0,'positive inward defect price')
    for iteration in range(16):
        wl=vl;wh=vh+cap/n;swl=sqrtlo(wl);swh=sqrthi(wh)
        Hlo=rlo/(swh if rlo>=0 else swl);Hhi=rhi/(swl if rhi>=0 else swh)
        Hlo=max(Hlo,-F(row['H_minus']));Hhi=min(Hhi,F(row['H_plus']))
        if Hlo>Hhi:return {'excluded':'signed_H'}
        maxima=[]
        if Hhi>=0:
            maxima.extend(qmax(q,max(0,Hlo),Hhi,1)for q in row['quadratics'])
        if Hlo<=0:
            maxima.extend(qmax(q,max(0,-Hhi),-Hlo,-1)for q in row['quadratics'])
        B=min(F(row['T']),max(maxima))
        if P0>0 and KAPPA*n*P0>=B:return {'excluded':'strict_resource','margin':str(KAPPA*n*P0-B)}
        budget=min(47*F(row['D']),B/KAPPA);E=budget-n*P0
        if E<0:return {'excluded':'weighted_defect','margin':str(-E)}
        need(beta*n-E>0,'positive noise denominator')
        A0=A1=F(11,20)
        M=hi(max((1-pl)*A0,pu*A1))
        need(A0>0 and A1>0 and M>0,'positive early-strip variance/support price')
        # s <= q*A0*a0+p*A1*a1 <= M*(a0+a1).
        price=inward/M+beta*n/(n*vh+cap)
        need(price>0,'positive combined inward/noise price')
        new=min(cap,hi(E*n*vh/(beta*n-E)),hi(E/price))
        if new==cap:break
        cap=new
    return {'U':cap,'P0':P0,'beta':beta,'inward_price':inward,'iterations':iteration+1}

@lru_cache(maxsize=20000)
def binomial(n,k,pl,pu):
    def mass(p):return F(comb(n,k))*p**k*(1-p)**(n-k)
    a,b=mass(pl),mass(pu);peak=mass(max(pl,min(pu,F(k,n))))
    blo=lo(sqrtlo(F(n))*min(a,b));bhi=hi(sqrthi(F(n))*max(a,b,peak))
    ratio=F(1);R0=F(0)
    for j in range(k+1,n+1):
        ratio*=F(n-j+1,j)*pu/(1-pu);R0=max(R0,ratio)
    return blo,bhi,hi(R0)

def parameters(index,n,k,pl,pu,ul,uh):
    need(0<pl<=pu<F(1,2) and -F(1,2)<=ul<=uh<=F(1,2),'closed cell')
    need(uh<=0 or ul>=0,'phase sign split')
    row=ROWS[index];rpl,rpu=map(F,row['p']);need(rpl<=pl<=pu<=rpu,'source probability subcell')
    gd=GAPMAP[index,n];gr=next(r for r in gd['rows']if r['k']==k)
    res=resource(index,n,k,pl,pu,ul,uh)
    if 'excluded'in res:return res
    U=res['U'];L=F(0);vl=pl*(1-pl);vh=pu*(1-pu);wl=vl;wh=vh+U/n
    swl=sqrtlo(wl);swh=sqrthi(wh);svl=sqrtlo(vl)
    A0=A1=F(11,20);d0=F(row['d0']);c=1-d0
    need(A0>0 and A1>0 and A0>=d0 and A1>=d0 and 0<=d0<min(pl,F(1,2)),'coarse support and inward domains')
    delta_lo=k-n*pu;delta_hi=k-n*pl
    maxarg=max(abs(delta_lo),abs(delta_hi),abs(delta_lo+ul),abs(delta_hi+uh))
    phimin=lo(PHILO*(1-maxarg*maxarg/(2*n*wl)))
    need(phimin>0,'Gaussian phase lower density')
    phase=lo(phimin*ul/swh)if ul>=0 else lo(PHIHI*ul/swl)
    if delta_hi<0:
        mx=max(abs(delta_lo),abs(delta_hi));pm=PHILO*(1-mx*mx/(2*n*vl));need(pm>0,'variance density lower')
        varcoef=lo(pm*(-delta_hi)/(2*n*wh*swh))
    else:varcoef=lo(-PHIHI*max(0,delta_hi)/(2*n*vl*svl))
    cgain=lo(CELO/(wh*swh));blo,bhi,R0=binomial(n,k,pl,pu)
    # G=min(3p-d0,3q-d0); the first is smaller on this left range.
    bracket=3*pl-d0-F(3,2)*(1-2*vl)-3*(1-2*vl)*U/(8*n*vl)
    need(bracket>0,'nonnegative cubic-gain bracket on whole moment box')
    return {'n':n,'k':k,'pl':pl,'pu':pu,'L':L,'U':U,'A0':A0,'A1':A1,'d0':d0,
            'gap':F(gr['rhoB_epsilon']),'phase':phase,'varcoef':varcoef,'cgain':cgain,
            'blo':blo,'bhi':bhi,'c':c,'R0':R0,'ul':ul,'uh':uh,
            'bracket_lower':bracket,'resource':res}

def encode(d):
    if isinstance(d,F):return str(d)
    if isinstance(d,dict):return {k:encode(v)for k,v in d.items()}
    if isinstance(d,list):return list(map(encode,d))
    return d
