"""Fresh exact replay of one fixed complete finite central cover shard."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from inputs import need
from partition import SHARD_PAIRS
from complete_campaign import strict_json,source_pins as common_pins
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source_pins():
    out=common_pins()
    for name in ('replay_cover_shard.py','partition.py'):
        path=HERE/name;out[name]={'bytes':path.stat().st_size,'sha256':sha(path)}
    return out
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--shard',type=int,choices=range(4),required=True);a=p.parse_args()
    src=Path(a.input).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
    need(src.is_dir()and not src.is_symlink(),'ordinary selected object root')
    before=source_pins();start=time.monotonic();records={}
    for path in sorted(src.glob('pair_*.json')):
        need(path.is_file()and not path.is_symlink(),'ordinary proof object')
        obj=strict_json(path.read_text());need(type(obj)is dict and type(obj.get('row'))is int and type(obj.get('n'))is int,'strict candidate identity')
        key=(obj['row'],obj['n']);need(key not in records,'unique candidate pair');records[key]=(path,obj,sha(path))
    need(set(records)==set(SHARD_PAIRS[a.shard]),'exact external complete shard domain')
    spec=importlib.util.spec_from_file_location('native_complete_central_shard',HERE/'root/cover_central.py')
    cover=importlib.util.module_from_spec(spec);spec.loader.exec_module(cover)
    results=[]
    for key in SHARD_PAIRS[a.shard]:
        path,obj,pin=records[key];need(sha(path)==pin,'unchanged proof before readback')
        result=cover.accept_pair(obj);need((result['row'],result['n'])==key,'accepted same pair')
        results.append(result)
        if len(results)%100==0:print(json.dumps({'shard':a.shard,'accepted':len(results),'total':len(records)}),flush=True)
    need(before==source_pins(),'unchanged full acceptance source closure')
    need(all(sha(path)==pin for path,obj,pin in records.values()),'unchanged complete candidate set')
    result={'status':'PASS_EXACT_CENTRAL_FINITE_COVER_SHARD','shard':a.shard,'pairs':len(results),'results':results,
      'input_root':str(src),'inputs':{'%d,%d'%key:{'path':str(path),'sha256':pin}for key,(path,obj,pin)in records.items()},
      'sources':before,'seconds':time.monotonic()-start,'python':sys.version,
      'scope':'One fixed complete acquired finite central shard; all native per-pair gates replayed, whole four-shard union remains separate.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'shard':a.shard,'pairs':len(results),'result_sha256':sha(out/'RESULT.json')}),flush=True)
if __name__=='__main__':main()
