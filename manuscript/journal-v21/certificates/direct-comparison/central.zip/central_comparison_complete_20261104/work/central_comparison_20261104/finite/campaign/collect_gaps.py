"""Join four fully replayed gap shards with actual source/output-bound captures."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from inputs import PAIRS,PAIR_SET,need
from partition import SHARD_PAIRS
import gap_campaign as reader
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(text):return reader.strict_json(text)
def validate_complete(obj):
    need(type(obj)is dict and set(obj)=={'schema','sources','shards'},'complete gap object fields')
    need(obj['schema']=='COMPLETE_CENTRAL_FINITE_GAP_SHARD_UNION_V1'and obj['sources']==reader.pins(),'fixed complete gap union')
    need(type(obj['shards'])is list and len(obj['shards'])==4,'all four gap objects')
    for i,shard in enumerate(obj['shards']):reader.validate(shard,i)
def read_shard(run,index):
    need(run.is_dir()and not run.is_symlink(),'ordinary completed shard root')
    files=[run/'STARTED.json',run/'PROCESS.json',run/'stdout.txt',run/'stderr.txt',run/'accepted/RESULT.json',run/'accepted/proof_object.json']
    need(all(p.is_file()and not p.is_symlink()for p in files),'complete ordinary accepted capture')
    pins={str(p):sha(p)for p in files}
    started,process=map(lambda p:strict(p.read_text()),files[:2])
    need(type(process['returncode'])is int and process['returncode']==0 and process['inputs_unchanged']is True,'successful unchanged actual shard replay')
    for name in ('stdout','stderr'):need(sha(run/(name+'.txt'))==process[name+'_sha256'],'actual stream binding')
    argv=started['command']
    need(argv[1:5]==['-I','-B',str(HERE/'gap_campaign.py'),'accept'],'exact accepted gap entrypoint')
    need(len(argv)==10 and Path(argv[5]).resolve()==run/'accepted'and argv[6]=='--object'and argv[8:] == ['--shard',str(index)],'exact shard/output command')
    proposed=Path(argv[7]).resolve()
    need(started['inputs'].get(str(proposed))==sha(proposed),'actual accepted candidate input')
    for name,pin in reader.pins().items():
        need(started['inputs'].get(str((HERE/name).resolve()))==pin,'complete actual acceptance source input '+name)
    proof=strict(files[-1].read_text());reader.validate(proof,index)
    need(sha(files[-1])==sha(proposed),'accepted output retains exact candidate object')
    summary=strict((run/'stdout.txt').read_text().splitlines()[-1])
    need(summary['result_sha256']==sha(files[-2])and summary['proof_sha256']==sha(files[-1]),'actual stdout binds complete output bytes')
    result=strict(files[-2].read_text())
    need(result['status']=='PASS_EXACT_CENTRAL_FINITE_BERNOULLI_GAP_SHARD'and type(result['shard'])is int and result['shard']==index,'same completed shard')
    need(type(result['row_n_pairs'])is int and result['row_n_pairs']==len(SHARD_PAIRS[index])and result['sources']==reader.pins(),'same complete shard source/census')
    need(len(result['gaps'])==len(SHARD_PAIRS[index]),'complete output gap rows')
    for r,d,key in zip(result['gaps'],proof['pairs'],SHARD_PAIRS[index]):
        need(type(r['row'])is int and type(r['n'])is int and (r['row'],r['n'])==key,'same ordered row/index')
        need(r['p']==d['p']and r['count_cover']==d['counts']and r['subdivisions']==d['subdivisions'],'full accepted domain retained')
        need([z['k']for z in r['rows']]==d['counts'],'all output counts')
        need(all(F(z['epsilon'])>=reader.TARGET for z in r['rows']),'fixed positive gap target')
    need(pins=={str(p):sha(p)for p in files},'completed shard bytes unchanged during join')
    return proof,result,{'run':str(run),'files':pins,'actual_returncode':0,'output_bound_in_stdout':True}
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',action='append',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    need(len(a.input)==4,'four ordered external shard roots')
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);before=reader.pins()
    proofs=[];combined={};receipts=[]
    for i,name in enumerate(a.input):
        proof,result,receipt=read_shard(Path(name).resolve(),i);proofs.append(proof);receipts.append(receipt)
        for r in result['gaps']:
            key=(r['row'],r['n']);need(key not in combined,'disjoint complete shard ownership');combined[key]=r
    need(set(combined)==PAIR_SET,'complete full finite gap union')
    rows=[combined[key]for key in PAIRS]
    obj={'schema':'COMPLETE_CENTRAL_FINITE_GAP_SHARD_UNION_V1','sources':before,'shards':proofs};validate_complete(obj)
    need(before==reader.pins(),'all gap sources unchanged during join')
    result={'status':'PASS_EXACT_CENTRAL_ALL45_FINITE_BERNOULLI_GAPS','row_n_pairs':len(PAIRS),
      'count_pairs':sum(len(r['rows'])for r in rows),'closed_branch_cells':sum(2*r['subdivisions']*len(r['rows'])for r in rows),
      'minimum_epsilon':str(min(F(z['epsilon'])for r in rows for z in r['rows'])),
      'gaps':rows,'sources':before,'accepted_shards':receipts,
      'scope':'Complete finite central binary gaps from four actual exact replays; noisy comparison and n>=1000 remain separate.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');(out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'row_n_pairs':len(PAIRS),'minimum_epsilon':result['minimum_epsilon'],
      'result_sha256':sha(out/'RESULT.json'),'proof_sha256':sha(out/'proof_object.json')}),flush=True)
if __name__=='__main__':main()
