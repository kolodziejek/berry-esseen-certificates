"""Exact inward-support quartic gates; six moment corners, two noise/mass ends.

The previous sixteen-gate implementation is retained unchanged. This
module changes the fourth-moment price to gamma^2 at each support corner.
The two zero-inward corners are included conservatively; they may be
redundant by a further concavity argument.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import quartic_gate as base
EXPECTED=Path(__file__).with_name('quartic_gate.py').resolve()
BASE_PIN='b34522389c8e2bf745b70cd4907a021b96e60cd64a14e9b6cadd7951a0207858'
base.need(Path(base.__file__).resolve()==EXPECTED and hashlib.sha256(EXPECTED.read_bytes()).hexdigest()==BASE_PIN,'fixed univariate algebra dependency')
need=base.need;trim=base.trim;add=base.add;scale=base.scale;mul=base.mul;evaluate=base.evaluate;bernstein=base.bernstein
P,Q,V,V2,P2,Q2=base.P,base.Q,base.V,base.V2,base.P2,base.Q2

def _domain(n,k,pl,pu,L,U,A0,A1,d0,cgain,blo,bhi):
    base._domain(n,k,pl,pu,L,U,A0,A1,d0,cgain,blo,bhi)
    need(F(A0)>=F(d0)and F(A1)>=F(d0)and F(d0)<F(pl),'global support contains both inward endpoints and signs remain fixed')

def moment_corners(A0,A1,d0):
    A0,A1,d0=map(F,(A0,A1,d0))
    return((0,-A0,A0*A0),(0,F(0),F(0)),(0,d0,d0*d0),
           (1,A1,A1*A1),(1,F(0),F(0)),(1,-d0,d0*d0))

def _parts(n,k,lam,alpha,gamma,J4,b,A0,A1,gap,phase,varcoef,cgain):
    constant,linear=base._parts(n,k,lam,alpha,gamma,b,A0,A1,gap,phase,varcoef,cgain)
    lam,b,J4=map(F,(lam,b,J4));classcount=n-k if alpha==0 else k
    first=scale(mul(P2,Q)if alpha==0 else mul(P,Q2),lam*classcount*n)
    second=scale(P2 if alpha==0 else Q2,lam*lam*classcount*classcount)
    fourth=add(scale(first,-b*J4),scale(second,-3*b))
    return constant,linear[:4]+(fourth,)

def affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi):
    _domain(n,k,pl,pu,L,U,A0,A1,d0,cgain,blo,bhi);out=[]
    for lam in map(F,(L,U)):
      for b in map(F,(blo,bhi)):
       for alpha,gamma,J4 in moment_corners(A0,A1,d0):
        constant,linear=_parts(n,k,lam,alpha,gamma,J4,b,A0,A1,gap,phase,varcoef,cgain)
        out.append({'lambda':lam,'mass':b,'alpha':alpha,'gamma':gamma,'J4':J4,'constant':constant,'linear':linear})
    need(len(out)==24,'complete twenty-four-gate product');return out

def gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi,q):
    q=tuple(map(F,q));need(len(q)==5 and q[4]>=0,'quartic nonnegative leading coefficient')
    return[add(z['constant'],*(scale(p,a)for p,a in zip(z['linear'],q)))for z in affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi)]

def bracket_gates(n,pl,pu,L,U,A0,A1,d0):
    # The old eight endpoints enclose this smaller signed-moment domain.
    _domain(n,0,pl,pu,L,U,A0,A1,d0,0,1,1)
    return base.bracket_gates(n,pl,pu,L,U,A0,A1,d0)

def direct_loss(n,k,p,lam,A0,A1,gap,phase,varcoef,cgain,b,q,alpha,gamma,J4):
    p,lam,gap,phase,varcoef,cgain,b,gamma,J4=map(F,(p,lam,gap,phase,varcoef,cgain,b,gamma,J4))
    q=tuple(map(F,q));v=p*(1-p);t=lam*(F(n-k,n)/(1-p)if alpha==0 else F(k,n)/p)
    G=3*p-gamma if alpha==0 else 3*(1-p)+gamma
    gain=cgain*lam/n*(G-F(3,2)*(1-2*v)-3*(1-2*v)*lam/(8*n*v))
    return gap+phase+varcoef*lam+gain-b*(q[0]+q[2]*t+q[3]*t*gamma+q[4]*(J4*t+3*t*t))
