"""Fixed deterministic disjoint whole-row partition of the complete domain."""
from inputs import CAPS,PAIRS,need
SHARD_ROWS=[[]for _ in range(4)];SHARD_WEIGHTS=[0]*4
for row in sorted(CAPS,key=lambda x:(-x['pairs'],x['row'])):
    if not row['pairs']:continue
    index=min(range(4),key=lambda j:(SHARD_WEIGHTS[j],j))
    SHARD_ROWS[index].append(row['row']);SHARD_WEIGHTS[index]+=row['pairs']
for rows in SHARD_ROWS:rows.sort()
SHARD_PAIRS=[tuple(pair for pair in PAIRS if pair[0]in rows)for rows in SHARD_ROWS]
need(sum(map(len,SHARD_PAIRS))==len(PAIRS)and len(set(pair for pairs in SHARD_PAIRS for pair in pairs))==len(PAIRS),'exact complete disjoint shard cover')
need(list(map(len,SHARD_PAIRS))==SHARD_WEIGHTS,'exact shard cardinalities')
