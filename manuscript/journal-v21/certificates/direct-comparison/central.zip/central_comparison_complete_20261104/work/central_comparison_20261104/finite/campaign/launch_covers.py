"""Four disjoint whole-row discovery shards; complete readback is separate."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent;WORKSPACE=HERE.parents[3]
sys.path.insert(0,str(HERE))
from inputs import CAPS,PAIRS,need
from complete_campaign import source_pins
CAPTURE=WORKSPACE/'work/certificate_consolidation_20261104/capture_process.py'
CAPTURE_PIN='48e67827d2eaca9f60c8877bc7113ff98a1c5e73bd2f5e69fe12efecbe8d7727'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('output');p.add_argument('--python',required=True);a=p.parse_args()
    need(__debug__ and not sys.flags.optimize,'unoptimized supervisor')
    need(sha(CAPTURE)==CAPTURE_PIN,'reviewed exact capture supervisor')
    child=Path(a.python).resolve();need(child.is_file(),'explicit existing discovery interpreter')
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
    before=source_pins();before['launch_covers.py']={'bytes':Path(__file__).stat().st_size,'sha256':sha(Path(__file__))}
    shards=[[]for _ in range(4)];weights=[0]*4
    for row in sorted(CAPS,key=lambda x:(-x['pairs'],x['row'])):
        if row['pairs']==0:continue
        index=min(range(4),key=lambda j:(weights[j],j))
        shards[index].append(row['row']);weights[index]+=row['pairs']
    for rows in shards:rows.sort()
    need(sum(weights)==len(PAIRS)and sorted(r for rows in shards for r in rows)==[x['row']for x in CAPS if x['pairs']],'complete disjoint row ownership')
    plan={'schema':'CENTRAL_COMPLETE_FINITE_FOUR_SHARD_PLAN_V1','shards':[{'rows':rows,'pairs':weight}for rows,weight in zip(shards,weights)],
          'expected_pairs':len(PAIRS),'sources':before,'capture_driver_sha256':CAPTURE_PIN,
          'discovery_python':str(child),'supervisor_python':sys.executable,'started_unix':time.time()}
    (out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
    jobs=[]
    for i,rows in enumerate(shards):
        run=out/f'shard{i}'
        command=[sys.executable,'-I','-B',str(CAPTURE)]
        for source in before:command+=['--input',str(HERE/source)]
        command += [str(run),'--',str(child),'-I','-B',str(HERE/'root/discover_central.py'),str(run/'objects'),
          '--rows',','.join(map(str,rows)),'--ns','all','--maxdepth','22','--maxnodes','10000']
        stdout=(out/f'shard{i}.wrapper.stdout').open('xb');stderr=(out/f'shard{i}.wrapper.stderr').open('xb')
        process=subprocess.Popen(command,cwd=WORKSPACE,stdout=stdout,stderr=stderr)
        jobs.append((i,process,stdout,stderr,command))
    results=[]
    for i,process,stdout,stderr,command in jobs:
        code=process.wait();stdout.close();stderr.close()
        results.append({'shard':i,'command':command,'returncode':code,
          'stdout_sha256':sha(out/f'shard{i}.wrapper.stdout'),'stderr_sha256':sha(out/f'shard{i}.wrapper.stderr')})
        print(json.dumps({'shard':i,'returncode':code}),flush=True)
    after=source_pins();after['launch_covers.py']={'bytes':Path(__file__).stat().st_size,'sha256':sha(Path(__file__))}
    need(before==after,'construction sources unchanged')
    result={'status':'COMPLETED_DISCOVERY_SHARDS'if all(r['returncode']==0 for r in results)else'DISCOVERY_SHARDS_HAVE_FAILURES',
      'results':results,'sources_unchanged':True,'seconds':time.time()-plan['started_unix'],
      'scope':'Actual construction observations only; full independent complete_campaign replay still required.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    if not all(r['returncode']==0 for r in results):raise SystemExit(1)
if __name__=='__main__':main()
