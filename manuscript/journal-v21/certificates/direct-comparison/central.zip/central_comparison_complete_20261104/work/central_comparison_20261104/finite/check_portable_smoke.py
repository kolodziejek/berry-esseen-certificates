"""Bounded relocated smoke, not a second whole gap arithmetic replay."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(value, message):
    if not value:
        raise ValueError(message)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('portable')
    ap.add_argument('pair')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized smoke')
    portable = Path(args.portable).resolve()
    c = portable / 'work/central_comparison_20261104/finite/campaign'
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    stage = json.loads((portable / 'SOURCE_STAGE.json').read_text())
    for f in stage['files']:
        p = portable / f['path']
        need(p.is_file() and not p.is_symlink() and p.stat().st_size == f['bytes'] and sha(p) == f['sha256'],
             'same staged bytes ' + f['path'])
    sys.path.insert(0, str(c))
    import gap_campaign as gap
    import binomial_gap as core
    for i in range(4):
        gap.validate(gap.strict_json((portable / f'proof_objects/gaps/shard{i}.json').read_text()), i)
    native = json.loads((c / 'native/gaps_campaign.json').read_text())
    target = next(r for r in native['gaps'] if (r['row'], r['n']) == (19, 999))
    recalculated = core.panel(19, 999, target['subdivisions'])
    need(recalculated == target, 'one complete relocated gap panel equals full accepted native table')
    pair = Path(args.pair).resolve()
    before = sha(pair)
    obj = gap.strict_json(pair.read_text())
    need((obj['row'], obj['n']) == (0, 47), 'fixed complete comparison smoke pair')
    spec = importlib.util.spec_from_file_location('portable_cover_smoke', c / 'root/cover_central.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    accepted = module.accept_pair(obj)
    need(sha(pair) == before, 'unchanged smoke object')
    for f in stage['files']:
        need(sha(portable / f['path']) == f['sha256'], 'all portable source bytes unchanged')
    modules = {name: str(Path(mod.__file__).resolve()) for name, mod in list(sys.modules.items())
               if getattr(mod, '__file__', None) and '/central_comparison_20261104/' in str(mod.__file__)}
    for name, path in modules.items():
        if name != '__main__':
            need(Path(path).is_relative_to(portable), 'no original-workspace module import: ' + name)
    result = {'status': 'PASS_BOUNDED_RELOCATED_CENTRAL_SMOKE',
              'source_stage_sha256': sha(portable / 'SOURCE_STAGE.json'),
              'source_bytes_checked': len(stage['files']), 'gap_candidates_validated': 4,
              'gap_arithmetic': {'row': 19, 'n': 999, 'subdivisions': target['subdivisions'],
                                 'same_complete_record': True},
              'comparison': accepted, 'pair_path': str(pair), 'pair_sha256': before,
              'local_imports': modules,
              'scope': 'Full staged byte check, four candidate-domain checks, one complete gap panel and one complete quartic pair only. Not a full relocated gap replay or completed whole finite noisy comparison.'}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'result_sha256': sha(out / 'RESULT.json')}))


if __name__ == '__main__':
    main()
