"""Bounded readback/admission controls; synthetic fixtures are never evidence.

No binomial, Gaussian, Fourier or quartic arithmetic is repeated here.
The four real captured shards are read first. A disposable copy of shard zero
then tests process/output binding and, separately, semantic result predicates.
For semantic tests only, its synthetic stdout/hash is consistently regenerated.
This does not manufacture or replace any real execution observation.
"""
from pathlib import Path
import argparse, copy, hashlib, json, shutil, sys

HERE = Path(__file__).resolve().parent
C = HERE / 'campaign'
sys.path.insert(0, str(C))
import collect_gaps as reader
import gap_campaign


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(value, message):
    if not value:
        raise AssertionError(message)


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('actual')
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized controls')
    actual = Path(args.actual).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    sources = {str(p): sha(p) for p in (
        Path(__file__), C / 'collect_gaps.py', C / 'gap_campaign.py',
        C / 'inputs.py', C / 'partition.py', C / 'binomial_gap.py')}
    real = []
    for index in range(4):
        proof, result, receipt = reader.read_shard(actual / f'shard{index}/accept', index)
        real.append(receipt)
    fixture = out / 'synthetic_fixture'
    shutil.copytree(actual / 'shard0/accept', fixture)
    names = ['STARTED.json', 'PROCESS.json', 'stdout.txt', 'stderr.txt',
             'accepted/RESULT.json', 'accepted/proof_object.json']
    started = json.loads((fixture / 'STARTED.json').read_text())
    started['command'][5] = str(fixture / 'accepted')
    dump(fixture / 'STARTED.json', started)
    reader.read_shard(fixture, 0)
    baseline = {name: (fixture / name).read_bytes() for name in names}
    (out / 'SYNTHETIC_FIXTURE.json').write_text(json.dumps({
        'scope': 'Disposable mutation fixture, NOT an actual execution capture.',
        'source': str(actual / 'shard0/accept'),
        'changes': ['Only STARTED output path relocated for baseline.',
                    'Semantic result mutants regenerate synthetic stdout/PROCESS hashes.'],
        'baseline': {name: hashlib.sha256(data).hexdigest() for name, data in baseline.items()}
    }, indent=2) + '\n')
    changes = out / 'mutants'
    changes.mkdir()
    controls = []

    def restore():
        for name, data in baseline.items():
            (fixture / name).write_bytes(data)

    def reject(name, file, change, rebound=False, missing=False):
        restore()
        target = fixture / file
        if missing:
            target.rename(fixture / 'intentionally_missing.json')
        elif file.endswith('.json'):
            obj = json.loads(target.read_text())
            change(obj)
            dump(target, obj)
        else:
            target.write_bytes(target.read_bytes() + b'\nCORRUPTED\n')
        if rebound:
            summary = json.loads((fixture / 'stdout.txt').read_text().splitlines()[-1])
            summary['result_sha256'] = sha(fixture / 'accepted/RESULT.json')
            summary['proof_sha256'] = sha(fixture / 'accepted/proof_object.json')
            dump(fixture / 'stdout.txt', summary)
            process = json.loads((fixture / 'PROCESS.json').read_text())
            process['stdout_sha256'] = sha(fixture / 'stdout.txt')
            dump(fixture / 'PROCESS.json', process)
        mutated = {part: sha(fixture / part) if (fixture / part).exists() else None for part in names}
        try:
            reader.read_shard(fixture, 0)
        except (AssertionError, ValueError, KeyError, TypeError, FileNotFoundError) as exc:
            controls.append({'name': name, 'rejected': True, 'reason': str(exc),
                             'synthetic_rebinding': rebound, 'files': mutated})
            if not missing:
                (changes / (name + '.mutant')).write_bytes(target.read_bytes())
        else:
            raise AssertionError('Mutation was admitted: ' + name)
        if missing:
            (fixture / 'intentionally_missing.json').rename(target)

    reject('missing_process', 'PROCESS.json', None, missing=True)
    reject('nonzero_returncode', 'PROCESS.json', lambda d: d.update(returncode=1))
    reject('boolean_returncode', 'PROCESS.json', lambda d: d.update(returncode=False))
    reject('changed_inputs', 'PROCESS.json', lambda d: d.update(inputs_unchanged=False))
    reject('corrupt_stdout', 'stdout.txt', None)
    reject('uncaptured_result_change', 'accepted/RESULT.json', lambda d: d.update(row_n_pairs=0))
    reject('wrong_source_input', 'STARTED.json', lambda d: d['inputs'].update({str(C/'inputs.py'): '0'*64}))
    reject('wrong_output_path', 'STARTED.json', lambda d: d['command'].__setitem__(5, str(out/'wrong')))
    reject('wrong_selected_shard', 'STARTED.json', lambda d: d['command'].__setitem__(9, '1'))
    reject('boolean_result_shard', 'accepted/RESULT.json', lambda d: d.update(shard=False), True)
    reject('boolean_pair_count', 'accepted/RESULT.json', lambda d: d.update(row_n_pairs=True), True)
    reject('missing_result_pair', 'accepted/RESULT.json', lambda d: d['gaps'].pop(), True)
    reject('duplicate_result_pair', 'accepted/RESULT.json', lambda d: d['gaps'].__setitem__(1, copy.deepcopy(d['gaps'][0])), True)
    reject('reordered_result_pair', 'accepted/RESULT.json', lambda d: d['gaps'].reverse(), True)
    reject('boolean_result_index', 'accepted/RESULT.json', lambda d: d['gaps'][0].update(n=True), True)
    reject('narrowed_p_domain', 'accepted/RESULT.json', lambda d: d['gaps'][0]['p'].__setitem__(0, '2/5'), True)
    reject('changed_subdivision', 'accepted/RESULT.json', lambda d: d['gaps'][0].update(subdivisions=1), True)
    reject('missing_count', 'accepted/RESULT.json', lambda d: d['gaps'][0]['rows'].pop(), True)
    reject('weakened_target', 'accepted/RESULT.json', lambda d: d['gaps'][0]['rows'][0].update(epsilon='0'), True)
    reject('result_source_type', 'accepted/RESULT.json', lambda d: d.update(sources=[]), True)
    reject('changed_candidate', 'accepted/proof_object.json', lambda d: d['pairs'][0].update(n=48), True)
    restore()
    reader.read_shard(fixture, 0)
    need(sources == {name: sha(Path(name)) for name in sources}, 'unchanged tested source closure')
    for index, receipt in enumerate(real):
        need(receipt == reader.read_shard(actual / f'shard{index}/accept', index)[2],
             'original actual evidence untouched')
    result = {'status': 'PASS_BOUNDED_CENTRAL_GAP_CAPTURE_CONTROLS',
              'actual_shards_read': 4, 'rejections': len(controls), 'controls': controls,
              'actual_evidence': real, 'sources': sources,
              'scope': 'Readback and mutation controls only; no numerical arithmetic replay. Synthetic fixtures never establish a mathematical or execution result.'}
    dump(out / 'RESULT.json', result)
    print(json.dumps({'status': result['status'], 'rejections': len(controls),
                      'result_sha256': sha(out / 'RESULT.json')}))


if __name__ == '__main__':
    main()
