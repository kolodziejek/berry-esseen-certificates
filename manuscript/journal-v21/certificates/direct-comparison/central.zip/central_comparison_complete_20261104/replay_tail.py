"""Portable exact central-tail replay with actual captured child processes.

Place this additive supervisor at the publication-package root. All numerical
readers and the original historical capture wrapper remain byte-for-byte intact.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys, tempfile, time

ROOT = Path(__file__).resolve().parent
TAIL = Path('work/finite_left_replacement_20261104/audit/central_transfer')
PROOF = Path('runs/finite_left_replacement_20261104/audit_central_all45_capture01/accepted/proof_object.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(value, message):
    if not value:
        raise ValueError(message)


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output')
    args = ap.parse_args()
    need(__debug__ and not sys.flags.optimize, 'unoptimized exact replay required')
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    selected = json.loads((ROOT / 'TAIL_STAGE.json').read_text())
    expected = {f['path']: f for f in selected['files']}
    names = [str(TAIL / name) for name in ('accept_all45.py', 'check_all45.py', 'common_envelope.py')]
    names += ['work/finite_left_replacement_20261104/audit/quartic_global.py',
              'work/finite_left_replacement_20261104/audit/native/finite_binomial_core.py',
              'work/below50_20260929/local/conditional_input47.json', str(PROOF)]

    def pins():
        result = {}
        for name in names:
            path = ROOT / name
            need(path.is_file() and not path.is_symlink(), 'ordinary selected tail input')
            pin = {'bytes': path.stat().st_size, 'sha256': sha(path)}
            need(pin == {k: expected[name][k] for k in ('bytes', 'sha256')}, 'frozen tail source/input ' + name)
            result[name] = pin
        result['replay_tail.py'] = {'bytes': Path(__file__).stat().st_size, 'sha256': sha(Path(__file__))}
        result['TAIL_STAGE.json'] = {'bytes': (ROOT/'TAIL_STAGE.json').stat().st_size, 'sha256': sha(ROOT/'TAIL_STAGE.json')}
        return result

    before = pins()
    records = []
    with tempfile.TemporaryDirectory(prefix='central-tail-replay-') as scratch:
        for label, argv in (
            ('acceptance', [sys.executable, '-I', '-B', str(ROOT/TAIL/'accept_all45.py'),
                            str(out/'accepted'), str(ROOT/PROOF)]),
            ('common_envelope', [sys.executable, '-I', '-B', str(ROOT/TAIL/'common_envelope.py'),
                                 str(ROOT/PROOF), str(out/'common')])):
            run = out / label
            run.mkdir(exist_ok=False)
            start = {'command': argv, 'cwd': scratch, 'temporary_cwd': True, 'sources': before,
                     'runtime': {'executable': sys.executable, 'version': sys.version, 'optimized': sys.flags.optimize}}
            dump(run/'STARTED.json', start)
            t = time.monotonic()
            with (run/'stdout.txt').open('xb') as so, (run/'stderr.txt').open('xb') as se:
                child = subprocess.run(argv, cwd=scratch, stdout=so, stderr=se)
            record = {'returncode': child.returncode, 'seconds': time.monotonic()-t,
                      'stdout_sha256': sha(run/'stdout.txt'), 'stderr_sha256': sha(run/'stderr.txt'),
                      'sources_unchanged': pins() == before}
            dump(run/'PROCESS.json', record)
            records.append({'name': label, 'process': record})
            need(type(child.returncode) is int and child.returncode == 0 and record['sources_unchanged'],
                 'successful actual source-stable tail child: ' + label)
    accepted = json.loads((out/'accepted/RESULT.json').read_text())
    common = json.loads((out/'common/RESULT.json').read_text())
    need(accepted['status'] == 'PASS_EXACT_COMPLETE_EARLY_CENTRAL45_N_GE_1000_TAIL'
         and accepted['probability_rows'] == 45 and len(accepted['negative_controls']) == 21,
         'complete unchanged tail acceptance and controls')
    need(common['status'] == 'PASS_ONE_ENVELOPE_FOUR_QUARTICS_CENTRAL_N1000'
         and len(common['quartics']) == 4 and common['final_margin'] == '19847/500000',
         'same four-quartic common envelope')
    need(before == pins(), 'all numerical readers/inputs and supervisor unchanged')
    result = {'status': 'PASS_RELOCATED_COMPLETE_CENTRAL_TAIL', 'rows': 45, 'n_lower': 1000,
              'accepted_result_sha256': sha(out/'accepted/RESULT.json'),
              'common_result_sha256': sha(out/'common/RESULT.json'),
              'proof_sha256': sha(ROOT/PROOF), 'sources': before, 'children': records,
              'scope': 'Fresh exact complete tail acceptance plus21 controls and common four-quartic envelope, using unchanged numerical sources from an additive portable supervisor. The original acquisition/support and analytic n-uniform argument remain explicit mathematical premises.'}
    dump(out/'RESULT.json', result)
    print(json.dumps({'status': result['status'], 'rows': 45, 'n_lower': 1000,
                      'result_sha256': sha(out/'RESULT.json')}))


if __name__ == '__main__':
    main()
