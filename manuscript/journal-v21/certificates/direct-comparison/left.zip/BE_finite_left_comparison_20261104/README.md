# Complete direct comparison for the acquired raw-left branch

This package excludes every law satisfying the stated same-law acquisition
hypotheses and one of the 39 original raw-left rows, for every n>=47. The
finite reduction and comparison are complete: all 3,385 retained row/index
pairs have passed exact acceptance, including a second complete replay from
this portable copy. This is a module of the larger proof. It does not by
itself establish attainment, contact, Fourier inversion, acquisition or the
central and smaller-index branches.

| Mathematical status | Execution status |
| --- | --- |
| Locally derived and checked implication at the explicit same-law acquisition boundary | Fresh complete gap/cap replay, complete 3,385-pair comparison replay and corruption controls passed |

Read `proofs/analytic/finite_left_comparison.tex` or its six-page PDF
`proofs/analytic/finite_left_comparison.pdf` for the mathematical proof.
`gaps/SOUNDNESS.md` supplies the full
binomial-gap and integer-cap derivation; `proofs/SHIFTED_AND_FAST_SOUNDNESS.md`
explains the exact tensor transform. The original raw table is preserved at
`work/below50_20260929/entry/left_input47_table.json`.

## What the certificate proves

The acquisition hypotheses are those of an attained positive closed-event
ratio maximizer with n>=47, C>=CE, n(C-CE)<=.7, predecessor decrement<=.19,
own cap .4247 and both deleted caps .4253. One raw row supplies its probability,
radius3, conditional moments, inward distance, signed phase and weighted
defect/Fourier bounds simultaneously for the same law. These analytic and
acquisition premises are inherited, not inferred from a successful program.

The joint defect restricts each raw probability row to a finite set of
indices; all larger n are excluded by the same inequality. The 39 exact
caps give 3,385 pairs and maximum index326. For each pair, the finite binary
reader checks all licensed nearest counts and both CDF jump sides over
the entire original closed probability interval. Its minimum certified
CE-minus-binary score is `574819469/250000000000 > 1/500`.

For a noisy law, a pathwise count coupling uses one common pair of conditional
marginals. A quartic majorizes its incoming/outgoing staircase on the whole
real line, with strict outgoing and closed incoming events. Support gives
a fourth-moment bound; concavity reduces the moment, noise and mass variables
to 24 corners. The phase stays inside the translated quartic. Exact tensor
Bernstein coefficients then prove the score inequality throughout each
closed probability/phase cell. Resource exclusions and both children of
every subdivision are recomputed. There is no sampling, division by tiny
noise, or fixed-law limiting step in acceptance.

The full cover contains 16,496 count/sign roots, 9,738 quartics, 7,337 resource
exclusions and579 subdivisions, of maximum depth7. It checks8,179,920 score
coefficients and97,380 global interval/ray positivity targets. Zero noise,
phase zero, nearest-count ties and all common cell endpoints are included.

## Reproduce the exact checks

Use unoptimized Python3 with its standard library; never pass `-O` or `-OO`.
The recorded portable replay used CPython3.12.14. NumPy/SciPy are unnecessary
for acceptance. The `work/` and `runs/` subtrees preserve the original relative
layout, so every selected acceptance source remains byte-for-byte unchanged.
They form a self-contained subset, not references to an external workspace.

Run from this directory. Every destination below must be a new absolute path
outside the package. The capture tool preserves command, runtime, source
hashes, streams and actual return code, and rejects package changes.

```bash
python3 -I -B tools/capture.py /fresh/gap-run gaps/accept_gaps.py all '{output}/accepted' gaps/proof_object.json
python3 -I -B tools/capture.py /fresh/gap-controls gaps/controls.py '{output}/accepted'
```

The first command derives every index cap from the raw rows, then recomputes
all3,385 binary bounds,8,248 count pairs and131,968 closed branch subcells.
Its regenerated `accepted/RESULT.json` must have SHA-256
`d6b53cc0f4ec90d48105ea0d59b75819a704285504769ca592252ec1b0ccfce4`.
That is the exact fixed gap input consumed below; `gaps/VERIFIED_GAPS.json`
and the copy under `runs/.../audit_gaps_all02/accepted/` are expected data,
not substitutes for recomputation.

```bash
python3 -I -B tools/capture.py /fresh/comparison-run \
  work/finite_left_replacement_20261104/audit/complete_strong_campaign.py \
  --input runs/finite_left_replacement_20261104/root_strong_shard0_01/objects \
  --input runs/finite_left_replacement_20261104/root_strong_shard1_01/objects \
  --input runs/finite_left_replacement_20261104/root_strong_shard2_01/objects \
  --input runs/finite_left_replacement_20261104/root_strong_shard3_01/objects \
  --discovery-result runs/finite_left_replacement_20261104/root_strong_shard0_01/objects/RESULT.json \
  --discovery-result runs/finite_left_replacement_20261104/root_strong_shard1_01/objects/RESULT.json \
  --discovery-result runs/finite_left_replacement_20261104/root_strong_shard2_01/objects/RESULT.json \
  --discovery-result runs/finite_left_replacement_20261104/root_strong_shard3_01/objects/RESULT.json \
  --output '{output}/accepted'
python3 -I -B tools/capture.py /fresh/comparison-controls tools/comparison_controls.py '{output}/accepted'
```

The complete reader requires exactly all3,385 pairs and independently checks
every leaf. A census-only run is explicitly not arithmetic acceptance.
Its result status is `PASS_EXACT_COMPLETE_STRONG_RESOURCE_3385_RAW_LEFT_PAIRS`.
Paths and timings vary between runs; the complete per-pair results and source
identities must agree. The portable run took177.734seconds and reproduced
the aggregate's entire per-pair results and source map. The gap replay took
12.317seconds and reproduced the exact expected result bytes. These are
observations on the tested machine, not runtime guarantees.

The gap controls reject17 malformed objects. The comparison controls reject
19 corruptions, including missing/reordered roots, missing children, an
unsupported exclusion, invalid quartics, duplicate JSON keys or whole pairs,
and a changed pinned kernel. Their deliberately corrupted source copies are
created only in disposable output directories.

## Finding and checking are different tasks

`root/discover_strong.py` uses floating-point linear programming to propose
rational quartics and a subdivision tree. Its candidate is then passed to
the exact reader. Neither optimizer success nor sampled positivity proves
the inequality. Acceptance reconstructs the semantic targets, verifies the
global majorants using exact rational polynomial root counts, and checks
every continuous score coefficient and coverage obligation.

The four completed discovery captures and all objects are included unchanged.
Their child runtime was conda CPython3.12.12, NumPy2.4.4 andSciPy1.17.1;
the capture supervisor was CPython3.12.14. These identities are distinct in
the records. Discovery is optional for reproduction: the standard-library
reader accepts the fixed objects independently of that floating stack.

## Evidence and scope

`python3 -I -B tools/verify_integrity.py` checks the final complete file census,
sizes and SHA-256 hashes against `FILES.json`. This is an integrity check;
the mathematical replay commands above remain separate.

`provenance/WORKSPACE_STAGE.json` and `CAMPAIGN_STAGE.json` bind the unchanged
source/data selection and the disjoint ownership of every object.
`COMPLETION.json` links the exact complete replays and controls.
Historical absolute paths in preserved captures describe those executions;
runtime imports and fixed inputs are local to this package. Documentation
and supporting evidence were added after the arithmetic replay; acceptance
sources and objects remained unchanged. The initial staged README and
conditional theorem snapshot are retained for that chronology.

The result permits the uniform proof to terminate its left branch at raw
node L, replacing the later S/L2 refinement and uniform-left confinement
and comparison descendants. The central branch and separate positive39
and finite40–48 modules retain their own dependencies. This package makes
no standalone all-law or all-index Berry–Esseen claim beyond its stated
acquired raw-left implication. Hashes establish integrity, not correctness;
the proof explains why these exact checks establish that implication.
