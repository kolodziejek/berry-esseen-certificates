# Raw-left direct comparison: portable candidate package

This directory is currently staged for verification. The complete quartic
campaign objects and its final all-pair readback have not yet been added.
No complete raw-left comparison is claimed by this staging checkpoint.

The selected readers retain their original bytes and workspace-relative
layout. `provenance/WORKSPACE_STAGE.json` records every source/data identity.
The `work/` and `runs/` directories here are a small self-contained subset;
they do not refer to an external workspace. There are no source adapters.

Exact acceptance requires unoptimized Python 3 with the standard library.
Never run with `-O` or `-OO`. NumPy and SciPy are needed only to repeat the
optional floating-point discovery, not to verify an existing proof object.
Hashes establish identity; the probability, moment, resource and polynomial
proofs are in `proofs/` and `gaps/SOUNDNESS.md`.

The full finite-index restriction is recomputed by the gap reader. It uses
the original 39 raw rows, the joint-defect lower bound and weighted nD
budget to derive every integer cap, then checks all3,385 row/index pairs
and8,248 licensed counts on their complete closed probability intervals,
including both sides of each binomial jump. `gaps/VERIFIED_GAPS.json` is a
fixed expected result, not a substitute for this recomputation.

From this directory, using fresh output paths outside the package:

```bash
python3 -I -B tools/capture.py /fresh/gap-run gaps/accept_gaps.py all '{output}/accepted' gaps/proof_object.json
python3 -I -B tools/capture.py /fresh/gap-controls gaps/controls.py '{output}/accepted'
```

The regenerated `accepted/RESULT.json` must have SHA-256
`d6b53cc0f4ec90d48105ea0d59b75819a704285504769ca592252ec1b0ccfce4`,
identical to the data consumed by the comparison reader at
`runs/finite_left_replacement_20261104/audit_gaps_all02/accepted/RESULT.json`.
The latter path names fixed input data in this package, not a new run.

The final comparison command will use
`work/finite_left_replacement_20261104/audit/complete_strong_campaign.py`.
It requires exactly all3,385 objects and independently recomputes every
resource exclusion, global quartic majorant and continuous tensor gate.
A file census alone is not acceptance. The original raw acquisition,
attainment/contact, common-law resources and analytic reduction remain
explicit premises; none is established merely by an arithmetic PASS.
