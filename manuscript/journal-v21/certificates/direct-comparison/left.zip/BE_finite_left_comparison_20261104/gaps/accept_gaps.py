"""Accept a fixed complete raw-left Bernoulli gap scope by exact recomputation."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from binomial_gap import *

def expected(scope):
    need(scope in ('row38','all'),'known complete scope')
    indices=[38]if scope=='row38'else list(range(39))
    return {'schema':'RAW_LEFT_FINITE_BERNOULLI_GAP_V1','scope':scope,'sources':PINS,
      'subdivisions':8,'minimum_epsilon':'1/100000000','closed_p':True,'both_jump_sides':True,
      'domains':[{'row':i,'n':n,'p':ROWS[i]['p'],'counts':count_domain(i,n)}for i in indices for n in range(47,CAPS[i]['n_upper']+1)]}
def validate(obj,scope):
    need(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False)==json.dumps(expected(scope),sort_keys=True,separators=(',',':'),allow_nan=False),'fixed complete closed probability/integer/count/branch cover')
def accept(obj,scope,out):
    validate(obj,scope)
    out.mkdir(exist_ok=False);results=[];smallest=None;where=None
    for d in obj['domains']:
        r=panel(d['row'],d['n'],obj['subdivisions'])
        need(r['count_cover']==d['counts'],'computed exact count cover')
        for b in r['rows']:
            e=F(b['epsilon']);need(e>=F(obj['minimum_epsilon']),'strict finite Bernoulli gap')
            if smallest is None or e<smallest:smallest=e;where=[d['row'],d['n'],b['k']]
        results.append(r)
        if len(results)%100==0:print(json.dumps({'completed':len(results),'total':len(obj['domains']),'minimum_epsilon':str(smallest)}),flush=True)
    result={'status':'PASS_EXACT_CLOSED_P_BERNOULLI_GAPS','scope':scope,'mathematical_status':'locally derived and checked under the acquired same-law count-domain and weighted-index premises',
      'execution_status':'fresh exact recomputation','row_n_pairs':len(results),'count_pairs':sum(len(x['rows'])for x in results),'closed_branch_cells':sum(16*len(x['rows'])for x in results),
      'minimum_epsilon':str(smallest),'minimum_location':where,'native_source_pins':PINS,'gaps':results}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'proof_object.json').write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in ('gaps','native_source_pins')}),flush=True)
    return result
if __name__=='__main__':
    scope=sys.argv[1];obj=json.loads(Path(sys.argv[3]).read_text())if len(sys.argv)==4 else expected(scope)
    accept(obj,scope,Path(sys.argv[2]))
