"""Independent small algebra checks plus malformed complete-cover controls."""
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial
import copy,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from binomial_gap import *
from accept_gaps import expected,validate

def polynomial_cdf(n,j):
    # Expand every mass independently; differentiate coefficients rather than
    # use the telescoping derivative formula of the acceptance implementation.
    coeff=[0]*(n+1)
    for b in range(j+1):
        for h in range(n-b+1):coeff[b+h]+=comb(n,b)*comb(n-b,h)*(-1)**h
    return coeff

def main():
    out=Path(sys.argv[1]);out.mkdir(exist_ok=False);counts={};num=0
    for n in range(2,15):
        for j in range(n):
            co=polynomial_cdf(n,j)
            for p in (F(1,10),F(3,10),F(2,5),F(j,n-1)if 0<j<n-1 else F(1,3)):
                d2=sum(F(a*r*(r-1))*p**(r-2)for r,a in enumerate(co)if r>=2)
                D=n*comb(n-1,j)*p**j*(1-p)**(n-1-j)
                need(d2==D*((n-1)*p-j)/(p*(1-p)),'independent CDF derivative identity')
                a,b=max(F(1,1000),p-F(1,1000)),min(F(499,1000),p+F(1,1000))
                if a<b and a<=p<=b:need(abs(d2)<=cdf_curvature(n,j,a,b),'curvature endpoint/critical-point bounds')
                num+=1
    counts['independent_binomial_derivative_checks']=num
    num=0
    for n in (2,3,7,47):
        for p in (F(1,4),F(3,10),F(19,50)):
            ks=list(range(n+1));a=endpoint(n,p,ks);b=C.endpoint(n,p.numerator,p.denominator)
            need([a[k]for k in ks]==b,'full and selected endpoint consistency')
            for k in ks:
                mass=F(comb(n,k))*p**k*(1-p)**(n-k)
                need(F(a[k][2]-a[k][1],C.S)<=mass<=F(a[k][3]-a[k][0],C.S),'jump mass bounds')
                num+=1
    counts['endpoint_jump_cases']=num
    # Normalization invariants include signs and exact central collisions.
    for n,p,k in [(4,F(1,4),1),(10,F(3,10),3),(50,F(19,50),19)]:
        need(C.cdf_at(n,k,p.numerator,p.denominator)==(C.S//2,C.S//2),'normal zero atom')
    counts['normal_zero_cases']=3
    obj=expected('all');mutants=[]
    def trial(name,edit):
        b=copy.deepcopy(obj);edit(b)
        try:validate(b,'all')
        except ValueError:mutants.append(name)
        else:raise AssertionError('accepted mutant '+name)
    trial('missing_row_n',lambda b:b['domains'].pop())
    trial('duplicate_row_n',lambda b:b['domains'].append(b['domains'][0]))
    trial('reordered_domains',lambda b:b['domains'].reverse())
    trial('missing_count',lambda b:b['domains'][-1]['counts'].pop())
    trial('duplicate_count',lambda b:b['domains'][-1]['counts'].append(b['domains'][-1]['counts'][0]))
    trial('reordered_counts',lambda b:b['domains'][-1]['counts'].reverse())
    trial('changed_count',lambda b:b['domains'][-1]['counts'].__setitem__(0,0))
    trial('changed_n',lambda b:b['domains'][-1].update(n=327))
    trial('changed_p_endpoint',lambda b:b['domains'][-1].update(p=['189/500','379/1000']))
    trial('one_jump_side',lambda b:b.update(both_jump_sides=False))
    trial('open_p',lambda b:b.update(closed_p=False))
    trial('changed_target',lambda b:b.update(minimum_epsilon='0'))
    trial('changed_source',lambda b:b['sources'].update(raw_left='0'*64))
    trial('changed_subdivision',lambda b:b.update(subdivisions=7))
    trial('boolean_row_index',lambda b:b['domains'][0].update(row=False))
    trial('integer_branch_flag',lambda b:b.update(both_jump_sides=1))
    trial('floating_n',lambda b:b['domains'][0].update(n=47.0))
    # Positive controls exercise extreme acquired rows/count caps without
    # repeating the whole 3385-pair calculation.
    controls=[]
    for i,n in ((0,47),(38,47),(38,326)):
        r=panel(i,n,8);need(all(F(x['epsilon'])>F(1,500)for x in r['rows']),'independent selected positive controls')
        controls.append(r)
    result={'status':'PASS_EXACT_ADVERSARIAL_BINOMIAL_GAP_CONTROLS','algebra_checks':counts,'rejected_mutants':mutants,'positive_controls':controls}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':counts,'rejections':len(mutants)}))
if __name__=='__main__':main()
