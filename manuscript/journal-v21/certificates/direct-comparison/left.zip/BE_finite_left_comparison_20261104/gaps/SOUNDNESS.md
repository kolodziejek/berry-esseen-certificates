# Exact finite Bernoulli gaps on the acquired raw-left domains

Mathematical status: locally derived and checked, with explicit inherited
same-law domain premises below. Execution status: fresh exact PASS for the
full stated finite domain. This does not prove the conditional-noise
comparison or acquire any input table.

## Claim and domain

Let raw row `i` in the pinned `native/raw_left.json` be acquired for one law,
with `p in [l,h]`, `theta <= Theta`, `-Hminus <= H <= Hplus`, and weighted
`n D <= 47 row.D`. Assume the central-gap joint-defect inequality

`D >= (6+2 sqrt(10)) (1-theta)^(3/2) (p-p*)^2/sqrt(p(1-p))`,
`p*=(4-sqrt(10))/2`.

The independent finite-index derivation in `check_left_index_cap.py` is
recomputed here, not inferred from its historical output: put
`sigmaL=3162277660/10^9`, `sigmaU=3162277661/10^9`, use directed square roots
on grid `10^-12`, and take

`P=(6+2 sigmaL) sqrtLower((1-Theta)^3)/sqrtUpper(h(1-h)) * ((4-sigmaU)/2-h)^2`.

This is positive and `D >= P`. Therefore
`n <= floor(47 row.D/P)`. The 39 exact integer caps total 3,385 pairs
`(row,n)` with `n>=47`, with largest cap 326. The checker reconstructs P
and each floor exactly, and checks the complete census.

Set `ell=sqrt((1-theta)/(p(1-p)))` and let the actual nearest count satisfy
`x=np+H/ell=k+u`, `-1/2 <= u <= 1/2` (either convention at a tie is included).
With `E=sqrtLower((1-Theta)/(h(1-h)))>0`, every such k belongs to

`ceil(n l-Hminus/E-1/2) <= k <= floor(n h+Hplus/E+1/2)`.

Intersect this integer interval with `[0,n]`. This may include infeasible
counts, which only strengthens the check. Each included k is checked on
**the entire original closed probability row**, without assuming k remains
feasible at all its p. No assertion about other counts is needed or made.

For `B~Bin(n,p)`, `v=p(1-p)`, `z=(k-np)/sqrt(nv)` and
`rhoB=(1-2v)/sqrt(v)`, both normalized jump scores obey

`CBplus=sqrt(n)/rhoB * (Pr(B<=k)-Phi(z)) <= CE-epsilon`,
`CBminus=sqrt(n)/rhoB * (Phi(z)-Pr(B<=k-1)) <= CE-epsilon`.

`CE=(3+sqrt(10))/(6 sqrt(2 pi))`. The second score is the reflected branch
and uses the strict binomial left limit. Consequently all atom collisions
and both sign branches are included. The result data supplies a separate
exact epsilon for each (row,n,k), and a conservative `rhoB_epsilon`.

The accepted full-domain minimum is
`574819469/250000000000 = 0.002299277876 > 1/500`.
It occurs at row 38, n=309, k=117. This number is an output of all exact
checks, not a substituted target. The fixed minimum acceptance target is
`1/100000000`. These bounds do not assert a comparison for a noisy law.

## Why eight probability subcells suffice

A twice differentiable function d on [a,b], with `|d''|<=M`, satisfies

`d(p) <= max(d(a),d(b)) + M (b-a)^2/8`.

Indeed its linear interpolant L obeys
`d(p)-L(p)=d''(xi)(p-a)(p-b)/2`; equivalently the same result follows by
subtracting `M(p-a)(b-p)/2` and convexity. Both proofs include endpoints.
We apply it separately to `dplus=F_k-Phi(z)` and
`dminus=Phi(z)-F_(k-1)` on eight equal closed subcells.

For `0<=j<n`, differentiate the binomial CDF using the exact telescoping
identity

`F_j'=-D_j`, `D_j=n binom(n-1,j) p^j (1-p)^(n-1-j)`,
`F_j''=D_j * ((n-1)p-j)/(p(1-p))`.

`D_j` is maximized on [a,b] at the clipped point `j/(n-1)`.
It is evaluated there as an exact rational. Since `p(1-p)>=a(1-a)` here,

`|F_j''| <= max(D_j) max(|(n-1)a-j|,|(n-1)b-j|)/(a(1-a))`.

For `j=-1,n`, the CDF is constant and curvature zero.

Put `A=k-np`, `B=k+(n-2k)p`. Direct differentiation gives

`z'=-B/(2 sqrt(n) v^(3/2))`,
`z''=-(n-2k)/(2 sqrt(n) v^(3/2)) + 3 B(1-2p)/(4 sqrt(n) v^(5/2))`.

`B=k(1-p)+(n-k)p>0` for 0<=k<=n and 0<p<1.
The absolute A and B are bounded at the endpoints; `1-2p<=1-2a`
and `v>=a(1-a)`. Directed lower square roots yield the displayed code's
rational upper bounds `Z,Z1,Z2` for `|z|,|z'|,|z''|`.
Since `phi(z)<=phi(0)<2/5`,

`|(Phi(z))''| = |phi(z)(z''-z(z')^2)| <= (2/5)(Z2+Z Z1^2)`.

Add the relevant CDF curvature to this bound. Combining endpoint upper
bounds with the chord error proves the computed d upper bound. Clamp it
at zero, then multiply by the upper score factor
`sqrtUpper(n b(1-b))/(1-2b(1-b))`. This factor is increasing for p<1/2:
writing v=p(1-p), the derivative of `sqrt(v)/(1-2v)` is
`(1+2v)/(2 sqrt(v)(1-2v)^2)>0`.

The largest exact subcell bound is rounded **up** to grid 10^-12.
Subtract it from the rigorous native `CE_LO` and round **down** on the
same grid. Finally `rhoB` is decreasing for p<1/2, so
`(1-2h(1-h))/sqrtUpper(h(1-h))` is a valid positive lower bound.
The output `rhoB_epsilon` rounds their product downward.

## Endpoint arithmetic and trusted stack

`native/finite_binomial_core.py` is copied unchanged and checked against
SHA-256 `939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f`.
Its complete 3,510-byte source was read before reuse. It uses Python
integers and `Fraction`, with integer-square-root enclosures, Machin's
arctangent formula, and the Gaussian integral Taylor polynomial through
term79 plus the absolute term80 remainder. The integrated Taylor bound
is valid throughout [0,5]; outside this interval a rational Mills bound
is used. All divisions and grid roundings are directed. Phi(-z)=1-Phi(z)
is applied with interval endpoints reversed. CE_LO combines lower
sqrt(10) and lower phi(0).

The new selected-count endpoint routine sums exact binomial mass integers
with denominator M^n, checks every recurrence division and that all masses
sum to that denominator, and extracts both the pre-jump and post-jump CDFs.
It invokes the pinned normal routine only for the selected counts. No
floating arithmetic, numerical optimizer, or optional dependency is used.
Unoptimized Python is required. Hashes establish source identity; the
formulas above supply the mathematical justification.

## Reproduction and scope of evidence

From a directory containing these audit sources and `native/`, run

```
python3 -I -B accept_gaps.py all /fresh/absolute/output/path
```

The output directory must not already exist. `capture.py` supplies the
wrapper used for the recorded execution; it records exact argv, runtime,
stdout, stderr, return code, elapsed time and before/after source hashes.
The recorded command is in
`runs/finite_left_replacement_20261104/audit_gaps_all02/PROCESS.json`.
Actual rc=0, all pinned/acceptance sources unchanged, elapsed11.8329 seconds.
`accepted/RESULT.json` contains all 3,385 exact result rows. The proof
object fixes source identities, all original closed intervals, all integer
caps and all count domains. The acceptor reconstructs and compares this
entire object before any arithmetic check; omissions, duplicates,
reordering, narrowed domains and changed targets reject.

Fresh arithmetic verifies these finite Bernoulli bounds. The inherited
contact, acquisition, weighted-defect and same-law normalization claims
remain explicit analytic premises. No new acquisition or complete
conditional-noise comparison is claimed here.

The second capture adds strict JSON type comparison for proof-object fields;
boolean/integer and floating/integer substitutions now reject. It reproduces
the same exact gaps. The first capture remains preserved. The full controls
receipt is `runs/finite_left_replacement_20261104/audit_gaps_controls02`: 416
independent expanded-binomial derivative identities,189 jump comparisons,
three exact normal collisions,17 malformed-object rejections, and three
selected endpoint-row positive checks. These are supplemental controls, not
a replacement for the full-domain acceptance.
