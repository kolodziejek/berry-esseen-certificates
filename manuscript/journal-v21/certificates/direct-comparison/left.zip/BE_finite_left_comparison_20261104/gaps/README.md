# Exact finite Bernoulli gap package

This package is relocatable and requires only unoptimized Python 3, with its
standard-library integers, Fraction and isqrt. See SOUNDNESS.md for the full
analytic statement, inherited premises, atom conventions and exact arithmetic.

From this directory, execute:

```
python3 -I -B accept_gaps.py all /fresh/absolute/output/path proof_object.json
python3 -I -B controls.py /another/fresh/absolute/output/path
```

Both destinations must not exist. VERIFIED_GAPS.json is the preserved result
of the full actual acceptance; it is a convenient index, not a substitute for
recomputing the proof object. Every native source is pinned and the index cap
is recomputed. All39 probability rows,3385 row/index pairs and8248 acquired
count pairs are checked on their original closed intervals and both binomial
jump sides. The minimum certified gap CE−CB is .002299277876.

This does not prove acquisition or the noisy-law comparison. Historical
source/capture paths in the supporting notes are provenance labels; runtime
imports and inputs are all within this directory.
