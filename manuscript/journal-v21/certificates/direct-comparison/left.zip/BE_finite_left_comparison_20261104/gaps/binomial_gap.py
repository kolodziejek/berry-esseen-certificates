"""Exact closed-p finite Bernoulli margins on acquired raw-left count domains.

Native Gaussian integrals are copied unchanged and pinned.  This file adds a
second-derivative chord bound; no floating computation enters acceptance.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import hashlib, importlib.util, json, sys
if not __debug__ or sys.flags.optimize:
    raise RuntimeError('unoptimized Python is required')
HERE=Path(__file__).resolve().parent
PINS={'finite_binomial_core.py':'939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f','raw_left.json':'2270ab68dd18e13afb7382e046589346e4cab26721a4e48be77b66ec22aa4b9a','left_caps.json':'b714d74aa6b82ea44a87c9415c41b185cd6578b57fa5dcd26801aab869549fbf'}
def need(v,s):
    if not v: raise ValueError(s)
def load():
    for name,pin in PINS.items():need(hashlib.sha256((HERE/'native'/name).read_bytes()).hexdigest()==pin,'source hash '+name)
    spec=importlib.util.spec_from_file_location('pinned_binomial_core',HERE/'native'/'finite_binomial_core.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    rows=json.loads((HERE/'native'/'raw_left.json').read_text())['panels']
    caps=json.loads((HERE/'native'/'left_caps.json').read_text())['tables']['raw_left39']['rows']
    need(len(rows)==len(caps)==39,'complete raw row census')
    for i,(r,c) in enumerate(zip(rows,caps)):
        need(type(r['index']) is int and r['index']==i==c['index'],'ordered unique rows')
        need(list(map(F,r['p']))==[F(151+i,500),F(152+i,500)]==list(map(F,c['p'])),'closed row endpoints')
        sl,su=F(3162277660,10**9),F(3162277661,10**9);u=F(r['p'][1]);theta=F(r['theta'])
        need(sl**2<10<su**2 and (4-su)/2>u and 0<=theta<1,'defect cap guards')
        P=(6+2*sl)*m.root((1-theta)**3,10**12)[0]/m.root(u*(1-u),10**12)[1]*((4-su)/2-u)**2
        need(P==F(c['P_lower']) and c['n_upper']*P<=47*F(r['D'])<(c['n_upper']+1)*P,'exact index cap')
    need(sum(max(0,c['n_upper']-46)for c in caps)==3385,'complete integer census')
    return m,rows,caps
C,ROWS,CAPS=load()
def count_domain(i,n):
    r=ROWS[i];l,u=map(F,r['p']);th=F(r['theta'])
    need(type(i)is int and 0<=i<39 and type(n)is int and 47<=n<=CAPS[i]['n_upper'],'row/index domain')
    ell=C.root((1-th)/(u*(1-u)))[0];need(ell>0,'positive span lower bound')
    xmin=n*l-F(r['H_minus'])/ell-F(1,2)
    xmax=n*u+F(r['H_plus'])/ell+F(1,2)
    return list(range(max(0,C.ceildiv(xmin.numerator,xmin.denominator)),min(n,xmax.numerator//xmax.denominator)+1))
def endpoint(n,p,ks):
    """Both binomial jump limits and Gaussian CDF for selected actual counts."""
    a,M=p.numerator,p.denominator;den=M**n;b=(M-a)**n;cum=0;ans={}
    for j in range(n+1):
        prev=cum;cum+=b
        if j in ks:
            phlo,phhi=C.cdf_at(n,j,a,M)
            ans[j]=(prev*C.S//den,C.ceildiv(prev*C.S,den),cum*C.S//den,C.ceildiv(cum*C.S,den),phlo,phhi)
        if j<n:
            v=b*(n-j)*a;d=(j+1)*(M-a);need(v%d==0,'integer binomial mass recurrence');b=v//d
    need(cum==den and set(ans)==set(ks),'complete selected count sums')
    return ans

def cdf_curvature(n,j,l,u):
    if j==-1 or j==n:return F(0)
    need(0<=j<n,'binomial CDF derivative index')
    p=max(l,min(u,F(j,n-1)))
    d=n*comb(n-1,j)*p**j*(1-p)**(n-1-j)
    return d*max(abs((n-1)*l-j),abs((n-1)*u-j))/(l*(1-l))
def normal_curvature(n,k,l,u):
    v=l*(1-l);sr=C.root(v)[0];sn=C.root(F(n))[0]
    a=max(abs(k-n*l),abs(k-n*u));B=max(k+(n-2*k)*l,k+(n-2*k)*u)
    need(B>0 and sr>0 and sn>0,'normal derivative denominators')
    z=a/(sn*sr);z1=B/(2*sn*v*sr)
    z2=abs(n-2*k)/(2*sn*v*sr)+3*B*(1-2*l)/(4*sn*v*v*sr)
    return F(2,5)*(z2+z*z1*z1)
def round_up(q,scale=10**12):return F(C.ceildiv(q.numerator*scale,q.denominator),scale)
def round_down(q,scale=10**12):return F(q.numerator*scale//q.denominator,scale)
def panel(i,n,subdiv):
    need(type(subdiv)is int and 1<=subdiv<=4096,'subdivision integer')
    ks=count_domain(i,n);r=ROWS[i];pl,pu=map(F,r['p']);h=(pu-pl)/subdiv
    left=endpoint(n,pl,ks);best={k:{'+':F(0),'-':F(0)}for k in ks}
    for a in range(subdiv):
        l=pl+a*h;u=l+h;right=endpoint(n,u,ks);v=u*(1-u);factor=C.root(n*v)[1]/(1-2*v)
        for k in ks:
            normal=normal_curvature(n,k,l,u)
            for sign,j,li,ri in [('+',k,3,4),('-',k-1,5,0)]:
                dleft=F(left[k][li]-left[k][ri],C.S);dright=F(right[k][li]-right[k][ri],C.S)
                M=normal+cdf_curvature(n,j,l,u)
                d=max(F(0),max(dleft,dright)+M*h*h/8)
                best[k][sign]=max(best[k][sign],factor*d)
        left=right
    rholo=(1-2*pu*(1-pu))/C.root(pu*(1-pu))[1]
    out=[]
    for k in ks:
        caps={s:round_up(b)for s,b in best[k].items()};cap=max(caps.values());eps=round_down(C.CE_LO-cap)
        out.append({'k':k,'score_caps':{s:str(q)for s,q in caps.items()},'epsilon':str(eps),'rhoB_epsilon':str(round_down(rholo*eps))})
    return {'row':i,'n':n,'p':r['p'],'subdivisions':subdiv,'count_cover':ks,'rhoB_lower':str(rholo),'rows':out}
def main():
    i,n,sub=map(int,sys.argv[1:4]);r=panel(i,n,sub);print(json.dumps(r,indent=2))
if __name__=='__main__':main()
