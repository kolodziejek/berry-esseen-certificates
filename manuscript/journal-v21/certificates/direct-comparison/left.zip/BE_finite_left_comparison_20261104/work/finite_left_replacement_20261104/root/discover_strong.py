"""Translated-quartic floating search; acceptance only uses exact cover_shift."""
from pathlib import Path
from fractions import Fraction as F
import sys,types,hashlib,math
import numpy as np
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import cover_strong as cov
import discover_cover as driver

def propose(z):
    records=cov.gate.affine_gates(**cov.arguments(z))
    norm=float((z['n']*(z['pl']+z['pu'])/2*(1-(z['pl']+z['pu'])/2))**2)
    lhs0=[];rhs0=[];seen=set()
    for r in records:
        transformed=cov.gate.bernstein_affine(r,z['pl'],z['pu'],z['ul'],z['uh'])
        C,A=transformed['constant'],transformed['linear']
        for i in range(7):
          for j in range(5):
            exact=(C[i][j],*(v[i][j]for v in A))
            if exact in seen:continue
            seen.add(exact);lhs0.append([-float(v[i][j])/norm for v in A]+[1.]);rhs0.append(float(C[i][j])/norm)
    c,R=map(float,(z['c'],z['R0']));J=8
    def target(x):
        if x<-J*c:return R*(-x)/c
        if x>1e-10:return -1.
        zz=-x/c
        if abs(zz-round(zz))<1e-9:zz=round(zz)
        return R*max(0,math.floor(zz))
    points=sorted(set(np.linspace(-10,10,51))|{-j*c for j in range(J+1)}|{0.})
    for iteration in range(50):
        lhs=list(lhs0);bound=list(rhs0)
        for x in points:
            scale=max(1.,abs(x)**4);lhs.append([-x**j/scale for j in range(5)]+[0.]);bound.append(-target(x)/scale)
        ans=linprog([0.]*5+[-1.],A_ub=lhs,b_ub=bound,bounds=[(-100,100)]*4+[(.001,100),(-100,100)],
          method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
        if not ans.success:return None,{'reason':'LP','message':ans.message}
        if ans.x[-1]<2e-6:return None,{'reason':'loss','margin':float(ans.x[-1])}
        q=ans.x[:5];der=np.array([j*q[j]for j in range(1,5)]);extra=[]
        for zz in np.polynomial.polynomial.polyroots(der):
            if abs(zz.imag)<1e-7 and zz.real>=-J*c:
                x=float(zz.real)
                if np.polynomial.polynomial.polyval(x,q)-target(x)<-1e-8*max(1.,abs(x)**4):extra.append(x)
        der[0]+=R/c
        for zz in np.polynomial.polynomial.polyroots(der):
            if abs(zz.imag)<1e-7 and zz.real<-J*c:
                x=float(zz.real)
                if np.polynomial.polynomial.polyval(x,q)-target(x)<-1e-8*max(1.,abs(x)**4):extra.append(x)
        if extra:points.extend(extra);continue
        rational=[F(round(float(v)*10**10),10**10)for v in q]
        rational[0]+=F(1,10**6);rational[4]+=F(1,10**7)
        try:
            margin=cov.leaf_check(z,rational)
            return list(map(str,rational)),{'margin':str(margin),'LP_margin':float(ans.x[-1]),'iterations':iteration+1}
        except ValueError as e:return None,{'reason':'exact','message':str(e),'LP_margin':float(ans.x[-1]),'q':list(map(str,rational))}
    return None,{'reason':'separation_limit','q':list(map(float,q)),'extra':extra,'LP_margin':float(ans.x[-1])}

def main():
    # Reuse only the discovery tree driver; the acceptance contract is separate.
    original=cov.sources
    def sources():
        result=original()
        for p in(Path(__file__),HERE/'discover_cover.py'):
            result[str(p.relative_to(cov.enc.ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
        return result
    cov.sources=sources;driver.cover=cov;driver.gate=cov.gate;driver.propose=propose
    driver.enc=types.SimpleNamespace(parameters=cov.parameters,encode=cov.enc.encode,ROOT=cov.enc.ROOT,
      GAPMAP=cov.enc.GAPMAP,need=cov.need)
    driver.main()
if __name__=='__main__':main()
