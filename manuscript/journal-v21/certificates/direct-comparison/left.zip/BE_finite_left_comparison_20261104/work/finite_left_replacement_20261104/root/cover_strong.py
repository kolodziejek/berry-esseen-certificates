"""Exact complete cover with a quartic in Z=W-u and bivariate score gates."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,time,argparse
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import cover as basic
import enclosures_strong as enc
need=enc.need;globalq=basic.globalq
gate=basic.module('shifted_quartic_fast',HERE.parent/'construction/shifted_quartic_fast.py')
SCHEMA='RAW_LEFT_TRANSLATED_QUARTIC_COVER_V1'
roots=basic.roots;children=basic.children
def sources():
    out=basic.sources()
    for p in(Path(__file__),HERE/'enclosures_strong.py',HERE.parent/'construction/shifted_quartic_gate.py',HERE.parent/'construction/shifted_quartic_fast.py'):
        out[str(p.relative_to(enc.ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
    return out
def parameters(index,n,k,pl,pu,ul,uh):
    z=enc.parameters(index,n,k,pl,pu,ul,uh)
    if 'excluded'in z:return z
    vl=pl*(1-pl);wh=pu*(1-pu)+z['U']/n
    if ul>=0:
        dl,dh=k-n*pu,k-n*pl
        mx=max(abs(dl),abs(dh),abs(dl+ul),abs(dh+uh))
        pm=enc.lo(enc.PHILO*(1-mx*mx/(2*n*vl)));need(pm>0,'positive phase density')
        phasecoef=enc.lo(pm/enc.sqrthi(wh))
    else:
        need(uh<=0,'closed phase sign');phasecoef=enc.hi(enc.PHIHI/enc.sqrtlo(vl))
    need(phasecoef>0,'positive phase coefficient');z['phasecoef']=phasecoef;z['phase']=F(0)
    return z
def arguments(z):return {**basic.arguments(z),'ul':z['ul'],'uh':z['uh'],'phasecoef':z['phasecoef']}
def leaf_check(z,q):
    need(type(q)is list and len(q)==5 and all(type(v)in(int,str,F)for v in q),'five exact translated coefficients')
    q=list(map(F,q));need(q[4]>0,'strictly coercive translated quartic')
    globalq.accept(q,F(0),z['c'],z['R0'])
    polys=gate.gates(**arguments(z),q=q);need(len(polys)==24,'all translated moment corners')
    coeffs=[v for p in polys for row in gate.bernstein(p,z['pl'],z['pu'],z['ul'],z['uh'])for v in row]
    need(min(coeffs)>0,'strict positive bivariate continuous loss');return min(coeffs)
def accept_pair(obj):
    need(type(obj)is dict and set(obj)=={'schema','row','n','trees'}and obj['schema']==SCHEMA,'exact translated cover schema')
    index,n=obj['row'],obj['n'];expected=roots(index,n)
    need(type(obj['trees'])is list and len(obj['trees'])==len(expected),'complete count/sign root census')
    stats={'excluded':0,'quartics':0,'splits':0,'maxdepth':0};minimum=None
    def visit(node,k,cell,depth):
        nonlocal minimum
        need(depth<=36 and type(node)is dict,'finite translated tree');stats['maxdepth']=max(stats['maxdepth'],depth)
        if 'split'in node:
            need(set(node)=={'split','children'}and type(node['children'])is list and len(node['children'])==2,'both closed translated children')
            cc=children(cell,node['split']);stats['splits']+=1
            for ch,sub in zip(node['children'],cc):visit(ch,k,sub,depth+1)
            return
        z=parameters(index,n,k,*cell)
        if set(node)=={'excluded'}:
            need('excluded'in z and node['excluded']==z['excluded'],'recomputed translated exclusion');stats['excluded']+=1;return
        need(set(node)=={'q'}and 'excluded'not in z,'exact translated quartic leaf')
        margin=leaf_check(z,node['q']);minimum=margin if minimum is None else min(minimum,margin);stats['quartics']+=1
    for r,(k,sign,cell)in zip(obj['trees'],expected):
        need(type(r)is dict and set(r)=={'k','sign','tree'}and type(r['k'])is int and type(r['sign'])is int,'fixed translated root fields')
        need((r['k'],r['sign'])==(k,sign),'ordered translated count/sign roots');visit(r['tree'],k,cell,0)
    return {'status':'PASS_EXACT_COMPLETE_TRANSLATED_RAW_LEFT_PAIR','row':index,'n':n,**stats,
      'minimum_cleared_loss_coefficient':str(minimum)if minimum is not None else None}
def strict_json(text):
    def pairs(items):
        result={}
        for k,v in items:
            need(k not in result,'duplicate JSON key');result[k]=v
        return result
    return json.loads(text,object_pairs_hook=pairs)

def main():
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('output');a=p.parse_args()
    src=Path(a.input);out=Path(a.output);out.mkdir(parents=True,exist_ok=False);start=time.monotonic();before=sources()
    files=sorted(src.glob('pair_*.json'))if src.is_dir()else[src];need(files,'nonempty translated input')
    results=[];seen=set();pins={str(f.resolve()):hashlib.sha256(f.read_bytes()).hexdigest()for f in files}
    for f in files:
        obj=strict_json(f.read_text());key=(obj.get('row'),obj.get('n'));need(key not in seen,'unique translated pairs');seen.add(key)
        r=accept_pair(obj);results.append(r);print(json.dumps(r),flush=True)
    need(before==sources(),'unchanged translated arithmetic sources')
    need(all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==pin for f,pin in pins.items()),'unchanged translated input objects')
    (out/'RESULT.json').write_text(json.dumps({'status':'PASS_EXACT_LISTED_TRANSLATED_RAW_LEFT_PAIRS','results':results,
      'scope':'Only listed complete pairs; acquired hypotheses and analytic reductions remain documented dependencies.',
      'sources':before,'inputs':pins,'seconds':time.monotonic()-start},indent=2)+'\n')
if __name__=='__main__':main()
