"""Join exactly all3385 strong-resource translated-quartic raw-left pairs, then replay the exact cover acceptor.

A complete file census is not a mathematical acceptance. No historical PASS
marker substitutes for cover.accept_pair on every proposed proof object.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,importlib.util,json,sys,time
if not __debug__ or sys.flags.optimize:raise RuntimeError('unoptimized Python required')
ROOT=Path(__file__).resolve().parents[3]
GAPS=ROOT/'runs/finite_left_replacement_20261104/audit_gaps_all02/accepted/RESULT.json'
GAP_PIN='d6b53cc0f4ec90d48105ea0d59b75819a704285504769ca592252ec1b0ccfce4'
HERE=Path(__file__).resolve().parent

def need(v,s):
    if not v:raise ValueError(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict_json(data):
    def pairs(items):
        out={}
        for k,v in items:
            need(k not in out,'duplicate JSON object key '+k)
            out[k]=v
        return out
    def invalid(token):raise ValueError('nonfinite JSON number '+token)
    return json.loads(data,object_pairs_hook=pairs,parse_constant=invalid)
def expected():
    need(sha(GAPS)==GAP_PIN,'exact independently checked Bernoulli gap source')
    data=strict_json(GAPS.read_text());rows=data['gaps'];keys=[(r['row'],r['n'])for r in rows]
    need(len(keys)==len(set(keys))==3385 and data['row_n_pairs']==3385,'complete unique expected finite census')
    need(all(type(i)is int and type(n)is int and 0<=i<39 and 47<=n<=326 for i,n in keys),'strict expected pair types')
    return set(keys)
def inspect(inputs):
    files=[]
    for src in inputs:
        need(src.exists()and not src.is_symlink(),'ordinary existing input root')
        ff=sorted(src.glob('pair_*.json'))if src.is_dir()else[src]
        need(ff,'nonempty selected proof root');files.extend(ff)
    records={}
    for p in files:
        need(p.is_file()and not p.is_symlink(),'ordinary proof object file')
        data=p.read_bytes();o=strict_json(data)
        need(type(o)is dict and type(o.get('row'))is int and type(o.get('n'))is int,'strict pair identity')
        key=(o['row'],o['n']);need(key not in records,'duplicate row/index proof object '+str(key))
        records[key]=(p,o,hashlib.sha256(data).hexdigest())
    want=expected();have=set(records)
    return records,sorted(want-have),sorted(have-want)

def source_pins():
    rel=['work/finite_left_replacement_20261104/root/cover_strong.py','work/finite_left_replacement_20261104/root/enclosures_strong.py','work/finite_left_replacement_20261104/root/discover_strong.py','work/finite_left_replacement_20261104/root/discover_cover.py','work/finite_left_replacement_20261104/root/cover.py','work/finite_left_replacement_20261104/root/cover_shift.py','work/finite_left_replacement_20261104/root/cover_fast.py','work/finite_left_replacement_20261104/root/enclosures.py',
      'work/finite_left_replacement_20261104/construction/quartic_gate.py','work/finite_left_replacement_20261104/construction/quartic_gate24.py','work/finite_left_replacement_20261104/construction/shifted_quartic_gate.py','work/finite_left_replacement_20261104/construction/shifted_quartic_fast.py',
      'work/finite_left_replacement_20261104/audit/quartic_global.py','work/finite_left_replacement_20261104/audit/quartic_sturm.py',
      'work/finite_left_replacement_20261104/audit/complete_strong_campaign.py','work/below50_20260929/entry/left_input47_table.json',str(GAPS.relative_to(ROOT))]
    return {r:{'bytes':(ROOT/r).stat().st_size,'sha256':sha(ROOT/r)}for r in rel}

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',action='append',required=True);p.add_argument('--output',required=True)
    p.add_argument('--discovery-result',action='append',default=[]);p.add_argument('--inventory-only',action='store_true');a=p.parse_args()
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    records,missing,extra=inspect([Path(x).absolute()for x in a.input])
    inv={'schema':'EXACT_STRONG_RESOURCE_RAW_LEFT3385_CAMPAIGN_JOIN_V1','expected_pairs':3385,'provided_pairs':len(records),'missing':missing,'extra':extra,
      'pair_files':{str(k):{'path':str(v[0].resolve()),'sha256':v[2]}for k,v in sorted(records.items())},'gap_sha256':GAP_PIN,
      'arithmetic_acceptance_claimed':False}
    (out/'INVENTORY.json').write_text(json.dumps(inv,indent=2)+'\n')
    need(not missing and not extra,'incomplete or extraneous finite campaign; see INVENTORY.json')
    if a.inventory_only:
        print(json.dumps({'status':'COMPLETE_BYTE_CENSUS_ONLY','pairs':3385,'arithmetic_acceptance_claimed':False}));return
    before=source_pins()
    spec=importlib.util.spec_from_file_location('full_finite_left_strong_cover',ROOT/'work/finite_left_replacement_20261104/root/cover_strong.py')
    cover=importlib.util.module_from_spec(spec);spec.loader.exec_module(cover)
    discovery=[]
    for name in a.discovery_result:
        f=Path(name).resolve();need(f.is_file()and not f.is_symlink(),'ordinary discovery record')
        d=strict_json(f.read_text());need(type(d)is dict and type(d.get('sources'))is dict,'recorded discovery source map')
        for path,pin in d['sources'].items():
            if path in before:need(pin==before[path]['sha256'],'discovery/acceptance source epoch mismatch '+path)
        discovery.append({'path':str(f),'sha256':sha(f),'sources':d['sources'],'scope':'preserved discovery record, not mathematical evidence by itself'})
    results=[]
    for key,(path,obj,pin)in sorted(records.items()):
        need(sha(path)==pin,'proof object changed before readback')
        need(obj.get('schema')=='RAW_LEFT_TRANSLATED_QUARTIC_COVER_V1','fixed translated proof schema')
        r=cover.accept_pair(obj);need((r['row'],r['n'])==key,'accepted same pair identity');results.append(r)
        if len(results)%100==0:print(json.dumps({'accepted':len(results),'total':3385}),flush=True)
    after=source_pins();need(before==after,'all acceptance sources unchanged')
    need(all(sha(v[0])==v[2]for v in records.values()),'all proof objects unchanged')
    result={'status':'PASS_EXACT_COMPLETE_STRONG_RESOURCE_3385_RAW_LEFT_PAIRS','pair_count':len(results),'results':results,
      'source_before':before,'source_after':after,'discovery_records':discovery,'seconds':time.monotonic()-start,'runtime':sys.version,
      'mathematical_scope':'All complete strong-resource translated-quartic raw-left finite row/index/count/p/phase/noise/moment implications accepted at the documented analytic and same-law acquisition boundary; acquisition not rerun.',
      'execution_scope':'Fresh exact cover_strong.accept_pair replay for every one of the3385 expected pairs; no missing or duplicate pair.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'pair_count':len(results),'seconds':result['seconds']}),flush=True)
if __name__=='__main__':main()
