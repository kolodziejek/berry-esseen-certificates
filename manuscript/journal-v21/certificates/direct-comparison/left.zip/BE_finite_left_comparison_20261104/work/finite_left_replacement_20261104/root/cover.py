"""Read-only exact acceptance of a complete raw-left p/phase dyadic cover.

Every noise and conditional moment value is handled by analytic concavity.
This reader imports no floating discovery, numerical solver, or optimization.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parent/'construction'))
import enclosures as enc
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
gate=module('quartic_gate24',HERE.parent/'construction/quartic_gate24.py')
globalq=module('quartic_sturm',HERE.parent/'audit/quartic_sturm.py')
need=enc.need
KEYS=('n','k','pl','pu','L','U','A0','A1','d0','gap','phase','varcoef','cgain','blo','bhi')
SCHEMA='RAW_LEFT_SAME_MARGINAL_QUARTIC_COVER_V1'
def arguments(z):return {k:z[k]for k in KEYS}
def sources():
    paths=[Path(__file__),HERE/'enclosures.py',HERE.parent/'construction/quartic_gate24.py',HERE.parent/'construction/quartic_gate.py',
           HERE.parent/'audit/quartic_sturm.py',HERE.parent/'audit/quartic_global.py',enc.RAW,enc.GAPS]
    return {str(p.relative_to(enc.ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
def leaf_check(z,q):
    need(type(q)is list and len(q)==5 and all(type(v)in(int,str,F)for v in q),'five exact coefficients')
    q=list(map(F,q));need(q[4]>0,'strictly coercive quartic')
    globalq.accept(q,z['uh'],z['c'],z['R0'])
    polys=gate.gates(**arguments(z),q=q)
    need(len(polys)==24,'complete same-marginal moment corners')
    coeffs=[v for p in polys for v in gate.bernstein(p,z['pl'],z['pu'])]
    need(min(coeffs)>0,'strict positivity of every continuous score gate')
    return min(coeffs)
def roots(index,n):
    need(type(index)is int and type(n)is int and (index,n)in enc.GAPMAP,'licensed row and integer')
    pl,pu=map(F,enc.ROWS[index]['p'])
    return [(k,sign,(pl,pu,F(-1,2)if sign==0 else F(0),F(0)if sign==0 else F(1,2)))
            for k in enc.GAPMAP[index,n]['count_cover']for sign in (0,1)]
def children(cell,axis):
    pl,pu,ul,uh=cell
    if axis=='p':
        m=(pl+pu)/2;return(pl,m,ul,uh),(m,pu,ul,uh)
    need(axis=='u','fixed split axis');m=(ul+uh)/2
    return(pl,pu,ul,m),(pl,pu,m,uh)
def accept_pair(obj):
    need(type(obj)is dict and set(obj)=={'schema','row','n','trees'},'exact pair fields')
    need(obj['schema']==SCHEMA,'fixed cover schema')
    index,n=obj['row'],obj['n'];expected=roots(index,n)
    need(type(obj['trees'])is list and len(obj['trees'])==len(expected),'complete count/sign root census')
    stats={'excluded':0,'quartics':0,'splits':0,'maxdepth':0};minimum=None
    def visit(node,k,cell,depth):
        nonlocal minimum
        need(depth<=36 and type(node)is dict,'finite proof tree');stats['maxdepth']=max(stats['maxdepth'],depth)
        if 'split'in node:
            need(set(node)=={'split','children'}and type(node['children'])is list and len(node['children'])==2,'both closed children')
            cc=children(cell,node['split']);stats['splits']+=1
            for ch,sub in zip(node['children'],cc):visit(ch,k,sub,depth+1)
            return
        z=enc.parameters(index,n,k,*cell)
        if set(node)=={'excluded'}:
            need('excluded'in z and node['excluded']==z['excluded'],'recomputed exact exclusion');stats['excluded']+=1;return
        need(set(node)=={'q'}and 'excluded'not in z,'certified quartic leaf')
        margin=leaf_check(z,node['q']);minimum=margin if minimum is None else min(minimum,margin);stats['quartics']+=1
    for record,(k,sign,cell)in zip(obj['trees'],expected):
        need(type(record)is dict and set(record)=={'k','sign','tree'}and type(record['k'])is int and type(record['sign'])is int,'fixed root fields')
        need((record['k'],record['sign'])==(k,sign),'ordered exact count/sign roots')
        visit(record['tree'],k,cell,0)
    return {'status':'PASS_EXACT_COMPLETE_RAW_LEFT_PAIR','row':index,'n':n,**stats,
            'minimum_cleared_loss_coefficient':str(minimum)if minimum is not None else None}
def main():
    import argparse,time
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('output');a=p.parse_args()
    src=Path(a.input);out=Path(a.output);out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    files=sorted(src.glob('pair_*.json'))if src.is_dir()else[src]
    need(files,'nonempty input');results=[];seen=set()
    for f in files:
        obj=json.loads(f.read_text());key=(obj.get('row'),obj.get('n'));need(key not in seen,'unique pairs');seen.add(key)
        r=accept_pair(obj);results.append(r);print(json.dumps(r),flush=True)
    result={'status':'PASS_EXACT_LISTED_RAW_LEFT_PAIRS','scope':'Only the explicitly listed complete pairs; acquisition and analytic reduction are separate obligations.',
      'mathematical_status':'locally derived exact arithmetic certificate at documented analytic boundary',
      'execution_status':'fresh PASS','results':results,'sources':sources(),
      'inputs':{str(f.resolve()):hashlib.sha256(f.read_bytes()).hexdigest()for f in files},'seconds':time.monotonic()-start}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
