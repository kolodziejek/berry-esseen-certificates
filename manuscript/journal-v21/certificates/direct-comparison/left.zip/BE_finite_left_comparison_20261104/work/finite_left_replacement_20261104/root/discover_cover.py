"""Floating search for quartics; exact acceptance is in independent cover.py."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys,time,math,hashlib
import numpy as np
import scipy
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import cover
enc=cover.enc;gate=cover.gate

def propose(z):
    records=gate.affine_gates(**cover.arguments(z));normalizer=float((z['n']*(z['pl']+z['pu'])/2*(1-(z['pl']+z['pu'])/2))**2)
    score=[];rhs=[];seen=set()
    for r in records:
        c=gate.bernstein(r['constant'],z['pl'],z['pu']);a=[gate.bernstein(v,z['pl'],z['pu'])for v in r['linear']]
        for j in range(7):
            exact=(c[j],*(v[j]for v in a))
            if exact in seen:continue
            seen.add(exact);score.append([-float(v[j])/normalizer for v in a]+[1.]);rhs.append(float(c[j])/normalizer)
    u,c,R=map(float,(z['uh'],z['c'],z['R0']));J=8
    def target(x):
        if x<u-J*c:return R*(u-x)/c
        if x>u+1e-10:return -1.
        zz=(u-x)/c
        if abs(zz-round(zz))<1e-9:zz=round(zz)
        return R*max(0,math.floor(zz))
    points=sorted(set(np.linspace(-10,10,51))|{u-j*c for j in range(J+1)}|{0.})
    for iteration in range(50):
        lhs=list(score);bound=list(rhs)
        for x in points:
            scale=max(1.,abs(x)**4);lhs.append([-x**j/scale for j in range(5)]+[0.]);bound.append(-target(x)/scale)
        ans=linprog([0.]*5+[-1.],A_ub=lhs,b_ub=bound,
                    bounds=[(-100,100)]*4+[(.001,100),(-100,100)],method='highs',
                    options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
        if not ans.success:return None,{'reason':'LP','message':ans.message}
        if ans.x[-1]<2e-6:return None,{'reason':'loss','margin':float(ans.x[-1])}
        q=ans.x[:5];der=np.array([j*q[j]for j in range(1,5)]);extra=[]
        for zz in np.polynomial.polynomial.polyroots(der):
            if abs(zz.imag)<1e-7 and zz.real>=u-J*c:
                x=float(zz.real)
                if np.polynomial.polynomial.polyval(x,q)-target(x)<-1e-8*max(1.,abs(x)**4):extra.append(x)
        der[0]+=R/c
        for zz in np.polynomial.polynomial.polyroots(der):
            if abs(zz.imag)<1e-7 and zz.real<u-J*c:
                x=float(zz.real)
                if np.polynomial.polynomial.polyval(x,q)-target(x)<-1e-8*max(1.,abs(x)**4):extra.append(x)
        if extra:points.extend(extra);continue
        rational=[F(round(float(v)*10**10),10**10)for v in q]
        rational[0]+=F(1,10**6);rational[4]+=F(1,10**7)
        try:
            margin=cover.leaf_check(z,rational)
            return list(map(str,rational)),{'margin':str(margin),'LP_margin':float(ans.x[-1]),'iterations':iteration+1}
        except ValueError as e:return None,{'reason':'exact','message':str(e),'LP_margin':float(ans.x[-1]),'q':list(map(str,rational))}
    return None,{'reason':'separation_limit','q':list(map(float,q)),'extra':extra,'LP_margin':float(ans.x[-1])}

def make_pair(index,n,maxdepth,maxnodes):
    stats={'nodes':0,'excluded':0,'quartics':0,'maxdepth':0};failures=[]
    def visit(k,cell,depth):
        stats['nodes']+=1;stats['maxdepth']=max(stats['maxdepth'],depth)
        if stats['nodes']>maxnodes:raise RuntimeError('node budget exhausted')
        z=enc.parameters(index,n,k,*cell)
        if 'excluded'in z:stats['excluded']+=1;return {'excluded':z['excluded']}
        q,info=propose(z)
        if q is not None:stats['quartics']+=1;return {'q':q}
        if depth>=maxdepth:
            failures.append({'k':k,'cell':list(map(str,cell)),'diagnostic':info,'parameters':enc.encode(z)})
            raise RuntimeError('unclosed terminal cell')
        pl,pu,ul,uh=cell;axis='p'if n*(pu-pl)>uh-ul else'u'
        return {'split':axis,'children':[visit(k,ch,depth+1)for ch in cover.children(cell,axis)]}
    obj={'schema':cover.SCHEMA,'row':index,'n':n,'trees':[]}
    try:
        for k,sign,cell in cover.roots(index,n):obj['trees'].append({'k':k,'sign':sign,'tree':visit(k,cell,0)})
        result=cover.accept_pair(obj)
        return obj,{'status':'COMPLETE_EXACTLY_ACCEPTED',**stats,'acceptance':result}
    except RuntimeError as e:return None,{'status':'UNRESOLVED','reason':str(e),**stats,'failures':failures}
def main():
    p=argparse.ArgumentParser();p.add_argument('output');p.add_argument('--rows',default='38');p.add_argument('--ns',default='125')
    p.add_argument('--maxdepth',type=int,default=22);p.add_argument('--maxnodes',type=int,default=10000);a=p.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False);start=time.monotonic();results=[]
    indices=list(range(39))if a.rows=='all'else list(map(int,a.rows.split(',')))
    ns=None if a.ns=='all'else set(map(int,a.ns.split(',')))
    source_before=cover.sources();source_before[str(Path(__file__).relative_to(enc.ROOT))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    for index in indices:
      for n in sorted(n for r,n in enc.GAPMAP if r==index and(ns is None or n in ns)):
        t=time.monotonic();obj,res=make_pair(index,n,a.maxdepth,a.maxnodes)
        res.update(row=index,n=n,seconds=time.monotonic()-t);results.append(res)
        if obj is not None:(out/('pair_%02d_%03d.json'%(index,n))).write_text(json.dumps(obj,separators=(',',':'))+'\n')
        (out/'PROGRESS.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps({k:v for k,v in res.items()if k!='failures'}),flush=True)
        if obj is None:break
    after=cover.sources();after[str(Path(__file__).relative_to(enc.ROOT))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    enc.need(source_before==after,'all arithmetic and discovery sources unchanged during run')
    (out/'RESULT.json').write_text(json.dumps({'results':results,'sources':source_before,'seconds':time.monotonic()-start,
      'runtime':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__},
      'scope':'Only separately saved complete pairs are certified; numerical failures are not mathematical exclusions.'},indent=2)+'\n')
    if any(r['status']!='COMPLETE_EXACTLY_ACCEPTED'for r in results):raise SystemExit(1)
if __name__=='__main__':main()
