"""Capture an isolated package command without writing inside the package.

Usage: python -I -B tools/capture.py /fresh/output relative/script.py ARGS...
The literal {output} in an argument expands to the fresh capture directory.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,time
PACKAGE=Path(__file__).resolve().parents[1]

def need(v,s):
    if not v:raise ValueError(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files():
    result={}
    for p in sorted(PACKAGE.rglob('*')):
        need(not p.is_symlink(),'ordinary package path '+str(p))
        if p.is_file():result[str(p.relative_to(PACKAGE))]={'bytes':p.stat().st_size,'sha256':sha(p)}
    return result

def main():
    need(__debug__ and not sys.flags.optimize,'unoptimized execution')
    out=Path(sys.argv[1]).resolve()
    need(not out.is_relative_to(PACKAGE),'output outside immutable package')
    script=(PACKAGE/sys.argv[2]).resolve()
    need(script.is_relative_to(PACKAGE)and script.is_file(),'selected package script')
    out.mkdir(parents=True,exist_ok=False)
    before=files()
    argv=[sys.executable,'-I','-B',str(script)]+[x.replace('{output}',str(out))for x in sys.argv[3:]]
    start={'command':argv,'cwd':str(PACKAGE),'started_unix':time.time(),
      'python':sys.version,'python_executable':sys.executable,'python_sha256':sha(Path(sys.executable)),
      'package_files_before':before}
    (out/'STARTED.json').write_text(json.dumps(start,indent=2)+'\n')
    with(out/'stdout.txt').open('xb')as stdout,(out/'stderr.txt').open('xb')as stderr:
        child=subprocess.run(argv,cwd=PACKAGE,stdout=stdout,stderr=stderr)
    after=files()
    result={**start,'returncode':child.returncode,'seconds':time.time()-start['started_unix'],
      'package_files_after':after,'package_unchanged':before==after,
      'stdout_sha256':sha(out/'stdout.txt'),'stderr_sha256':sha(out/'stderr.txt')}
    (out/'PROCESS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'returncode':child.returncode,'seconds':result['seconds'],'package_unchanged':before==after,'output':str(out)}))
    need(child.returncode==0 and before==after,'successful child and unchanged package')

if __name__=='__main__':main()
