"""Verify all final package paths, sizes and hashes; not mathematical acceptance."""
from pathlib import Path
import hashlib,json,sys
PACKAGE=Path(__file__).resolve().parents[1]

def need(v,s):
    if not v:raise ValueError(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(text):
    def pairs(xs):
        result={}
        for k,v in xs:
            need(k not in result,'duplicate manifest key');result[k]=v
        return result
    return json.loads(text,object_pairs_hook=pairs)
def tree_sha(records):
    return hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()

def main():
    need(__debug__ and not sys.flags.optimize,'unoptimized execution')
    manifest=PACKAGE/'FILES.json';data=strict(manifest.read_text())
    need(data['schema']=='COMPLETE_RAW_LEFT_PORTABLE_FILES_V1','known inventory schema')
    records=data['files'];need(type(records)is dict and records,'nonempty inventory')
    actual=set()
    for p in PACKAGE.rglob('*'):
        need(not p.is_symlink(),'no package symlink '+str(p))
        if p.is_file():actual.add(str(p.relative_to(PACKAGE)))
    need(actual==set(records)|{'FILES.json'},'exact complete file census')
    for name,record in records.items():
        rel=Path(name)
        need(not rel.is_absolute()and '..'not in rel.parts,'relative manifest path')
        need(type(record)is dict and set(record)=={'bytes','sha256'},'exact file record')
        need(type(record['bytes'])is int and 0<=record['bytes']<100000000,'bounded byte size')
        path=PACKAGE/rel
        need(path.stat().st_size==record['bytes']and sha(path)==record['sha256'],'exact file identity '+name)
    need(tree_sha(records)==data['tree_sha256'],'canonical file-map tree digest')
    result={'status':'PASS_COMPLETE_PACKAGE_BYTE_INTEGRITY','files':len(records)+1,
      'inventoried_files':len(records),'inventoried_bytes':sum(x['bytes']for x in records.values()),
      'manifest_sha256':sha(manifest),'tree_sha256':data['tree_sha256'],
      'mathematical_acceptance_claimed':False}
    if len(sys.argv)==2:
        out=Path(sys.argv[1]).resolve();need(not out.is_relative_to(PACKAGE),'external output only')
        out.mkdir(parents=True,exist_ok=False)
        (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
