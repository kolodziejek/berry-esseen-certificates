"""Portable bounded controls: actual pair, semantic mutations and source pins."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,importlib.util,json,subprocess,sys
PACKAGE=Path(__file__).resolve().parents[1]
TREE=PACKAGE/'work/finite_left_replacement_20261104'

def need(v,s):
    if not v:raise ValueError(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
def selected(obj,kind):
    def descend(node):
        if kind in node:return node
        for child in node.get('children',[]):
            found=descend(child)
            if found is not None:return found
        return None
    for root in obj['trees']:
        found=descend(root['tree'])
        if found is not None:return found
    raise ValueError('selected fixture lacks '+kind)

def main():
    need(__debug__ and not sys.flags.optimize,'unoptimized controls')
    out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
    cover=load('portable_strong_cover_controls',TREE/'root/cover_strong.py')
    collector=load('portable_complete_controls',TREE/'audit/complete_strong_campaign.py')
    before=collector.source_pins()
    files=list(PACKAGE.glob('runs/finite_left_replacement_20261104/root_strong_shard*_01/objects/pair_38_125.json'))
    need(len(files)==1,'unique fixed actual completed pair')
    path=files[0];obj=collector.strict_json(path.read_text())
    baseline=cover.accept_pair(obj)
    need(baseline['row']==38 and baseline['n']==125 and baseline['quartics']>0,'actual positive continuous-pair control')
    rejections=[]
    def reject(name,change):
        bad=copy.deepcopy(obj);change(bad)
        try:cover.accept_pair(bad)
        except (ValueError,KeyError,TypeError):rejections.append(name)
        else:raise AssertionError('accepted invalid object '+name)
    reject('wrong_schema',lambda x:x.update(schema='changed'))
    reject('missing_count_sign_root',lambda x:x['trees'].pop())
    reject('duplicate_count_sign_root',lambda x:x['trees'].append(copy.deepcopy(x['trees'][0])))
    reject('reordered_count_sign_roots',lambda x:x['trees'].reverse())
    reject('missing_closed_child',lambda x:selected(x,'split')['children'].pop())
    reject('unknown_partition_axis',lambda x:selected(x,'split').update(split='lambda'))
    def false_exclusion(x):
        node=selected(x,'q');node.clear();node['excluded']='strict_resource'
    reject('quartic_replaced_by_unproved_exclusion',false_exclusion)
    reject('zero_quartic',lambda x:selected(x,'q').update(q=['0']*5))
    reject('global_payoff_failure',lambda x:selected(x,'q')['q'].__setitem__(0,str(F(selected(x,'q')['q'][0])-1000)))
    reject('floating_coefficient',lambda x:selected(x,'q')['q'].__setitem__(0,0.0))
    reject('boolean_coefficient',lambda x:selected(x,'q')['q'].__setitem__(0,False))
    reject('missing_count_identity',lambda x:x['trees'][0].pop('k'))
    reject('boolean_phase_sign',lambda x:x['trees'][0].update(sign=False))
    reject('boolean_n',lambda x:x.update(n=True))
    reject('out_of_scope_row',lambda x:x.update(row=39))
    for name,text in [('duplicate_json_key','{"row":38,"row":37}'),('nonfinite_json_number','{"row":NaN}')]:
        try:collector.strict_json(text)
        except ValueError:rejections.append(name)
        else:raise AssertionError('accepted '+name)
    records,missing,extra=collector.inspect([path])
    need(len(records)==1 and len(missing)==3384 and not extra,'single accepted pair is not whole campaign')
    try:collector.inspect([path,path])
    except ValueError:rejections.append('duplicate_whole_pair_file')
    else:raise AssertionError('duplicate complete pair admitted')

    # Only disposable copies are corrupted. This invokes the real pinned
    # import chain in a fresh interpreter, so import caches cannot mask it.
    fixture=out/'source-pin-fixture';fixture.mkdir()
    for name in ['quartic_gate.py','quartic_gate24.py','shifted_quartic_gate.py','shifted_quartic_fast.py']:
        (fixture/name).write_bytes((TREE/'construction'/name).read_bytes())
    with(fixture/'quartic_gate.py').open('ab')as f:f.write(b'\n# intentional source-pin corruption\n')
    driver=fixture/'import_control.py'
    driver.write_text('from pathlib import Path\nimport sys\nsys.path.insert(0,str(Path(__file__).resolve().parent))\nimport shifted_quartic_fast\n')
    argv=[sys.executable,'-I','-B',str(driver)]
    child=subprocess.run(argv,cwd=fixture,capture_output=True)
    (fixture/'stdout.txt').write_bytes(child.stdout);(fixture/'stderr.txt').write_bytes(child.stderr)
    need(child.returncode!=0 and b'fixed univariate algebra dependency' in child.stderr,'source substitution rejected by actual import chain')
    (fixture/'PROCESS.json').write_text(json.dumps({'command':argv,'returncode':child.returncode,
        'stdout_sha256':sha(fixture/'stdout.txt'),'stderr_sha256':sha(fixture/'stderr.txt')},indent=2)+'\n')
    rejections.append('modified_pinned_kernel_import')
    need(before==collector.source_pins(),'complete source closure unchanged')
    result={'status':'PASS_PORTABLE_RAW_LEFT_COMPARISON_CONTROLS','positive_pair':baseline,
      'positive_object_sha256':sha(path),'rejected_mutations':rejections,
      'missing_pairs_detected_from_single_file':len(missing),
      'source_before':before,'source_after':collector.source_pins(),
      'scope':'Bounded controls of the actual continuous-pair reader, complete-census rejection and source-pin import; full3385 arithmetic replay is separate.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'rejections':len(rejections)}))

if __name__=='__main__':main()
