# Independent review of the inward/variance noise cap

Mathematical status: locally derived and checked necessary condition for an
already acquired counterexample, with the same law and resources as the raw
left row. Execution status: fresh exact controls passed. This is not an
acquisition proof or a complete finite noisy comparison.

Reviewed `root/enclosures_strong.py`, SHA-256
`18ccaff376405a4873ed3779f588453f8db916040c48298117f7ddeed0420332`,
in full against the original `enclosures.py`, SHA-256
`38bd4b07a5c7d93cf676020ae55d28f697a76a9c46c0ee6b80086253c8f1c10b`.
The only mathematical addition is the retained inward resource below.
The existing signed Gaussian, mass, cubic-price and phase-resource arguments
remain those reviewed in `ENCLOSURES_REVIEW.md`.

## Uniform implication

Let the same centered conditional noises obey
`U0 in [-A0,a0]`, `U1 in [-a1,A1]`, with nonnegative endpoints and
`a0+a1=d<=d0`. Put `s0=E U0^2`, `s1=E U1^2`,
`s=(1-p)s0+p s1`, `lambda=n s`, `v=p(1-p)`.
Integrating `(U0+A0)(a0-U0)>=0` and
`(U1+a1)(A1-U1)>=0` gives

```
s0 <= A0*a0,  s1 <= A1*a1,
s <= (1-p)A0*a0+p A1*a1 <= M d,
M >= max((1-p)A0,p A1).
```

This includes zero inward endpoints: centering and one-sided support then
force the corresponding conditional variance to vanish. It neither divides
by an inward endpoint nor assigns unrelated laws to different counts.

The already established joint-defect bound gives

```
E >= alpha*n*d + beta*n*lambda/(n*v+lambda),
E = min(47*row.D,Bmax/kappa)-n*P0,
alpha>0, beta>0.
```

Here `P0<=D_B(p)` and the row supplies `theta<=Theta`, `d<=d0`;
one may choose
`alpha<=6(1-Theta)*sqrt((1-Theta)/vmax)*(1-d0)`.
The code rounds this expression down. It follows that

```
E >= lambda * [alpha/M + beta*n/(n*vmax+Uold)]
```

whenever `0<=lambda<=Uold` and `v<=vmax`. Every term in the bracket is
nonnegative, and the bracket is strictly positive. Dividing by it therefore
gives a valid upper bound on lambda. The code rounds this upper bound up
and intersects it with the prior cap and the older noise-only upper bound.

On the whole probability cell `[pl,pu]`,
`A0>=3*sqrt(vmax+Uold/n)-pl` and
`A1>=3*sqrt(vmax+Uold/n)-(1-pu)` follow from raw `|X|<=3`.
The chosen `M>=max((1-pl)A0,pu A1)` is therefore outward. The dependence on
the old cap is legitimate: each iteration starts with a proved superset,
and the next one remains a proved superset. Sixteen iterations need not
converge; stopping early only weakens the conclusion. Empty signed-H
intersection and the original strict resource exclusion remain separate
valid branches. No refined support/confinement premise is introduced.

The resource is available only at the acquired counterexample boundary
`C>=C_E`, with its sign license and common Fourier budget. In particular,
`C>=.4` alone does not supply it.

## Fresh exact controls

`runs/finite_left_replacement_20261104/construction_strong_resource01/`
records actual return code zero, full streams and unchanged source hashes.
`check_strong_resource.py` checks 3,159 rational centered conditional-law
pairs, including zero noise, two-point boundary support and a zero-atom
mixture. It checks the integrated support identity, the one shared inward
budget, and the resulting outward noise cap exactly.

The same run reads all 176 original n=47 row/count/phase resource cells;
111 caps strictly improve, and every comparable new cap is no larger.
This is a numerical property of those cell bounds, not a new proof that
the cells contain an attained law. Six deliberately invalid substitutions
are refuted by exact saturated-support witnesses: minimum instead of
maximum, an incorrect probability weight, a smaller variance denominator,
an unproved smaller noise ceiling, an extra factor n in inward pricing,
and dropping the outward support endpoint from the variance bound.

No defect was found in the reviewed stronger cap. The all-pair quartic
campaign and its complete final reader remain separate obligations.
