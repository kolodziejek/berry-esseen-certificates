# Global quartic staircase majorants

`quartic_global.py` certifies one algebraic statement. It does not assert any
moment enclosure, conditional-law coupling, or score comparison.

Let c>0, R>=0, upper phase b real, J>=1 integer. For a quartic q with ascending
rational coefficients, q4>=0 makes q'' convex on the entire real line. Define

`psi(w,u)=-1{w>u}+R max(0,floor((u-w)/c))`.

This is nondecreasing in u for every w, including u=w. It is enough to
majorize psi(w,b). The following finite family suffices:

* `q(w)+1>=0` on the closed right ray `[b,infinity)`;
* `q(w)-R j>=0` on `[b-(j+1)c,b-jc]`, j=0,...,J-1;
* `q(w)-R(b-w)/c>=0` on the left ray `(-infinity,b-Jc]`.

At a staircase knot `w=b-jc`, j>=1, the interval with index j supplies the
higher value Rj. At j=J the left-ray condition supplies RJ. The j0 interval
supplies q(b)>=0, so the closed threshold event has the correct value, despite
the weaker right-ray condition q(b)>=-1. In the interior of a finite interval
floor((b-w)/c)=j. On the left ray, floor((b-w)/c)<=(b-w)/c. These statements
prove the global majorization and include all atoms. For u<=b, monotonicity
then gives q(w)>=psi(w,u).

Each finite interval is mapped affinely to [0,1]. For the right ray write
w=b+s, and for the left ray w=b-Jc-s, s>=0. For either resulting quartic
P(s), define the polynomial

`Pcompact(t)=(1-t)^4 P(t/(1-t))`, 0<=t<=1.

Nonnegativity on the compact interval implies P(s)>=0 for every finite
s>=0 because 1-t>0 there. Nonnegativity at t=1 is a stronger limiting
condition, never an omitted ray endpoint. The mapping preserves all terms,
including the left-ray linear envelope `R(J+s/c)`.

The discovery routine converts the four-degree power polynomial to Bernstein
coefficients and recursively bisects a cell with a negative coefficient.
Its finite depth/node ceilings only limit discovery: exceeding either fails.
A proposed leaf records its binary dyadic path and five exact coefficients.

The acceptance routine does not trust the forward conversion. It expands
`sum b_j binom(4,j)t^j(1-t)^(4-j)` by exact polynomial multiplication and
compares all five power coefficients with the independently restricted
fixed target. Nonnegative b_j and the Bernstein partition of unity then
prove the polynomial nonnegative on that leaf. The ordered-prefix checker
requires both children of every split, no omitted/duplicate/overlapping
leaf, and full coverage of [0,1]. Target names, count, parameters and both
rays are fixed externally by the caller, not supplied by the object alone.

API:

```
obj = build(q, phase_upper, c, R0, J=8, maxdepth=22, maxnodes=200000)
receipt = accept(obj, q, phase_upper, c, R0, J=8)
```

All scalar arguments are exact integers, Fraction values or rational strings;
float and boolean coefficient representations reject. The proof object is
JSON-safe. The checker does not add padding or alter q. Any rational padding
must be made by the caller, recorded in q, and included in its expectation
bound. Similarly, choosing J changes only the sufficient positivity cover,
not the staircase being majorized.

Fresh controls include a positive quartic, a positive quadratic requiring an
actual dyadic subdivision, the zero polynomial at R=0, missing and malformed
rays/steps/coefficients, and a cubic with q4=0,q3>0 that fails on the far left.
The latter cannot be rescued by sampled positivity on a finite w grid.
117 exact atom and immediate-neighbor evaluations supplement the global
proof; they are not used in place of it.
