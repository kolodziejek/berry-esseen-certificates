# A compact exact certificate for the same global quartic target

`quartic_sturm.py` is an alternative acceptor for the identical algebraic
staircase-majorization target documented in `QUARTIC_SOUNDNESS.md`. It imports
the frozen fixed-target construction from `quartic_global.py` only after
checking its SHA-256. It does not trust a proposed Sturm sequence: every
sequence and exact polynomial division is recomputed. The proof data can
therefore be just the five rational coefficients of q. Cell parameters remain
external, fixed theorem inputs and must be bound by the caller.

For each fixed compact polynomial P of degree at most4, the checker requires
P(0)>0 and P(1)>0. A positive constant accepts immediately. Otherwise form

`P0=P`, `P1=P'`, `P_(j+1)=-remainder(P_(j-1),P_j)`.

All arithmetic is over rational coefficients, and leading zero coefficients
are stripped. Euclidean division strictly decreases degrees. The last
nonzero polynomial is required to be constant; this is a conservative
squarefreeness check. In particular an interior even root rejects, while a
strictly positive polynomial with a repeated complex root may also reject.
Such a rejection is failure of this sufficient certificate, not evidence
that the proposed majorant is false.

For each endpoint x, evaluate the sequence exactly, omit zeros, and let V(x)
be the number of changes of sign. Acceptance requires V(0)=V(1). Here is the
root-count justification, including the endpoint-zero convention for
intermediate sequence entries.

* Adjacent members have no common root, because the Euclidean recurrence
  would propagate one to the final nonzero constant. At a zero r of an
  intermediate member P_j, its neighbors satisfy
  `P_(j-1)(r)=-P_(j+1)(r)`. Their signs are opposite and nonzero. The total
  number of variations across this three-term block is therefore one on
  either side of r, and also one when the middle zero is omitted.
* Roots of P are simple: otherwise P and P' would have a common factor and
  the Euclidean sequence could not end in a nonzero constant. At a real
  root r of P, `P(x)=P'(r)(x-r)+o(x-r)` and P'(r) is nonzero. The first pair
  in the sequence changes from opposite signs just to the left to equal
  signs just to the right. Its variation drops by exactly one; all later
  changes are unaffected by this first root. Any simultaneous zero of a
  nonadjacent sequence entry preserves variation by the previous bullet.
* Between roots no evaluated sign changes. Thus V(0)-V(1) equals the number
  of distinct real roots of P in (0,1). P itself has no endpoint roots by
  the strict endpoint checks. Zeros of intermediate entries at0 or1 can be
  omitted by the opposite-neighbor argument above.

Consequently equal endpoint variations prove there is no zero of P on the
closed interval. Continuity and P(0)>0 prove P>0 throughout. Applying this to
all finite staircase intervals and both compactified rays proves the same
global majorization as the Bernstein acceptor. There is no sampled root
search, numerical tolerance, root approximation, or unverified claim about
a floating LP solution.

The strict test deliberately rejects compact-ray endpoint zeros. The caller
may choose a small positive q4 padding during discovery, but the exact
padded q must then be included in the moment expectation and score test.
Neither this acceptor nor the Bernstein acceptor modifies q. Positive q4
alone does not establish the other target inequalities: every target still
passes its own endpoint and Sturm checks.

Controls cover: positive constant/linear/quadratic/quartic polynomials,
a very small positive gap around an approximate double root, two and four
interior roots, an even interior zero, either endpoint zero, a negative
endpoint, conservative rejection of repeated complex roots, negative q4,
and the wrong far-left cubic sign with q4=0. Two full staircase certificates
also pass the independent inverse-Bernstein checker, including a genuinely
subdivided finite interval. These controls supplement the proof above.

API:

```
receipt = quartic_sturm.accept(q, phase_upper, c, R0, J=8)
```

q has five ascending exact rational coefficients. The returned receipt is a
summary, not an independently authoritative proof object: reproduce it by
running the checker on the exact q and the same bound cell parameters.
The return value expressly makes no probabilistic claim. The common-marginal
moment and score reduction must be proved and checked separately.
