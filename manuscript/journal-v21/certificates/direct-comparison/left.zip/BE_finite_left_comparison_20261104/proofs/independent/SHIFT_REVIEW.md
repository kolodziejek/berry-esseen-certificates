# Independent review of translated quartics and the exact fast reader

Mathematical status: locally derived conditional comparison rule with all
acquisition premises retained. Execution status: fresh complete hard-pair
PASS plus independent algebra, ray, tensor and malformed-object controls.
The full3,385-pair campaign was still running at this checkpoint; no result
for that entire campaign is claimed here.

## Why translation helps without changing the claim

The all-count coupling supplies the pointwise upper bound
`psi(W,u)=-1{W>u}+R0 floor((u-W)/c)_+`, where `c=1-d0>0`.
Writing Z=W-u gives the exact identity `psi(W,u)=psi(Z,0)`. A single global
quartic Q majorizing the fixed phase-zero staircase therefore works as
Q(W-u) on a whole phase interval. This is stronger than replacing u by the
upper endpoint before constructing a polynomial in W. It retains the exact
atom value at Z=0 and all negative staircase knots. The same conditional
marginal still supplies every moment and score term.

For a quartic, expand

`E Q(W-u)=q0-q1*u+q2*(t+u^2)`
` +q3*(S3-3*u*t-u^3)`
` +q4*(E W^4-4*u*S3+6*u^2*t+u^4)`.

For each fixed u the translated quartic retains leading coefficient q4>=0.
The proved inward-support moment and lambda concavity reductions therefore
remain valid without alteration. The implementation conservatively retains
all six moment corners and24 scalar endpoint choices. The positive phase
coefficient is a lower coefficient on u>=0 and an upper coefficient on u<=0;
multiplying by a negative phase reverses the required bound exactly as used.
After positive denominator clearing, each score gate is a polynomial of
bidegree at most(6,4) in p,u. Tensor Bernstein nonnegativity on the entire
closed rectangle proves the continuous gate; no phase sampling is used.

The inherited premises still include the same-law central gap, radius3,
weighted defect, signed resource budget with nonnegative excess C-CE, and
all raw table bounds. The new calculation does not acquire these premises
and does not use any subsequent noise-confinement strip.

## Source review

Read the full `shifted_quartic_gate.py`, `cover_shift.py`, `discover_shift.py`,
`shifted_quartic_fast.py`, `cover_fast.py` and `complete_shift_campaign.py`,
including their pinned original algebra/global-quartic dependencies.
The shifted gate expands every monomial, including the phase contribution
from q1 despite E W=0. Its scalar coefficient mapping and tensor degree are
correct. The exact reader reconstructs every p/phase cell from full binary
coverage and each licensed count root. Its global Sturm check is applied
at phase zero, which is precisely the translated target.

The fast transform changes only computation of the tensor coefficients.
For a monomial p^i*u^j, its tensor Bernstein coefficients are the outer
product of the two corresponding univariate degree-elevated coefficient
vectors. Exact linearity then gives the complete polynomial transform.
The cached keys include all rational coefficients, both intervals and both
degrees; cached results are immutable tuples. The original gate construction
is imported only after checking its module path and source hash. The cache
therefore does not omit a mathematical parameter or change a target.

The discovery driver uses floating LP only to propose five coefficients.
Every rationalized candidate passes the independent exact global and tensor
checks. The source snapshot includes both the delegated discovery driver and
the shifted proposer; no solver success is treated as a proof.

The aggregate reader fixes the exact set of3,385 expected row/index keys
from the independently checked, pinned Bernoulli gap data. Missing,
duplicate or extraneous pairs reject before any completeness assertion.
It then replays every complete shifted pair through the fast exact reader.
The source closure includes all original, shifted and fast modules plus
both raw/gap inputs. Proof objects and sources are checked before and after
readback. Strict JSON parsing rejects duplicate object keys at all nesting
levels and nonfinite JSON numbers. The `inventory-only` mode deliberately
claims only a byte census, not mathematical acceptance.

## Fresh evidence

* `audit_pair38_125_01`:complete original unshifted hard-pair replay,
  4,200 quartics,4,199 splits,3 excluded leaves, actual rc0 in29.958s.
  Nine selected quartics independently pass full inverse-Bernstein global
  majorization,216 inverse score-polynomial reconstructions and9 corruptions.
* `audit_shift_pair38_125_01`:the same full acquired hard pair accepts with
  15 translated quartics,12 splits,1 exclusion, actual rc0 in1.832s.
  Five deterministic witnesses pass the separate Bernstein global checker;
  120 bivariate inverse reconstructions and4,200 exact shifted-expectation
  identities agree. Six real-object corruptions reject. Source/input hashes
  are unchanged. These are complete continuous-domain pair certificates,
  not grid observations.
* `audit_fast_join01`:the original and fast exact readers give identical
  complete-pair results. All360 tensor polynomials of its15 witnesses have
  identical35 rational Bernstein coefficients under both transforms.
  Sixteen malformed-source/schema/duplicate-key/duplicate-pair controls
  reject. The partial pair list correctly leaves3,384 missing pairs.
* `audit_shift_source_closure01`:all13 explicit aggregate source files cover
  every dependency declared by the actual fast reader. The frozen aggregate
  SHA is `92e31b6ddf56cedb8c194460ba173308f159acbde9499e2177b1f3cb63a72e49`.
* `audit_shift_campaign_missing01`:the actual aggregate command returns1
  for the single completed pilot, writes the3,384 missing-pair inventory,
  and writes no acceptance RESULT. This successful rejection is not a
  failed mathematical comparison.

All these captures are under `runs/finite_left_replacement_20261104/`.
No manuscript source was modified in this audit. A complete aggregate PASS
and the independent analytic acquisition join remain separate obligations
before replacing the old full left-range proof.
