# Independent derivation of the six moment corners and24 scalar gates

This is a conditional analytic reduction for the direct sharp-score slack,
not a completed finite-left comparison. No Poisson comparison is needed.
The quartic, scalar enclosure constants and probability cell must be fixed
independently of every eliminated moment variable.

Write q for the quartic polynomial (q0,...,q4), with q4>=0. To avoid confusing
this notation with probability, write r=1-p here. The actual centered
conditional noises have support

`-A0 <= U0 <= a0`, `-a1 <= U1 <= A1`,
`a0,a1>=0`, `a0+a1<=d0`.

Their variances are s0,s1, and third-moment ratios are gamma0,gamma1 whenever
the variances are positive. The identities at zero variance use any value
in the respective interval, since every product with that variance is zero.
Weighting the support inequality by U_i^2 shows

`-A0<=gamma0<=a0`, `-a1<=gamma1<=A1`.

Nonnegativity of `(U0+A0)(a0-U0)U0^2` and
`(U1+a1)(A1-U1)U1^2` gives

`m40 <= (a0-A0)m30+A0*a0*s0`,
`m41 <= (A1-a1)m31+A1*a1*s1`.

For the actual sum of n-k copies of U0 and k copies of U1, independence and
centering give

`t=(n-k)s0+k*s1`, `S3=(n-k)m30+k*m31`,
`E W^4=sum m4+3t^2-3 sum s_i^2`.

Drop the final nonpositive term before multiplying by q4>=0. Thus the
expectation of the quartic is bounded by its exact lower moments plus the
displayed asymmetric fourth-moment bound. Both conditional laws remain the
same as those defining the variance, skew and original score repair.

Let lambda=n(r*s0+p*s1), and for lambda>0 let alpha=n*p*s1/lambda.
Then s0=lambda*(1-alpha)/(n*r), s1=lambda*alpha/(n*p), and 0<=alpha<=1.
In the sharp-score lower bound the cubic correction uses

`G=3p*(1-alpha)+3r*alpha+alpha*gamma1-(1-alpha)*gamma0`.

Fix p,lambda,b>=0,a0,a1,gamma0,gamma1, where b is the binomial mass factor.
All terms in the lower score bound are affine in alpha except
`-3*b*q4*t^2`. Therefore the score lower bound is concave in alpha.
Its minimum over [0,1] is attained at an endpoint. This considers an enlarged
necessary moment domain; it does not assert that either endpoint is a
realizable nondegenerate common marginal.

At alpha=0 all terms from side1 disappear. The remaining expression is
affine in gamma0, so its lower bound is attained at gamma0=-A0 or gamma0=a0.
For the outward choice the fourth-moment coefficient is

`(a0-A0)*(-A0)+A0*a0=A0^2`,

which no longer depends on a0. For the inward choice it is

`(a0-A0)*a0+A0*a0=a0^2`.

The entire remaining score lower bound is then concave in a0: its only
quadratic term is `-b*q4*t*a0^2`, and every other a0 term is affine. Since
t>=0, its minimum over the enlarged interval [0,d0] occurs at0 or d0.
At this point the actual simplex restriction a0+a1<=d0 projects precisely
to the surviving a0 interval; no coupled variable still appears.

At alpha=1 the argument is the same. The surviving endpoints gamma1=A1 and
gamma1=-a1 produce fourth coefficients A1^2 and a1^2. The inward case is
concave in a1 and endpoints0,d0 suffice. The full moment list is therefore

| side | surviving gamma | fourth coefficient B4 | t/lambda |
|---|---|---|---|
|0| -A0 | A0^2 | (n-k)/(n*(1-p)) |
|0| 0 | 0 | (n-k)/(n*(1-p)) |
|0| d0 | d0^2 | (n-k)/(n*(1-p)) |
|1| A1 | A1^2 | k/(n*p) |
|1| 0 | 0 | k/(n*p) |
|1| -d0 | d0^2 | k/(n*p) |

At each corner the quartic expectation upper bound is

`q0 + lambda*V*(q2+q3*gamma+q4*B4) + 3*q4*lambda^2*V^2`.

In the score lower bound, its lambda-square coefficient is

`-c_gain*3*(1-2p(1-p))/(8*p(1-p)*n^2) - 3*b*q4*V^2 <=0`,

assuming c_gain>=0 and p<1/2. Hence two **constant**, proved lambda endpoints
suffice. The expression is affine in b, so its two nonnegative endpoint
values suffice too. This gives6*2*2=24 rational lower-bound gates. Clearing
by `(n*p*(1-p))^2>0` makes each a polynomial of degree at most6 in p when
all other enclosure constants and endpoint values are fixed rational inputs.

The lambda=0 case is covered by the continuous formulas directly: all
conditional noises vanish, t=S3=0, and every corner yields the same noise
terms. Atoms in the probability comparison are a separate obligation handled
by the global staircase majorant, whose exact closed-event convention must
remain unchanged.

This reasoning fails if b<0, q4<0, the scalar enclosure constants depend on
eliminated moment variables, or the score gain coefficient is lowered before
its multiplying bracket is known nonnegative. Those are explicit gates,
not conventions. Retaining the negative `-3 sum s_i^2` can change alpha
curvature; this24-corner argument deliberately does not retain it.

## Further exact simplification: the two zero corners are redundant

The preceding24-gate argument is valid but not minimal. After carrying out
its endpoint reductions, the three side0 corner values are evaluations of
one concave quadratic in gamma, at gamma=-A0,0,d0, with fourth coefficient
gamma^2. Its quadratic term is `-b*q4*t*gamma^2`; every other gamma term is
affine. Thus the value at0 is at least the lesser value at -A0 and d0.
The analogous side1 interval is [-d0,A1]. The zero corners can therefore be
removed, leaving four moment corners and16 lambda/mass endpoint gates.

This final observation is made **after** the six-corner proof. It is not a
claim that an actual centered variable satisfies
`E U^4 <= (E U^3/E U^2)^2 E U^2`; that statement generally has the opposite
Cauchy--Schwarz direction. The reduced corners are sufficient minima of the
proved relaxation, not pointwise fourth-moment estimates for actual laws.

The original common-support four-corner formula remains valid but is weaker:
its fourth coefficient was `A0*A1+(A1-A0)*gamma`. The stronger reduced
formula uses gamma^2 only at the endpoint corners just justified above.
