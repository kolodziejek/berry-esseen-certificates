# Independent derivation and review of the stronger resource bound

This is an additive strengthening from the original acquired hypotheses.
The sharp-score target, probability domain, moment assumptions and same-law
requirements are unchanged. The older enclosures and all unsuccessful
campaign records are preserved. A discovery failure in an older enclosure
was not evidence of a false acceptance or a counterexample.

Let d=a0+a1<=d0, v=p(1-p), theta<=Theta, ell^2=(1-theta)/v,
and s=(1-p)Var(U0)+p Var(U1), lambda=n*s. The existing joint-defect identity
already gives its Bernoulli, inward and noise contributions simultaneously:

`D >= P_B(p)*(1-theta)^(3/2)`
`     +6*ell*(1-theta)*(d*(1-d)+a0*a1) + b*theta`,

where b is a lower bound for the two signed noise prices. The independent
nonnegative summands in this one inequality are not separate budgets to be
spent twice. Retaining all of them gives a stronger bound than dropping the
inward term.

For p in[pl,pu], set vmax=pu*(1-pu). With the existing positive lower P0 for
P_B(p), convexity of (1-theta)^(3/2) yields

`D >= P0 + (b-3*P0/2)*theta + I*d`,

where any positive rational

`I <= 6*(1-Theta)*sqrt((1-Theta)/vmax)*(1-d0)`

is valid. Indeed d(1-d)+a0*a1 >= (1-d0)d, ell*(1-theta)
is at least (1-Theta)*sqrt((1-Theta)/vmax), and all factors have their
required nonnegative signs. The code rounds I and beta=b-3P0/2 down and
checks positivity. This derivation also holds at theta=0 or d=0.

At a current proved upper cap lambda<=Lambda_old, the original radius3
support gives

`U0 in[-A0,a0]`, `U1 in[-a1,A1]`,

with the code's outward-rounded A0,A1. Centering and the nonnegative
polynomials `(U0+A0)(a0-U0)` and `(U1+a1)(A1-U1)` prove

`Var(U0)<=A0*a0`, `Var(U1)<=A1*a1`.

Thus

`s <= (1-p)*A0*a0+p*A1*a1 <= M*d`,

where `M>=max((1-pl)A0,pu*A1)>0`. Consequently
`n*I*d >= I*lambda/M`. Separately,

`n*beta*theta = n*beta*lambda/(n*v+lambda)`
`             >= n*beta*lambda/(n*vmax+Lambda_old)`.

Let E be the remaining common nD budget after subtracting nP0, exactly as
in the prior reader. The two inequalities combined in the same joint budget
therefore imply

`lambda <= E / [I/M + beta*n/(n*vmax+Lambda_old)]`.

Every denominator is positive. E<0 is an exclusion, not an input to the
fraction. The code keeps the previous cap and the previous noise-only
upper bound, then takes their minimum with an upward rounding of this new
fraction. Each update preserves all actual witnesses admitted by the old
cap; no convergence assumption is required for a fixed16 iterations.
The support bounds used to obtain M are justified by the cap before that
update. They are recomputed at the next iteration only after its stronger
cap is established, avoiding a circular support argument.

The statement `Var(Ui)<=Ai*ai` is valid for both skew signs and remains valid
when ai=0: centering then forces that conditional variable to be zero. It
uses the original radius3 support and inward endpoints, not a later .55
strip or a conditional-noise confinement certificate.

Read the full new `enclosures_strong.py`, `cover_strong.py` and
`discover_strong.py`. The exact changed resource code implements precisely
these formulas. The current cover differs from the prior fast cover only
by using this stronger enclosure module and recording it in source maps;
all event conventions, translated quartics, tensor gates, closed covers and
sharp-score tests are retained. The discovery route still requires exact
acceptance of every rationalized candidate.

`complete_strong_campaign.py` is an additive collector. It uses the strong
reader with the same exact3,385-key expected set and strict duplicate-key
JSON loader. Its explicit17-source snapshot covers every strong reader
dependency and the strong discovery/driver sources. It preserves all old
collectors. Its SHA is
`95b9be405194d50e6437f9ce36c83032a8d63eaa7bde67072cbb9baadf043b65`.
A complete aggregate acceptance is still required before claiming that the
new route covers every acquired left-range case.

Fresh independent evidence is in `audit_strong_pilot01`: actual rc0 in1.724s,
all16 complete pilot pairs replayed, including all four cases unclosed by
the previous campaign. Sixty-four exact rational combined-budget controls
include zero inward endpoints and zero noise;62 noisy pilot cells have a
strong cap no larger than their old cap and pass an independent squared
check of the inward-price lower bound. Eight altered-object, duplicate-pair
and strict-JSON controls reject. All source and input hashes remain stable.

The actual aggregate negative control is `audit_strong_campaign_missing01`:
its invocation on only these16 pairs correctly returns1, records3,369 missing
pairs and writes no acceptance RESULT. The full strong campaign remains a
separate ongoing computation at this checkpoint.
