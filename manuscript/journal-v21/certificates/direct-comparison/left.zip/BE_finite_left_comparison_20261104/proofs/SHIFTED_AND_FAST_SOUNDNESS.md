# Translated quartics and the exact fast tensor transform

The earlier `API24.md` proves the same-law twenty-four-corner reduction.
This note explains the two subsequent changes without enlarging its scope.

## Keep phase inside the polynomial

Fix a quartic `Q(z)=sum(h=0..4) q_h*z^h`, with `q4>0`. The all-real
majorant is checked at phase zero. Substituting `z=W-u` gives the exact
same payoff bound at phase u, including all jump endpoints. As a polynomial
in W its coefficients are

`r_j(u)=sum(h=j..4) binom(h,j)*q_h*(-u)^(h-j)`.

The leading coefficient remains the constant q4. Consequently the previous
concavity in the variance split, inward endpoint, and lambda holds for
every fixed u. The exact scalar phase lower bound is retained as `f*u`:
for u>=0, f is a lower density divided by an upper square root; for u<=0,
f is an upper density divided by a lower square root. The cell must be
split at zero. The fixed variance, support and cubic-price constants apply
on the whole cell. Multiplying the resulting loss by `(n*p*(1-p))^2`
gives a polynomial of bidegree at most (6,4) in p and u.

The checker constructs this polynomial independently of candidate claims.
It verifies all tensor Bernstein coefficients are strictly positive on
the closed p/u rectangle. Bernstein basis functions are nonnegative and
sum to one, so this proves strict positivity throughout that rectangle,
not just at selected phases. All twenty-four corner polynomials are
checked. A proof object supplies only the quartic coefficients and the
finite subdivision tree, whose root census and both children are checked.

## Faster arithmetic, identical polynomial

For a univariate monomial x^r on `[a,b]`, write x=a+(b-a)t. Its power
coefficient of t^s is `binom(r,s)*a^(r-s)*(b-a)^s`. Its Bernstein
coefficient of degree d and index i is therefore

`sum(s=0..min(r,i)) binom(r,s)*a^(r-s)*(b-a)^s*binom(i,s)/binom(d,s)`.

For a bivariate monomial p^r*u^s, the tensor coefficient is the product
of these two univariate coefficients. Exact linearity gives the transform
of any input tensor. `shifted_quartic_fast.py` uses precisely this formula,
with bounded caches of immutable rational tuples. It changes no target,
subdivision, corner, or positivity test. Cache eviction discards only a
reusable value; recomputation uses the same formula.

The original exact kernel is retained and hash-pinned. Fresh controls in
`construction_shifted_fast_controls01` compare 8,400 randomized exact
coefficients and independently reconstruct 240 tensor polynomials. They
also compare all 2,520 affine/final tensors (88,200 coefficients) from the
completed fifteen-quartic row38,n125 pilot. All values agree exactly.
Bounded-cache eviction preserves equality, and four invalid-domain
controls reject. Earlier translated-kernel controls additionally check
1,080 direct formula identities and 1,080 independent tensor expansions.
These tests support the implementation; the displayed algebra is the
uniform mathematical justification.

Neither transform equality nor a pilot establishes the full finite range.
That requires the complete all-pair reader, fixed input/gap checks, global
quartic majorization, and every continuous cell's positive coefficient gate.
