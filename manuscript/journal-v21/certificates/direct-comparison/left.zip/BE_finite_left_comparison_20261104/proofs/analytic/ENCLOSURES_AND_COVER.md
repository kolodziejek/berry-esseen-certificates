# Semantic enclosures and the exact replacement obligation

## Read-only audit of root/enclosures.py

The source was read in full, and its estimates were derived separately.
There is no sign or inequality-direction defect in the reviewed formulas.
The completed-source/result hashes used for a final acceptance must be
recorded by that acceptance epoch; this note is not permission to substitute
later changed sources.

1. The raw signed budget uses the table's Qbudget coefficients, takes the
   clipped vertex of each concave quadratic on both permitted H half-lines,
   and keeps the maximum over all four common-law corners. Intersecting with
   T and the weighted47D bound is valid. The H interval is formed by the
   correct sign-dependent divisions by lower/upper square roots.
2. P0 is a lower bound on the decreasing binary defect over the p cell.
   The coefficient beta=b-3P0/2 is legitimate because the binary term is
   first replaced by `(1-theta)^(3/2)*P0`. It is not obtained by subtracting
   a lower bound from an independently fixed exact coefficient. The new
   noise ceiling is rounded upward, intersected with the previous ceiling,
   and valid at each of the sixteen iterations. Finite termination needs
   no convergence assertion.
3. The test `kappa*n*P0>=B` is a strict exclusion, including equality,
   because `P0>0` and `kappa<phi(0)/6`; the actual conserved budget satisfies
   `B>=n*phi(0)*D/6>kappa*n*P0`. A reader should explicitly check the cheap
   rational guards `SIGMA_LO^2<10`, `KAPPA<PHILO/6`, and
   `CELO<(3+SIGMA_LO)*PHILO/6`. The raw table and final gap result must be
   pinned, and the full unique gap domain must be bound rather than merely
   the length of a dictionary.
4. The support radii `A0=3*sqrt(w)_upper-pl` and
   `A1=3*sqrt(w)_upper-(1-pu)` are outward bounds from radius3. The checks
   A0,A1>=d0 and d0<pl supply both the common support interval and the
   required sign decomposition of the third absolute moment.
5. A binomial mass is unimodal as a function of p, with peak k/n. Its
   minimum over a closed interval is therefore at an endpoint and its
   maximum at the clipped peak. Each incoming ratio is increasing in p;
   the finite product evaluated at pu bounds every legal incoming mass.
   These bounds include all counts and do not assume n is infinite.
6. For the normal phase integral, the largest absolute endpoint among
   delta_lo, delta_hi, delta_lo+ul and delta_hi+uh bounds every point of
   the interpolation. `phi(0)*(1-z^2/2)` is a lower density bound, and
   positivity is checked. For positive phase the code uses the lower
   density and upper square root; for negative phase it uses the upper
   density and lower square root, with the negative phase endpoint.
   Both directions give a lower bound on the signed integral.
7. If delta_hi<0, increasing the variance gives a favorable normal
   correction. The lower bound uses the smallest -delta, the density
   lower bound along the whole interpolation, and the largest variance
   denominator. Otherwise the negative correction uses delta_plus_hi,
   phi(0)'s upper bound, and the smallest denominator. The factor1/n is
   correct because the stored coefficient multiplies lambda=n*s.
8. The lower cubic-price bracket uses G>=3pl-d0, v>=pl(1-pl), and
   s<=U/n, all in the correct directions. Thus the positive coefficient
   c_gain can safely be rounded downward. The positive gap is the
   independently proved rhoB*epsilon for this exact row,n,k domain.

The final checker still has to verify every bracket and polynomial, the
global payoff majorants including both rays, and the complete geometric
cover. Successful scalar enclosures alone are not a score certificate.

## Coverage theorem to be discharged

Take a positive closed-event attained ratio maximizer with the hypotheses
of `j:local:uniform` in journal-v20: n>=47, C>=CE, scaled excess<=.7,
predecessor loss<=.19, own cap .4247 and both deleted caps .4253. Suppose
the already accepted acquisition schedule places it in one of the raw L39
rows of node L, using radius3. Every raw row has all its moment, phase,
weighted-defect and noise bounds simultaneously for this same law.

The joint defect gives its exact finite integer restriction. The bound
on H and span gives the nearest-count interval in the finite-gap reader.
Both half-integer nearest-count choices are covered; choose either one.
The original entire p row is covered by closed p cells, and [-1/2,1/2]
by closed signed phase cells. A cell is admissible if either:

* its full H/resource interval is proved impossible by a strict conserved
  budget exclusion; or
* its complete lambda interval [0,U] and all actual common conditional
  moment values are covered by a global quartic majorant and all24 exact
  inward-support score gates (or another separately proved comparison).

Every numerical exclusion must state which complete cell it excludes.
An adaptively subdivided tree must retain its root, every child partition,
and every endpoint; replacing an unsuccessful leaf by a successful proper
subset is not a cover. The final collector must reconstruct the exact
39 rows, their3385 integer pairs, their8248 possible counts, and the
closed p/phase root domains from the original inputs. It must reject an
unresolved leaf, a gap, a changed parent, a changed target, or an unsupported
normalization/resource substitution. The finite-gap reader supplies both
jump branches, but only the positive closed branch is needed after the
original attainment/reflection reduction. Both signs of H and u still
have to be checked on the same oriented law.

On a comparison leaf the finite binary gap and the shared conditional
fourth-moment rule prove directly C<CE. This contradicts the attained
maximum. The proof includes lambda=0 through the full zero-noise score
gate with the translated expectation Q(-u). The outgoing event is strict:
at W_k=0 its contribution is -1 for u<0 and0 for u>=0, preserving
F_B(k-1) versus F_B(k). The finite gap at nearest count k alone would not
justify dropping that signed phase/atom calculation. There is no noise
cutoff or division by lambda. For n above the row's certified ceiling, the weighted binary
defect already gives a contradiction. Thus a complete collector meeting
these requirements would exclude the entire raw L39 branch for every
n>=47, including equality C=CE. No new compactness or attainment theorem
is inferred from arithmetic; the existing theorem supplies that input.

## What this would remove, and what it would not

In journal-v20/sections/local.tex the resource schedule is the table in
the subsection “Confinement from the remaining defect budget,” followed
by `j:local:re:acquired`. A complete raw-left exclusion would permit:

* keep I and L, then terminate the left branch at L;
* delete the selected S sign-resource pass whose left purpose was to
  remove the first raw row; its extra central refinement is already
  explicitly unused by the selected central comparison;
* delete L2, its left radius2.7 update, the3073-cell left coordinate-strip
  consequence and its38-row output;
* delete the uniform-left47 confinement/profile and TINY/MID/LOW numerical
  descendants, replacing their proof use by the direct finite conclusion;
* restate the uniform acquired/comparison propositions as: a law is either
  excluded in raw L39 or placed in the45 selected central rows.

This does NOT justify deleting the general confinement proof, its
antichain/deletion argument, or the common nearest/whole-count machinery.
The central C1/C2 route still uses them. The separate finite42--48,
actual40--42 and positive39 modules also retain their own left confinement
and comparison inputs; the new theorem starts at n47 and uses raw L39,
not those different resource tables. In particular, no floor or moment
table may be transferred backward to those finite modules without a new
proof. The same distinction applies to the generic radius/strip theorem,
which still has central and finite applications.

Therefore full raw-left closure removes a genuine branch of computations
and several specialized applications, but is not by itself evidence that
the large common analytic block can disappear. The attainable page saving
must be measured after a correct dependency edit. The partial results alone
do not mathematically justify those deletions. The user has authorized
manuscript work; the outstanding requirement is proof, not permission.
No manuscript change is made in this audit task.
