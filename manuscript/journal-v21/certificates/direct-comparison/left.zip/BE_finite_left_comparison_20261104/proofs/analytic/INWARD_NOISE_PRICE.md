# Noise consumes the inward budget as well

This strengthening uses only the raw acquired radius, the actual common
conditional marginals, and the joint-defect inequality. It requires no
coordinate strip or confinement. It applies at every finite retained n.

On a closed probability cell [pl,pu] set vmax=pu(1-pu). Suppose the current
proved ceiling is lambda<=U, the acquired inward ceiling is d<=d0<1, and
theta<=Theta<1. Choose outward rational support bounds

```
A0_hi >= 3*sqrt(vmax+U/n)-pl,
A1_hi >= 3*sqrt(vmax+U/n)-(1-pu),
M=max((1-pl)*A0_hi,pu*A1_hi)>0.
```

Conditional centering and the support intervals give

```
s0<=A0_hi*a0,  s1<=A1_hi*a1,
s=q*s0+p*s1
 <= M*(s0/A0_hi+s1/A1_hi) <= M*(a0+a1)=M*d.
```

For example the first variance inequality follows by integrating
`(U0+A0_hi)*(a0-U0)>=0`, whose expectation is A0_hi*a0-s0.
Thus `n*d>=lambda/M`. Both zero variances and zero inward endpoints are
included; all displayed denominators M,A0_hi,A1_hi are required positive.

The joint-defect inequality already proved in the manuscript gives

`D >= P0+alpha_D*d+beta*theta`,

where P0>0 is the binary lower bound, beta>0 is the noise coefficient
derived in DIRECT_CERTIFICATE_INTERFACE.md, and a valid inward price is

`alpha_D <= 6*(1-Theta)*sqrt((1-Theta)/vmax)*(1-d0)`.

Indeed the joint deterministic gap term is
`6*ell*(1-theta)*(d*(1-d)+a0*a1)`;
use ell>=sqrt((1-Theta)/vmax), d<=d0 and a0*a1>=0.
This term and the conditional-noise term appear in the SAME lower bound;
there is no independent spending of one resource twice.

Since `n*theta=n*lambda/(n*v+lambda)` and v<=vmax, lambda<=U,

```
n*D >= n*P0 + lambda*[
          alpha_D/M + beta*n/(n*vmax+U)].
```

Let E be the current acquired phase-budget upper bound for nD minus nP0.
If E<0 the cell is impossible. Otherwise

`lambda <= E/[alpha_D/M+beta*n/(n*vmax+U)]`.                (* )

All quantities in the denominator are positive. Use downward rational
prices alpha_D,beta, upward M and U, and round the final quotient upward.
Intersect with the old ceiling. After updating the support and phase
intervals from that smaller proved ceiling, repeat if useful. Each finite
iteration is a valid implication; no convergence or fixed-point premise
is introduced. A small nonnegative enclosure at E=0 is conservative; an
exact zero ceiling may instead be handled by the existing zero-noise gate.

This formula can strengthen the first denominator-rearranged theta-only
bound because it uses a term that the earlier comparison discarded. It
does not change the target, alter the acquired input table, or permit
using an unsupported amplitude. A complete campaign must record which
source epoch and ceiling reconstruction it uses. A failed old campaign
remains a failed campaign and is preserved even if a new stronger reader
accepts its recovered or regenerated objects.
