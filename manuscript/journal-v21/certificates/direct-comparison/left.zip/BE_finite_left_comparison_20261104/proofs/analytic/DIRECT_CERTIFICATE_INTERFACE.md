# Direct finite-score certificates on the raw acquired left branch

Mathematical status: the implications below are locally derived analytic
lemmas. A successful whole-row score certificate is a separate obligation.
Execution status: see the separate bounded identity/control pilot. Nothing in
this note asserts that all 3,385 retained integer/panel pairs are excluded.

## 1. The actual law and the inputs that remain necessary

Write `q=1-p`, `v=pq`, `Y=B+U`, with `P(B=1)=p`,
`E(U|B)=0`, and conditional laws `U0,U1`. Their variances and third moments
are `s0,s1,m30,m31`. Put

```
s=q*s0+p*s1, lambda=n*s, w=v+s, ell=w^(-1/2), theta=s/w,
U0 in [-A0,a0], U1 in [-a1,A1], d=a0+a1<min(p,q),
x=k+u=np+H/ell, |u|<=1/2, 0<=k<=n.
```

The raw L39 rows are the 39 closed panels of
`work/below50_20260929/entry/left_input47_table.json`, SHA256
`2270ab68dd18e13afb7382e046589346e4cab26721a4e48be77b66ec22aa4b9a`.
Their premises include the actual attained/contact law and the common signed
Fourier resource; they are not a characterization of all bounded laws.
The earlier exact integer restriction gives `47<=n<=326`, with 3,385
integer/panel pairs. The initial row has only n=47; the last row is
`p in [.378,.380]`, n=47,...,326.

Here the raw support is `|X|<=3`, where `X=ell*(Y-p)`. Thus one may use
`A0=3*sqrt(w)-p` and `A1=3*sqrt(w)-q`, or outward constant bounds on these
quantities. The later `.55` strip, the radius2.7 left refinement, and the
noise-dependent confinement amplitudes are NOT premises. All counts use the
same two conditional laws. A cell may enlarge their moment domain, but must
not replace the two laws by different choices at different counts.

## 2. Actual-n and phase-dependent noise pricing

Let sigma=sqrt(10), p*=(4-sigma)/2 and

`D_B(p)=(6+2*sigma)*(p-p*)^2/sqrt(pq)`.

The manuscript's joint-defect identity and its simultaneous lower bound
(`journal-v20/sections/core.tex`, `j:core:joint`,
`j:core:simultaneous`) imply

```
D >= (1-theta)^(3/2)*D_B(p)
   + 6*ell*(1-theta)*(d*(1-d)+a0*a1)
   + 3*(sigma+1)*Aplus*theta_plus
   + 3*(sigma+3)*Aminus*theta_minus.
```

The table's `A_lo` bounds Aminus; `B_lo` bounds Aplus. On a raw panel
`p in [pl,pu]` below p*, take a rational lower bound `P0<=D_B(pu)`.
The binary defect decreases up to p*, so this is a lower bound throughout.
If `theta<=Theta`, `d<=d0`, and `v<=vmax`, choose rational lower bounds

```
b <= min(3*(sigma+1)*B_lo, 3*(sigma+3)*A_lo),
beta <= b - 3*P0/2,
alpha <= 6*(1-Theta)*sqrt((1-Theta)/vmax)*(1-d0).
```

Require `P0>0`, `alpha>0`, `beta>0`. Since
`(1-theta)^(3/2)>=1-3*theta/2` and theta_plus+theta_minus=theta,

**D >= P0 + alpha*d + beta*theta.**

No rounding must turn a lower bound into an upper bound. For fixed n and a
closed phase cell, the acquired raw/sign-licensed resource supplies

```
n*D <= M,
M = min(47*Drow, Bmax/kappa), kappa=997/15000,
B(H)=min(T,max_j[A_j+F_j,sign*abs(H)-Q_j*H^2]),
Bmax >= max_allowed_H B(H).
```

Here Q is the table's `Qbudget`, not `Qraw`. This inequality uses the
already-proved contact/sign license; it is false as an assertion for arbitrary
nonextremal laws. It follows that, with `E=M-n*P0`,

```
alpha*n*d + beta*n*lambda/(n*v+lambda) <= E.                 (1)
```

E<0 excludes the cell. E=0 excludes positive noise; a zero-noise law is
treated by the binary score. If E>=0 and beta*n>E, then

`lambda <= E*n*vmax/(beta*n-E)`.

Intersect this bound with the acquired lambda ceiling. If beta*n<=E,
this rearrangement gives no finite upper bound and must not be used.
An optional stronger inward-support consequence is
`d>=s0/A0+s1/A1`; retaining it in (1) improves the noise restriction.

To refine by phase, first bound
`H=(k+u-np)/sqrt(v+lambda/n)` using the current noise interval, respecting
the sign of its numerator. The maximum of each concave quadratic on a closed
interval occurs at an endpoint or its clipped vertex. Taking their maximum
and intersecting with T gives a valid Bmax. Each subsequent iteration starts
with a proved superset; its new noise cap is therefore valid. There is no
need to assert convergence. Every interval, rational square-root enclosure,
quadratic candidate, and new cap belongs in the proof object.

## 3. A stronger shared signed-moment resource

Set `z0=a0*s0-m30`, `z1=m31+a1*s1`. Conditional centering and inward
support imply

```
z0,z1>=0;  a0*z0>=s0^2;  a1*z1>=s1^2;
m40 <= a0^2*s0+(A0-a0)*z0;
m41 <= a1^2*s1+(A1-a1)*z1.                                (2)
```

If an inward endpoint is zero, its centered variable is identically zero;
its variance, third moment and z all vanish. The denominator-free form of
(2) covers this case. For positive endpoints, the signed cubic bound follows
by integrating `(a0-U0)*(U0+s0/a0)^2>=0`, and its reflection. The fourth
bound follows by integrating
`(U0+A0)*(a0-U0)*U0^2>=0`, and its reflection. Also `s0<=A0*a0`,
`s1<=A1*a1`, hence the stated lower bound on d.

The full joint-defect inequality gives the stronger coupled budget

```
ell^(-3)*D >= v*(6+2*sigma)*(p-p*)^2
 + 6*v*(d*(1-d)+a0*a1)
 + q*(3*(sigma+3)*p-(sigma+7)*a0)*s0
 + p*(3*(sigma+1)*q-(sigma+5)*a1)*s1
 + (sigma+1)*q*z0 + (sigma-1)*p*z1.                         (3)
```

To verify the coefficients, its positive conditional kernel is
`p*[3*(sigma+1)*q-6*a1]*s1+p*(sigma-1)*m31`;
substitute `m31=z1-a1*s1`. The negative kernel is
`q*[3*(sigma+3)*p-6*a0]*s0-q*(sigma+1)*m30`;
substitute `m30=a0*s0-z0`. The deterministic terms give the first two
terms of (3). This is a lower bound, not an equality for arbitrary laws.
The same z variables must appear in every moment and resource expression;
independently spending their budget in several estimates is invalid.

## 4. One all-count payoff, with closed event planes

Couple independent sequences U0_i and U1_i, and set
`W_j=sum_{i<=j} U1_i + sum_{i>j} U0_i`. Then
`(j+1)+W_(j+1)-(j+W_j)>=c=1-d>0`. Add the conventions that a cutoff before
0 gives R=-k-1 and a cutoff at n gives R=n-k. Let
`R=max{j: j+W_j<=k+u}-k` with this convention. The exact conditional count
identity gives

```
P(sum Y_i<=k+u)-F_B(k)=pi_k*E G(R),
G(r)= sum_{i=1}^r pi_(k+i)/pi_k               if r>0,
G(0)=0,
G(r)=-sum_{i=r+1}^0 pi_(k+i)/pi_k             if r<0.
```

All masses outside 0,...,n are zero. If R<0, then W_k>u and G(R)<=-1;
if R>=1, the spacing gives `W_k<=u-c*R`. Hence, for any bound
`R0>=max_{j>k} pi_j/pi_k`,

```
G(R) <= g(W_k;u,c,R0)
       = -1{W_k>u}+R0*max(0,floor((u-W_k)/c)).               (4)
```

When there is no incoming count, take R0=0. This formula keeps strict
outgoing and closed incoming events, including atoms at u and u-j*c.
The right side increases with u and R0 and decreases with c. Thus for an
entire cell one may use its upper u, upper R0, and lower positive c.

A rational polynomial Q majorizes g globally if, for an integer J>=1,

```
Q+1 >=0                            on [u,+infinity),
Q-j*R0>=0                         on [u-(j+1)*c,u-j*c], j=0,...,J-1,
Q-R0*(u-x)/c>=0                    on (-infinity,u-J*c].   (5)
```

At a shared event plane the lower adjacent interval or the last ray gives
the higher staircase value. Checking only open intervals would miss these
atoms. Finite-interval Bernstein coefficients plus exact transformed-ray
positivity witnesses are one sound way to establish (5). They are not the
only admissible format.

For comparison, the elementary all-count bound
`R_+<=W_k^2/(c-u)^2` holds if |u|<=1/2<c: on R=i>=1,
`W_k<=u-ci<0`, and
`(ci-u)^2-i*(c-u)^2=(i-1)*(c^2*i-u^2)>=0`.
It does not need A0,A1<1. Higher moments or the shared resource may sharpen
it, but each such change needs its own score acceptance.

## 5. Exact expectation without independent moment intervals

In addition to (5), require `Q''''>=0` on the whole real line. The proved
endpoint-Poisson comparison in
`work/coarse_comparison_20261104/analytic/POISSON_COMPARISON.md` has a
self-contained Taylor/generator proof: a centered bounded increment is
first Poissonized; the square of its centered translation generator is
positive on functions with convex second derivative. The size-biased jump
measure, which has mean third moment / variance, is then replaced by its
endpoint chord. Neither step changes the first three cumulants. The proof
uses global convexity of Q'', since the comparison process is unbounded.

Choose fixed enclosing outward bounds Aminus,Aplus>0 for both conditional
laws throughout the cell. Define

```
t=(n-k)*s0+k*s1, S3=(n-k)*m30+k*m31,
K1=0, K2=t, K3=S3,
Kr=(Aplus-Aminus)*K_(r-1)+Aminus*Aplus*K_(r-2), r>=4,
M0=1, Mr=sum_{h=2}^r binom(r-1,h-1)*Kh*M_(r-h).
```

These are the cumulants and moments of the centered endpoint compound
Poisson variable. Consequently

`E G(R) <= E Q(W_k) <= sum_j Q_j*M_j`.                    (6)

The zero-noise case has t=S3=0 and Mj=0 for j>0, without any division.
One may instead retain the two asymmetric conditional intervals and add
their count-weighted cumulants, as proved in `ASYMMETRIC_POISSON.md`.
This is stronger but introduces a0,a1. All endpoint rates must be
nonnegative, or equivalently each interval must enclose the retained
third-moment/variance ratio. The cumulant recurrence has no division by
zero at a degenerate conditional endpoint.

For lambda>0 parametrize the actual mixture by

```
alpha=p*s1/s in [0,1],
s0=lambda*(1-alpha)/(n*q), s1=lambda*alpha/(n*p),
m30=s0*gamma0, m31=s1*gamma1,
-A0<=gamma0<=a0, -a1<=gamma1<=A1.
```

When a variance vanishes, set its gamma to any value in the interval; it
is multiplied by zero. Thus the parameter cover includes both endpoints
alpha=0,1 and lambda=0 by continuity, without inventing separate laws.

## 6. A polynomial certificate for the direct sharp score

Because a0<p and a1<q, the two conditional classes remain on their actual
sides of p. Their EXACT common raw third absolute moment is

```
rRaw = E|Y-p|^3
     = v*(1-2*v)+3*v*(s0+s1)+p*m31-q*m30
     = v*(1-2*v)+(lambda/n)*[
         3*p*(1-alpha)+3*q*alpha+alpha*gamma1-(1-alpha)*gamma0].
```

In particular it is positive under the acquired inward bound d0<3*p and
gamma0<=d0, gamma1>=-d0. No favorable repair is discarded or silently
assigned the wrong sign.

For a closed parameter cell choose independently certified rational bounds

```
F_hi >= BinCDF(n,p,k),  pi_lo<=pi_k<=pi_hi,
Phi_lo <= Phi((k+u-n*p)/sqrt(n*v+lambda)),
w_hi >= v+lambda/n, sqrt_n_hi>=sqrt(n), sqrt_w_hi>=sqrt(w_hi),
0<CE_lo<=CE, c0=CE_lo/(sqrt_n_hi*w_hi*sqrt_w_hi).
```

Let E_Q denote the rational expression in (6). It suffices to certify, for
BOTH endpoints b=pi_lo and b=pi_hi,

`Phi_lo+c0*rRaw-F_hi-b*E_Q > 0`                            (7)

throughout the allowed moment/parameter cell. Linearity covers every
intermediate mass, regardless of the sign of E_Q. Then

```
F_actual-Phi_actual <= F_hi+pi_k*E_Q-Phi_lo
                    < c0*rRaw <= CE*rRaw/(sqrt(n)*w^(3/2)),
```

which proves the direct score `sqrt(n)*(F_actual-Phi_actual)/rho < CE`.
The binary finite gap is part of (7); there is no requirement that the
noise perturbation itself have a negative coefficient. If exact binomial
polynomials are used instead, set F_hi=F_n,k(p), b=pi_n,k(p) and omit the
mass endpoint split.

For degree d of Q, every Mr has denominator dividing
`(n*p*q)^floor(r/2)`, because all Kr for r>=2 are linear combinations of
t and S3. Multiplication by `(n*p*q)^floor(d/2)>0` turns (7) into an exact
rational polynomial in p,lambda,alpha,gamma0,gamma1 (and any retained
polynomial support variables). A complete box Bernstein certificate is
sufficient. If (1)--(3) restrict the box, either cover it by proved valid
subboxes, or use a fully checked multiplier/domain certificate; do not
delete untested parameter points based on floating samples.

Required coverage ledger: all 39 probability rows; each retained integer;
every legal nearest count; both signed H branches; lambda from zero to its
proved cap; all phases including half-integers and event-plane atoms; full
variance and skew parameters; source and normalizer identities. Any omitted
region is a remaining obligation. The current note gives the interface and
not that final coverage assertion.

## 7. Preferred gate: preserve the finite binary cancellation

The direct gate (7) is sound but separate intervals for a binomial CDF and
the normal CDF can lose too much. The following equivalent decomposition
uses a separately certified finite binomial gap. Suppose, on the entire
current probability cell and for the actual count k,

`sqrt(n)*(F_B(k)-Phi(delta/sqrt(n*v)))/rhoB <= CE-epsilon`,

where delta=k-n*p, rhoB=(1-2v)/sqrt(v), and epsilon>0. This is precisely the
positive closed-CDF branch required here. An absolute or two-sided binomial
certificate is also sufficient, but a gap on some other count domain is not.

Write

```
G=3*p*(1-alpha)+3*q*alpha+alpha*gamma1-(1-alpha)*gamma0,
L=G-3*(1-2*v)/2-3*(1-2*v)*s/(8*v).
```

Taylor's formula with decreasing second derivative gives, for all x>=0,
`(1+x)^(3/2)<=1+3*x/2+3*x^2/8`. Consequently

`rho-rhoB >= s*L/w^(3/2)`.                                (8)

Require L>=0 before making the lower substitutions below. A sufficient
uniform check is

```
6*pl-3*pl^2-3/2-d0
 - 3*(1-2*vmin)*smax/(8*vmin) >=0,
```

since G>=3*p-d0, p<1/2, and v>=vmin. For a stronger acceptance retain the
full signed G; do not replace it by this lower bound unnecessarily.

Choose rational `v_lo<=v`, `w_lo<=w<=w_hi`, square-root bounds with the
appropriate directions, `rhoB_lo<=rhoB`, and CE_lo<=CE. For the phase
integral let 0<phi_min<=phi(z)<=phi_max on every z between
delta/sqrt(n*w) and (delta+u)/sqrt(n*w), throughout the cell. Then

```
phase_lower(u) = phi_min*u/sqrt_w_hi    when u>=0,
                 phi_max*u/sqrt_w_lo    when u<=0.
```

The sign split is essential. The normal variance change satisfies

```
sqrt(n)*[Phi(delta/sqrt(n*w))-Phi(delta/sqrt(n*v))]
 >= -phi0_hi*delta_plus_hi*s/(2*v_lo*sqrt_v_lo),             (9)
```

where delta_plus_hi>=max(0,delta) and phi0_hi>=phi(0). For delta<=0 this
term is nonnegative and can be dropped. A positive lower contribution
`phi_min*(-delta)_lo*s/(2*w_hi*sqrt_w_hi)` may instead be retained if the
density lower bound also covers the whole variance interpolation.
Formula (9) follows by differentiating with respect to s; it is not an
asymptotic remainder and is uniform down to s=0.

Set `c_gain=CE_lo/(w_hi*sqrt_w_hi)` and bound
`b= sqrt(n)*pi_k` by [b_lo,b_hi]. For both endpoint values of b certify

```
epsilon*rhoB_lo + c_gain*s*L + phase_lower(u)
 - phi0_hi*delta_plus_hi*s/(2*v_lo*sqrt_v_lo)
 - b*E_Q > 0.                                             (10)
```

Indeed the actual sharp-score slack is at least

```
CE*rho - sqrt(n)*(F_actual-Phi_actual)
 >= epsilon*rhoB + CE*(rho-rhoB)
    +sqrt(n)*[Phi_actual-Phi(delta/sqrt(n*v))] - b*E_Q,
```

and (8)--(9) give (10). Its b endpoint checks handle either sign of E_Q.
The same positive-denominator polynomial conversion described above applies;
L introduces one extra factor v in a denominator. For degree d>=2,
`n*(n*p*q)^(floor(d/2)+1)>0` is a safe common clearing factor. Sharpness of
this exponent is unnecessary. The square roots, Gaussian density bounds,
epsilon and normalization constants are external rational cell inputs with
their own exact verification; they are not sampling oracles.

## 8. Elementary all-phase fallback for small actual noise

Let normal phase satisfy `l_f*u<=f(u)<=h_f*u` for u>=0, with the
corresponding signed integral bounds for u<0; assume 0<h_f<2. For u=-r,
0<=r<=1/2, Cantelli and centering give

```
P(W_k>u)+f(u) >= r^2/(t+r^2)-h_f*r,
h_f*r-r^2/(t+r^2) <= K*t,
K=h_f^2/[4*(1-h_f/2)].
```

For t>0 the second inequality follows after multiplying by t+r^2:
the required numerator is bounded below by
`(1-h_f/2)*r^2-h_f*r*t+K*t^2>=0`. The omitted terms
are nonnegative. At t=0 use the deterministic law directly; in particular,
at u=0 the outgoing event is empty.

If `Var(W_(k+i))<=v_i*lambda` and `r_i=pi_(k+i)/pi_k`, define the finite
sum `H(u)=sum_{i=1}^{n-k} r_i*v_i/(i-u)^2`. Incoming Chebyshev bounds are
valid for all signed phases, independently of A0,A1. For u<=0 use H(u)<=H(0)
and t<=omega_hi*lambda. For u>=0 the convex function
`lambda*H(u)-l_f*u` on [0,1/2] is bounded by its two endpoint values.
Thus for lambda>0 the entire conditional gain is bounded by

```
Q/pi_k-f(u)
 <= lambda*max(H(0)+K*omega_hi, H(1/2)-l_f/(2*lambda))
 <= lambda*(H(0)+K*omega_hi)
      +max(0,lambda*(H(1/2)-H(0))-l_f/2).                 (11)
```

The first displayed max is the sharper bound; the second avoids a division
by lambda after multiplying out. This is a candidate direct finite-gap
fallback, not a claim that the numerical right side suffices on every raw
row. Its coefficients must retain actual n, count, probability and variance
split or valid upper bounds for them. In particular, an infinite-n incoming
ratio envelope is not automatically a finite-n bound.

## 9. Quartic reduction: only one-dimensional degree-six certificates

This is a substantial simplification of the generic interface. Let Q be a
quartic satisfying (5), and write Q(x)=q0+q1*x+q2*x^2+q3*x^3+q4*x^4
with q4>=0. Thus its fourth derivative is globally nonnegative automatically.
For this quartic case the endpoint-Poisson theorem can be removed from the
dependency list altogether. Independence gives
`E W_k^4=sum_i E Z_i^4+3*t^2-3*sum_i (E Z_i^2)^2`.
The nonnegative support polynomial
`(Z_i+A0)*(A1-Z_i)*Z_i^2` gives
`E Z_i^4<=(A1-A0)*E Z_i^3+A0*A1*E Z_i^2`.
Sum and drop the nonpositive last term. Multiplying by q4>=0 proves (12)
directly. The lower-degree moments are exact. Thus (12) is an elementary
common-marginal fourth-moment bound, without any assertion that the actual
sum has a Poisson distribution. Retaining the dropped negative term may
improve a bound, but can destroy the alpha concavity used below; this
specific reduction uses (12) exactly as printed.
Fix a closed cell in p,lambda,u and all enclosure constants used in (10).
Check `A0>=d0`, `A1>=d0` and `d0<pl`: the common support interval then
contains both conditional inward endpoints, and both conditional classes
remain on their assigned signs of Y-p.
In particular fix A0,A1,d0, the polynomial Q, phase_lower's cell minimum,
c_gain and the coefficient of the variance loss. They must not vary with
the variance split or conditional skew. Let lambda range over a proved
constant interval [lambda_lo,lambda_hi], possibly starting at zero.

For each mass endpoint b>=0 the exact endpoint-CP expectation is

```
E_Q=q0+(q2+q4*A0*A1)*t
        +(q3+q4*(A1-A0))*S3+3*q4*t^2.                   (12)
```

At fixed p,lambda,gamma0,gamma1, the left side of (10) is a concave
function of alpha. All terms are affine in alpha except `-3*b*q4*t^2`,
which is concave since t is affine. A concave function on [0,1] is bounded
below by the smaller endpoint value. At alpha=0 gamma1 disappears, and at
alpha=1 gamma0 disappears. Each surviving gamma enters affinely. Therefore
the entire actual same-law moment domain is covered by just four corners:

| Corner | V=t/lambda | surviving gamma | G |
|---|---|---|---|
| alpha=0, negative skew | (n-k)/(n*q) | -A0 | 3*p-gamma |
| alpha=0, inward skew | (n-k)/(n*q) | d0 | 3*p-gamma |
| alpha=1, inward skew | k/(n*p) | -d0 | 3*q+gamma |
| alpha=1, positive skew | k/(n*p) | A1 | 3*q+gamma |

These corners need not be realizable conditional laws. They enclose all
actual laws and are used only to bound a necessary-domain relaxation. The
proof is not a linear-extreme-point assertion about P -> P^{*n}.

At each corner, t=lambda*V, S3=lambda*V*gamma, so

```
E_Q=q0+lambda*V*[q2+q4*A0*A1
                 +(q3+q4*(A1-A0))*gamma]+3*q4*lambda^2*V^2.
```

The coefficient of lambda^2 in (10) is exactly

`-c_gain*3*(1-2*v)/(8*v*n^2)-3*b*q4*V^2 <=0`.

The other terms are affine or constant in lambda. Thus the score lower
bound is concave in lambda too, and its two endpoints suffice. This yields
eight rational functions of p **for each mass endpoint b**, or sixteen in
total when both endpoints are required. A separately proved sign of E_Q
may permit only one mass endpoint, but cannot be assumed from sampled values.

For constant lambda endpoints, multiplication by `(n*p*q)^2>0` turns
each function into a polynomial of degree at most six in p: the term
with G has degree at most six after clearing, the extra variance-price
denominator is v, and V has denominator n*p or n*q. A one-dimensional
Bernstein positivity certificate on the full p interval therefore suffices.
One may also prove L>=0 using its lower bound in Section7. All enclosure
premises, q's global majorization, endpoint atoms, and the finite binary
gap still have to be verified. The corner reduction removes none of them.

The proof remains valid if a parameter endpoint is a rational function of p,
but then the claimed degree-six bound need not hold. Likewise it must not
be applied to a degree-eight Q, to b<0, to q4<0, or with Gaussian/resource
coefficients that depend on the eliminated moment variables. Such variants
need separate derivations.

## 10. Stronger rule: retain inward supports with twenty-four gates

The common interval in Section9 forgets that the positive endpoint of U0
and the negative endpoint of U1 are small. This can be repaired while
keeping a one-dimensional certificate. Keep the actual inward endpoints
a0,a1, with a0+a1<=d0. The support polynomials give

```
m40 <= (a0-A0)*m30+A0*a0*s0,
m41 <= (A1-a1)*m31+A1*a1*s1.
```

Consequently the valid quartic expectation upper bound is

```
q0+q2*t+q3*S3+q4*[
 (n-k)*s0*((a0-A0)*gamma0+A0*a0)
 + k*s1*((A1-a1)*gamma1+A1*a1)+3*t^2].                    (13)
```

It uses precisely the same conditional laws and variance split as the raw
third absolute moment. No Poisson result is involved. Relative to the
common-interval fourth bound, the saved amount in the fourth moment is

```
(n-k)*s0*(A1-a0)*(gamma0+A0)
 + k*s1*(A0-a1)*(A1-gamma1) >=0,
```

provided A0,A1>=d0. Thus this is a pointwise stronger bound on the actual
parameter domain.

Use (13) in the loss gate (10). To minimize the gate, first FIX a0,a1 and
gamma0,gamma1 within their actual intervals. The only nonlinear term in
alpha is again `-3*b*q4*t^2`, so its endpoints suffice. Enlarging the
remaining endpoint domain from a0+a1<=d0 to independent ai in[0,d0] is
safe. At alpha=0 the entire a1/gamma1 dependence disappears. The remaining
gamma0 enters affinely and ranges over [-A0,a0]. At its outward endpoint
gamma0=-A0, the fourth coefficient is A0^2 and all dependence on a0
cancels. At its inward endpoint gamma0=a0, the fourth coefficient is a0^2.
The remaining loss depends on a0 through an affine expression minus
`b*q4*t*a0^2`, hence is concave in a0. Its endpoints 0,d0 suffice.
The alpha=1 argument is the reflection: gamma1 is -a1 or A1, and the
inward endpoint has fourth coefficient a1^2. This proves the six-corner
cover:

| alpha | gamma | J4, the coefficient of t in the fourth bound |
|---|---|---|
| 0 | -A0 | A0^2 |
| 0 | 0 | 0 |
| 0 | d0 | d0^2 |
| 1 | A1 | A1^2 |
| 1 | 0 | 0 |
| 1 | -d0 | d0^2 |

At each corner use

`E_Q=q0+lambda*V*(q2+q3*gamma+q4*J4)+3*q4*lambda^2*V^2`.

The lambda concavity coefficient and the mass endpoint argument are
unchanged, so six moment corners times two noise endpoints times two mass
endpoints yield **twenty-four** rational functions of p. Multiplication by
(npq)^2 still gives degree at most six. The corresponding coefficient of
q4 in the cleared polynomial is

`-b*[J4*linear_moment+3*quadratic_moment]`,

where linear_moment=(npq)^2*lambda*V and
quadratic_moment=(npq)^2*lambda^2*V^2. This is the only change to the
quartic expectation part of the degree-six constructor. The positive-price
bracket can still be checked on the larger Section9 domain.

The artificial endpoints ai=0 with positive conditional variance need not
be realizable. They belong to an enlarged algebraic domain used to lower
bound the loss. Every actual law is covered by the successive concavity
arguments; no claim of existence at artificial endpoints is made. The
spacing/payoff certificate must use the fixed conservative c=1-d0, so it
does not acquire an untracked dependence on ai when these endpoints are
eliminated. All other premises and coverage obligations remain unchanged.
