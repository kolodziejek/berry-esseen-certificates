# Keep the phase in the quartic

The acquired inputs, variance/moment cone, final24-corner scope and target
are unchanged. The useful change is to write the majorant in Z=W_k-u,
while keeping u as a variable in the exact score gate.

## Global probability bound

For fixed c and R0 the common payoff is translation invariant:

`g(W_k;u,c,R0)=psi(W_k-u)`,
`psi(z)=-1{z>0}+R0*max(0,floor(-z/c))`.

Thus a single quartic Q majorizing psi on the entire real line works at
every phase in a cell. Its global proof uses phase0. At z=0 the required
value is0; at z=-j*c the closed incoming value is j*R0. The existing
closed-interval/ray acceptance includes these atoms. No stochastic or
moment translation is inferred: expand Q(W-u) explicitly.

## Exact expectation and unchanged corners

Writing Q(z)=sum(q_h*z^h),

`Q(W-u)=sum_j qtilde_j(u)*W^j`,
`qtilde_j(u)=sum_{h>=j} binom(h,j)*q_h*(-u)^(h-j)`.

In particular qtilde4=q4,
qtilde3=q3-4q4*u, qtilde2=q2-3q3*u+6q4*u², and
qtilde0=Q(-u). The first moment is zero. The already proved inward fourth
bound therefore gives

`E Q(W-u)<=Q(-u)+qtilde2*t+qtilde3*S3+q4*M4upper`.

For each FIXED u all terms retain the required dependence on the eliminated
variables. The sole alpha-quadratic term is -3*b*q4*t². At an inward
endpoint the sole ai-quadratic term is -b*q4*t*ai². At a reduced corner
the lambda-quadratic coefficient is still

`-3*c_gain*(1-2v)/(8*v*n²)-3*b*q4*V_alpha²<=0`.

Thus all24 moment/noise/mass endpoints suffice pointwise in u. These
reductions do not assume that W-u is centered; centering is used only for
W after its exact polynomial translation. A changed shift sign or setting
the shifted first moment to zero would be wrong.

## Keep the normal phase correction linear

On a closed nonnegative phase cell choose
`phasecoef<=phi_min/sqrt(w_hi)` and round DOWN. Then the signed phase
integral is at least phasecoef*u. On a nonpositive cell choose
`phasecoef>=phi_max/sqrt(w_lo)` and round UP; multiplication by negative
u reverses the direction and again gives a lower bound. Both coefficients
are positive. At u=0 either branch gives exactly0.

The semantic reader in `root/cover_shift.py` implements these directions
correctly. It calls the same acquired resource/normalization enclosures,
replaces the previous endpoint-minimized scalar phase by0, and supplies
the variable phasecoef*u. The shifted kernel requires scalarphase=0,
preventing duplicate addition of a phase allowance. The variance correction,
finite binary gap, cubic price, all true moment domains and target are
unchanged.

## Continuous certificate and source audit

After multiplication by (n*p*q)², every gate is a rational polynomial of
bidegree at most(6,4) in(p,u). Tensor Bernstein coefficients on the full
closed rectangle are sufficient: each tensor basis function is
nonnegative and the basis sums to1. The explicit construction first
affinely transforms both coordinates, then uses the exact factors
`binom(i,a)/binom(6,a)` and `binom(j,b)/binom(4,b)`. Both variable
endpoints, zero phase and every intermediate phase are therefore included.

Read in full: `construction/shifted_quartic_gate.py`, its exact controls,
`root/cover_shift.py` and the unchanged algebra it calls. The source's
translation sum, variable phase term, corner census, degree limits and
tensor transform agree with the independent derivation above. Semantic
phase coefficients have the correct directions. The exact global
majorant is checked at phase0, rather than incorrectly at the old phase
upper endpoint. No defect was found in this bounded source review.

The final cover reader should reject duplicate JSON keys as well as
omitted, duplicate or reordered semantic roots, bind all source and input
hashes, and reconstruct closed child partitions. The mathematical scope
of a partial input list is only those listed completed pairs.

## Measured pilot, not a complete campaign

For raw row38, n=125, the complete translated proof used15 quartics,
one resource exclusion and28 tree nodes, at depth at most5. The recorded
construction plus exact acceptance took5.3006seconds. The earlier
untranslated complete proof for this same pair used4,200 quartics and
about231seconds. These are observed single-pair results, not a time
prediction or evidence that all3,385 pairs pass.

Records: `runs/finite_left_replacement_20261104/root_shift_pilot01/`
and `root_cover_pilot03/`. The translated pilot includes the entire
closed original p row [.378,.380], both phase signs, all legal counts,
the full noise interval down to zero and the complete shared-moment
domain. Its improvement comes from preserving cancellation in u across
the polynomial and normal phase term, rather than using a phasewise
constant majorant. Complete raw-left replacement still requires the
full campaign and independent final coverage admission.
