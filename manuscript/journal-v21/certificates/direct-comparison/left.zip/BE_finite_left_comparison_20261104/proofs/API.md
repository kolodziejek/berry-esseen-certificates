# Exact quartic gate interface

`quartic_gate.py` is frozen after
`runs/finite_left_replacement_20261104/construction_quartic_controls01`.
It accepts only exact rational inputs. It proves no acquired domain or
payoff majorant by itself.

## Functions

```
gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi,q)
affine_gates(n,k,pl,pu,L,U,A0,A1,d0,gap,phase,varcoef,cgain,blo,bhi)
bracket_gates(n,pl,pu,L,U,A0,A1,d0)
bernstein(poly,pl,pu,degree=6)
```

`q` consists of five coefficients in powers of W, not W-u. `gates` returns
16 tuples of power-p coefficients. `affine_gates` returns records containing
the corner metadata, a constant polynomial and five linear polynomials;
their sum weighted by q is exactly the corresponding gate. The coefficient
of q1 is zero because EW=0. `bracket_gates` returns eight price-bracket
polynomials. `bernstein` returns every exact coefficient on the complete
closed probability interval. Positive coefficients imply strict positivity;
nonnegative coefficients alone suffice only when the surrounding argument
provides the required strict margin.

For the affine interface the caller must separately impose q4>=0. The
evaluated `gates` interface checks this. Both require cgain>=0, positive
mass bounds, legal integer n,k, positive coarse outward endpoints and a
closed nonnegative noise interval. All coefficient arrays are sparse only
through trailing-zero removal; the i-th entry always multiplies p^i.

## Caller-owned premises

The caller must supply and independently check:

* the actual raw acquired row, its weighted defect resource and complete
  finite n/count/probability/phase/noise coverage;
* the same conditional means zero, variances and signed support bounds
  `U0 in[-A0,d0]`, `U1 in[-d0,A1]`, with the actual inward sum <=d0;
  in particular the semantic reader must check `A0>=d0`, `A1>=d0` and
  `d0<pl`, so the common interval contains both conditional supports and
  their signs relative to p agree with the absolute-cubic expansion;
* a global polynomial majorant q of the actual coupled-count payoff,
  including both infinite rays, all jump endpoints and threshold atoms;
* the exact finite binomial gap, actual normalized mass interval,
  normal-phase and normal-variance price bounds;
* a valid cgain lower price, using one variance ceiling on the entire
  noise cell, and positivity of every price-bracket gate.

The signed third-moment ratios may vary over the conservative rectangles
`gamma0 in[-A0,d0]`, `gamma1 in[-d0,A1]`; these contain all actual
conditional laws. A zero conditional variance contributes zero and needs
no division to define its arbitrary gamma. No independent moment choice is
asserted to be a realizable law.

## Why a quartic needs no Poisson theorem

For each centered increment Z in[-A0,A1], nonnegativity of
`(Z+A0)(A1-Z)Z^2` gives

`E Z^4 <= (A1-A0)E Z^3 + A0 A1 E Z^2`.

For the actual independent sum W, put t=EW² and S3=EW³. Expanding the
fourth moment and dropping `-3 sum(Var Z)^2` gives

`EW^4 <= (A1-A0)S3 + A0 A1 t + 3t²`.

Thus for q4>=0,

`E q(W) <= q0 + (q2+q4*A0*A1)t
                 + (q3+q4*(A1-A0))S3 + 3q4*t²`.

Only the original pair of conditional laws occurs in t and S3. This direct
proof is enough for the selected quartic kernel. The optional generic
degree-eight utilities in `cp_interval.py` use the separately proved
endpoint compound-Poisson comparison and are not needed here.

## Why there are only sixteen gates

Let alpha be the fraction of unconditional noise variance in class one.
Then

`s0=lambda(1-alpha)/(n(1-p))`, `s1=lambda*alpha/(np)`,

`t=(n-k)s0+k*s1`,
`S3=(n-k)s0*gamma0+k*s1*gamma1`.

The cubic price bracket is

`3p(1-alpha)+3(1-p)alpha+alpha*gamma1-(1-alpha)*gamma0
 -1.5(1-2v)-3(1-2v)lambda/(8nv)`, where v=p(1-p).

For fixed p, noise, gamma0/gamma1 and positive mass b, the final loss is
concave in alpha: the only nonlinear alpha term is `-3b*q4*t²`.
Its minimum is at alpha=0 or1. The unused gamma then disappears and the
remaining gamma enters affinely. Hence the four moment corners are

`(alpha,gamma)=(0,-A0),(0,d0),(1,-d0),(1,A1)`.

At each corner, t=lambda*V with V=(n-k)/(n(1-p)) or k/(np). The loss is
concave in lambda because its quadratic coefficient is

`-3*cgain*(1-2v)/(8n²v)-3b*q4*V² <= 0`.

The other scalar terms are affine in lambda. Consequently the noise
minimum occurs at L or U. Finally the loss is affine in b, so its minimum
occurs at blo or bhi. The complete product is 4*2*2=16. This endpoint
argument remains valid at L=0 and at zero conditional variance. It is not
a claim that the underlying laws attain all rectangle corners.

The bracket is affine in each gamma, alpha after the unused variable
disappears, and lambda, so its separate eight endpoint gates prove the
required positivity on the entire moment/noise rectangle.

## Exact cleared expression

At an alpha corner, define

`G=3p-gamma`, `V=(n-k)/(n(1-p))` for alpha=0;

`G=3(1-p)+gamma`, `V=k/(np)` for alpha=1.

The scalar loss is exactly

```
gap + phase + varcoef*lambda
+ cgain*(lambda/n)*(G -1.5*(1-2v) -3*(1-2v)*lambda/(8*n*v))
- b*(q0 + lambda*V*(q2+q4*A0*A1
                  +(q3+q4*(A1-A0))*gamma)
        +3*q4*lambda²*V²).
```

`gates` multiplies this expression by the strictly positive `(n*v)²`.
The result has degree at most six in p. It keeps all scalar endpoints
fixed on the chosen p/noise/phase cell. An interval-specific scalar must
not be silently recomputed at a noise corner in a way that invalidates
the concavity argument.

The fresh checks compare 484 evaluations against an independently written
same-pair formula, reconstruct 448 Bernstein values, test 288 concavity
inequalities and reject eight malformed/sign/domain controls. These checks
support the implementation; the polynomial identities and the argument
above provide its mathematical soundness.

# Complete first raw-left panel

`row0.py` closes all of raw L0, not a sample of laws or parameters.
It uses the inherited original acquisition and contact-budget theorem.
The latter requires the acquired counterexample hypothesis `C>=CE`, so
`e=C-CE>=0` can be discarded from the budget. The weaker assumption
`C>=.4` alone would not justify its resource exclusions.
The exact fresh output is `construction_row0_01`.

The weighted defect lower bound excludes n>=48. For n47, the complete
threshold interval forces the nearest count to be 14 or15. Count15 has a
positive H whose signed resource upper bound is below the required defect
cost, and is excluded entirely.

For count14 and u<=.1, H is negative. Sixteen adjacent closed p intervals
retain the relation `|H| >= (47*p_lower-14-.1)/sqrt(w_upper)`. On each,
the exact maximum of each concave signed quadratic (including its clipped
vertex) is below `(997/15000)*47*D_lower`. This excludes the full remaining
small-phase region, including all negative phases and noise zero.

For u in[.1,.5] and lambda in[0,.0015], the original exact normalizer gives
`f(u)>=lf*.1`. For every legal incoming count i=1,...,33,

`Var W_(14+i) <= i*incoming*lambda`,

`Pr(W_(14+i)<=u-i) <= i*incoming*.0015/(i-.5)^2`.

This is the elementary second-moment bound for a closed event; no
confinement amplitude is used. Sum the finite33 terms, multiply by the
licensed incoming mass ratio R0, and discard the nonnegative outgoing
probabilities. The saved exact gate is

`mass*(lf*.1-R0*tail) - repair*.0015/47 > 0`.

The original comparison identity therefore gives C<CB on the entire
rectangle. The established finite Bernoulli theorem gives CB<=CE, so no
acquired maximizing witness lies in raw L0. Eight controls reject missing,
duplicated or reordered coverage, omitted counts, altered phase/noise
domains, changed cuts and changed source identities. This result alone
does not close the other38 raw left panels.
