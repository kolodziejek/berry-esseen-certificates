# Independent scalar-enclosure source audit

Reviewed file: `../root/enclosures.py`.
Final reviewed SHA256:
`38bd4b07a5c7d93cf676020ae55d28f697a76a9c46c0ee6b80086253c8f1c10b`.

Mathematical status: independently derived directions and source review;
no defect found under the original acquired counterexample hypotheses.
Execution status: read-only audit, no original integrals or acquisition
campaign rerun. This is not a completed-cover claim.

The first snapshot lacked the promised fixed gap hash. The final snapshot
adds `GAP_PIN`, checks the exact successful gap status and complete unique
census, and checks the strict directions of the scalar constants. The
mathematical enclosure formulas remain the ones reviewed below.

## Resource contraction

All source intervals lie below the critical Bernoulli probability. Thus
the Bernoulli defect decreases with p, and `p0_lower(pu)` is a lower bound
on the whole p cell. Its positive sqrt(10) coefficient uses a lower root,
and division uses an upper sqrt(v). The final downward grid operation is
correct for a lower bound.

The joint defect theorem gives `D>=P0+beta*theta`, with
`beta<=b-1.5*P0`, because `(1-theta)^1.5>=1-1.5theta`.
The substitution is legitimate even though P0 is a lower bound: first
replace the nonnegative Bernoulli defect term by P0, then apply the tangent
inequality. The explicit positive-beta check permits the noise cap.

The signed H interval correctly treats numerator signs when dividing by
the two positive square-root endpoints. Clipping by the acquired signed
threshold bounds preserves all actual laws. Each signed quadratic is
maximized at its clipped vertex; the maximum over the four corners and
minimum with the scalar resource remain upper bounds for the same budget.

The strict exclusion `kappa*n*P0>=B` is sound. Here kappa is strictly below
phi(0)/6, D>=P0>0 and the original excess is nonnegative. Hence the actual
budget requires `kappa*n*D<B`; this is not available from C>=.4 alone.

Writing `E=M-n*P0`, the retained inequality is
`beta*n*lambda/(n*v+lambda)<=E`. Once `beta*n-E>0`, it gives
`lambda<=E*n*v/(beta*n-E)`. Replacing v by its upper endpoint and rounding
up preserves all actual noise values. Each iterative contraction starts
from a previously valid cap, so stopping after sixteen iterations remains
sound even without convergence. A larger final cap only weakens the test.

## Binomial mass and ratios

For fixed n,k the mass is unimodal in p, with its maximum at k/n.
The minimum over a closed interval is therefore at an endpoint and the
maximum at the clipped peak. The square-root and grid rounding directions
for `blo,bhi` are correct. Each incoming ratio is increasing in p; the
product evaluated at pu bounds every legal incoming count. No illegal
count or different marginal is inserted into the actual comparison.

The finite gap is the pinned exact gap for the same row, n and count k.
It already covers the entire raw p row, hence also any selected subcell.

## Phase and variance signs

For the phase integral the argument bound contains every endpoint of
delta and delta+u over the cell. Since w>=wl, the Gaussian lower density
uses `PHILO*(1-maxarg^2/(2*n*wl))`, with positivity checked explicitly.
For nonnegative phase, the lower bound uses ul, the lower density and the
upper sqrt(w). For negative phase it uses the negative ul, the upper
density and lower sqrt(w); reversing this denominator direction would
be wrong, but the source uses the correct one.

For the normal variance difference, the derivative in lambda is
`-delta*phi(delta/sqrt(n*w))/(2*n*w^1.5)`. If the entire delta interval is
negative, the source retains a positive lower bound using -delta_hi,
the lower Gaussian density and the upper denominator. If delta may be
positive, it takes the adverse lower bound using delta_plus_hi, the upper
density and the lower denominator. The difference vanishes at lambda=0,
so integrating this fixed derivative bound gives `varcoef*lambda` on the
whole cell.

## Cubic price and support

The radius-three inequalities give the displayed coarse A0,A1 after
upper rounding. The source checks both A0,A1>=d0 and d0<pl. Thus the common
interval contains both inward endpoints and the signed absolute-cubic
formula applies.

The lower price `cgain` uses CELO and one upper `w*sqrt(w)` on the entire
noise cell. It is applied only after a positive lower bound for the full
third-moment bracket is checked. The minimum `G>=3*pl-d0` and the two
negative variance terms evaluated at vl and U have the correct directions.
All these constants are fixed before eliminating the moment variables or
taking the noise endpoints; this preserves the concavity argument.

The final caller still owns strict complete coverage, source identity of
the accepted objects, integer/count identities, global payoff majorization
and the final positive Bernstein margins. Those are not supplied by this
scalar-enclosure audit.
