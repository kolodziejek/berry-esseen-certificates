# Stronger conditional-inward quartic gates

`quartic_gate24.py` preserves the previous gate implementation and depends
on its pinned univariate polynomial routines. Its APIs are the same as
`quartic_gate.py`, except that `gates` and `affine_gates` produce 24 records
and each affine record includes `J4`.

The direct support inequalities are

`m40 <= (a0-A0)*m30+A0*a0*s0`,
`m41 <= (A1-a1)*m31+A1*a1*s1`.

They follow from the nonnegative conditional support polynomials multiplied
by U0² and U1². After independence, retain the resulting fourth-moment
upper bound plus 3t² and discard only the nonpositive variance-square sum.
No Poisson theorem is needed.

For fixed actual a0,a1,gamma0,gamma1, the loss remains concave in the
variance split alpha. At alpha=0 only the first conditional law remains;
the gamma0 endpoints are -A0 and a0. At the first endpoint the fourth
coefficient divided by s0 is A0². At the second it is a0², and the loss is
concave in a0 over [0,d0], so its endpoints suffice. Reflection gives the
second conditional law. The conservative six corners are

| alpha | gamma | J4 |
|---|---|---|
| 0 | -A0 | A0² |
| 0 | 0 | 0 |
| 0 | d0 | d0² |
| 1 | A1 | A1² |
| 1 | 0 | 0 |
| 1 | -d0 | d0² |

At each corner the expectation bound is

`q0+q2*t+q3*t*gamma+q4*(J4*t+3*t²)`.

The same noise concavity and affine mass argument gives 6*2*2=24 gates.
Only the cleared q4 coefficient changes relative to the earlier formula:

`-b*(J4*linear_moment+3*quadratic_moment)`.

All other scalar premises, complete p/noise/phase coverage and global
payoff majorization remain necessary. The implementation now explicitly
checks A0>=d0,A1>=d0,d0<pl as well as the algebraic domain guards. The older
eight price-bracket gates safely cover this smaller conditional domain.

The zero-inward corners are included conservatively. In fact, after this
reduction, each side's three values belong to one concave quadratic in
gamma with J4=gamma². The gamma=0 value is therefore at least the minimum
of the two outside endpoints. They may be removed in a separately selected
stronger sixteen-gate variant. A test showing that gamma=0 beats only the
inward d0 endpoint would not prove that omission is invalid when the
outward endpoint is also retained. No claim that `m4<=gamma²*s` holds on
the unreduced actual-law domain is made.

Fresh capture `construction_quartic24_controls02` passes 504 independent
conditional formula identities, 504 Bernstein reconstructions, 243 actual
parameter enclosure tests, 18 zero-corner redundancy checks and six
negative controls. The earlier controls01 log is preserved: its final
mutation fixture selected zero noise, where the two compared fourth prices
both vanish; the fixture was corrected to positive noise without changing
the gate core.
